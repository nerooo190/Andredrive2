import {jellyfinPath} from '../lib/jellyfin';
import {subsonicPath} from '../lib/subsonic';
import {opdsPath} from '../lib/opds';
import {webdavPath} from '../lib/webdav';
import {audiobookshelfPath} from '../lib/audiobookshelf';
import {handleDrive} from "../lib/drive-backend";
import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";

const worker = {
  fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    // Binary responses must keep their native stream length and HTTP Range headers.
    // Route them before the HTML/RSC response pipeline used by the UI framework.
    const pathname=new URL(request.url).pathname;
    if(webdavPath(pathname)||audiobookshelfPath(pathname)||opdsPath(pathname)||subsonicPath(pathname)||jellyfinPath(pathname)||/^\/(api|media|playlist|thumb|hls|movie|series)(?:\/|$)/.test(pathname)||/^\/(player_api|get|xmltv)\.php$/.test(pathname))return handleDrive(request,env,ctx);
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    return runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
  },
};

export default worker;
