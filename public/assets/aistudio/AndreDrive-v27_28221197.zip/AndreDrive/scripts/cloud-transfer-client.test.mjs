import assert from 'node:assert/strict';
import {runCloudTransfers,createCloudTransferManager,createCloudPool} from '../app/cloud-transfer-client.js';
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn){for(let i=0;i<1000;i++){if(fn())return;await wait(3)}throw Error('Queue did not settle')}
let phases=new Map(),active=0,peak=0,finishes=0,order=[];
const start=Array.from({length:55},(_,n)=>({id:'f'+n,status:'copying',size:30,copied:0,verified:0}));
function fixture(all,failed=null){globalThis.fetch=async(url,options={})=>{const [,id,action]=String(url).match(/transfers\/([^/]+)\/(step|finish)/);if(action==='step'){active++;peak=Math.max(peak,active);order.push(id);try{await wait(id==='f0'?8:3);if(options.signal?.aborted)throw new DOMException('pause','AbortError');if(id===failed)return Response.json({error:'permission denied'},{status:403});const n=(phases.get(id)||0)+1;phases.set(id,n);return Response.json({id,status:n<3?'copying':n===3?'verifying':'source_pending',copied:Math.min(30,n*10),verified:n>=4?30:0,size:30,fileId:n>=4?id:null})}finally{active--}}assert.ok(all.every(j=>phases.get(j.id)===4));finishes++;return Response.json({id,status:'done',size:30,copied:30,verified:30,fileId:id})}}
fixture(start);const updates=[];const done=await runCloudTransfers(start,{signal:new AbortController().signal,onUpdate:j=>updates.push(j)});assert.equal(peak,24);assert.equal(finishes,55);assert.ok(done.every(j=>j.status==='done'));assert.deepEqual(new Set(order.slice(0,55)),new Set(start.map(j=>j.id)));assert.equal(updates.length,275);
// An errored file does not stop other copies, but no source in its batch is removed.
phases=new Map();finishes=0;fixture(start,'f0');await assert.rejects(runCloudTransfers(start,{signal:new AbortController().signal}));assert.equal(finishes,0);assert.ok(start.slice(1).every(j=>phases.get(j.id)===4));
// Two overlapping selections share one limit and never process a file twice.
phases=new Map();finishes=0;peak=0;fixture(start);const memory=new Map(),storage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)};
const manager=createCloudTransferManager({storage:()=>storage});await manager.bind('owner-a');let events=0;const unsubscribe=manager.subscribe(()=>events++);
const first=manager.enqueue(start.slice(0,30));await until(()=>active>0);unsubscribe();const eventsBefore=events;const second=manager.enqueue(start.slice(20));await Promise.all([first,second]);assert.equal(events,eventsBefore);assert.equal(peak,24);assert.equal(finishes,55);assert.ok(manager.getSnapshot().jobs.every(j=>j.status==='done'));assert.deepEqual(JSON.parse(memory.get('andredrive:cloud-queue:owner-a')).ids,[]);
// Removing every view subscriber never aborts transfers; a full reload restores
// only IDs saved for the currently signed-in owner, using server-owned progress.
const restored=start.slice(0,25);phases=new Map();finishes=0;peak=0;fixture(restored);memory.set('andredrive:cloud-queue:owner-a',JSON.stringify({ids:restored.map(j=>j.id),parallel:32}));let loads=0;
const reloaded=createCloudTransferManager({storage:()=>storage,loadJobs:async()=>{loads++;return {transfers:restored}}});await reloaded.bind('owner-b');assert.equal(loads,0);await reloaded.bind('owner-a');await until(()=>!reloaded.getSnapshot().running);assert.equal(loads,1);assert.equal(peak,25);assert.equal(finishes,25);assert.equal(reloaded.getSnapshot().parallel,32);
// Explicit pause cancels pending requests, keeps server parts, and prevents
// automatic resume. An immediate new run cannot be erased by the old cleanup.
phases=new Map();finishes=0;fixture(start);const pausing=manager.enqueue(start);await until(()=>active>0);manager.pause();assert.equal(manager.getSnapshot().running,false);assert.deepEqual(JSON.parse(memory.get('andredrive:cloud-queue:owner-a')).ids,[]);const restarting=start.slice(0,3);fixture(restarting);const restarted=manager.enqueue(restarting);await pausing;assert.equal(finishes,0);assert.equal(JSON.parse(memory.get('andredrive:cloud-queue:owner-a')).ids.length,3);await restarted;assert.equal(finishes,3);
// A page exit checkpoints the queue even if cancellation callbacks settle before
// the document is destroyed. Already-saved parts are not reset by recovery.
phases=new Map();finishes=0;fixture(restored);const exiting=manager.enqueue(restored);await until(()=>active>0);manager.checkpoint();await exiting;assert.equal(JSON.parse(memory.get('andredrive:cloud-queue:owner-a')).ids.length,25);
// A lowered concurrency limit drains existing work without starting extra slots.
const pool=createCloudPool(32);const controller=new AbortController();let held=0,max=0;const work=Array.from({length:40},()=>pool.run(async()=>{held++;max=Math.max(max,held);await wait(3);held--},controller.signal));pool.setLimit(20);await Promise.all(work);assert.equal(max,32);assert.equal(pool.active,0);
console.log('Cloud queue checks passed: 24/32 concurrent files, FIFO part fairness, shared limits across selections, errors, source-removal safety, view unmount, reload recovery, owner isolation, explicit pause and page-exit checkpoints.');
