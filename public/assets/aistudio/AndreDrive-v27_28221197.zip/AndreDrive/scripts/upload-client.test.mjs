import assert from 'node:assert/strict';
import {uploadFile} from '../app/upload-file.js';
const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const file=new File(['abcdefghijklmn'],'movie.mp4',{type:'video/mp4',lastModified:12345}),meta={kind:'movie'};
const parts=new Map(),calls=new Map();let created=0,complete=0,shouldPause=true,transientFailure=true;
const first=new AbortController();
globalThis.fetch=async(url,options={})=>{
 const path=String(url),method=options.method||'GET';
 if(path==='/api/uploads'&&method==='POST'){created++;return Response.json({id:'u1',chunkBytes:4})}
 if(path==='/api/uploads/u1'&&method==='GET')return Response.json({id:'u1',chunkBytes:4,parts:[...parts.keys()],completed:false});
 const match=path.match(/\/parts\/(\d+)$/);if(match){const n=Number(match[1]);calls.set(n,(calls.get(n)||0)+1);if(n===2&&shouldPause){shouldPause=false;first.abort();throw new DOMException('pause','AbortError')}if(n===3&&transientFailure){transientFailure=false;return Response.json({error:'Retry once'},{status:503})}parts.set(n,new Uint8Array(await options.body.arrayBuffer()));return Response.json({ok:true})}
 if(path.endsWith('/complete')){complete++;return Response.json({id:'u1',name:file.name})}throw Error('Unexpected request '+path)
};
const progress=[];
await assert.rejects(uploadFile(file,meta,{signal:first.signal,onProgress:n=>progress.push(n)}));assert.equal(storage.size,1);assert.deepEqual([...parts.keys()],[1]);
const result=await uploadFile(file,meta,{signal:new AbortController().signal,onProgress:n=>progress.push(n)});assert.equal(result.id,'u1');assert.equal(created,1);assert.equal(complete,1);assert.equal(calls.get(1),1);assert.equal(calls.get(3),2);assert.equal(storage.size,0);assert.equal(progress.at(-1),file.size);
const reconstructed=Buffer.concat([...parts.keys()].sort((a,b)=>a-b).map(n=>parts.get(n)));assert.equal(reconstructed.toString(),'abcdefghijklmn');
console.log('Upload client checks passed: server-selected chunk size, pause, resume, transient retry, no duplicate first part, exact reconstruction and completed-session cleanup.');

// A delayed transport proves that the scheduler overlaps parts, drains all
// workers before completion and restores byte order after out-of-order replies.
storage.clear();
const big=new File(['0123456789'.repeat(20)],'parallel.mp4',{type:'video/mp4',lastModified:456});
let active=0,peak=0,finalized=false;const parallelParts=new Map();
globalThis.fetch=async(url,options={})=>{
 const path=String(url);
 if(path==='/api/uploads')return Response.json({id:'parallel',chunkBytes:10});
 const m=path.match(/parallel\/parts\/(\d+)/);if(m){active++;peak=Math.max(peak,active);const n=Number(m[1]);await new Promise(resolve=>setTimeout(resolve,4+(n%4)*4));parallelParts.set(n,new Uint8Array(await options.body.arrayBuffer()));active--;return Response.json({ok:true})}
 if(path.endsWith('/complete')){assert.equal(active,0);assert.equal(parallelParts.size,20);finalized=true;return Response.json({id:'parallel'})}throw Error(path)
};
const parallelProgress=[];
await uploadFile(big,meta,{signal:new AbortController().signal,onProgress:n=>parallelProgress.push(n),concurrency:4});
assert.equal(peak,4);assert.equal(finalized,true);assert.deepEqual(Buffer.concat([...parallelParts].sort((a,b)=>a[0]-b[0]).map(([,b])=>b)),Buffer.from(await big.arrayBuffer()));assert.ok(parallelProgress.every((n,i)=>n>=0&&n<=big.size&&(!i||n>=parallelProgress[i-1])));

// Browser transport: in-flight progress is visible, pausing cancels every
// active XHR, and selecting the same file resumes the stored session.
storage.clear();let xhrAborts=0,xhrCreated=0,xhrCompleted=0;const xhrParts=new Map();
class MockXHR{
 constructor(){this.upload={};this.status=0;this.stopped=false}
 open(method,url){this.url=url;this.method=method}
 setRequestHeader(){}
 send(blob){this.blob=blob;const part=Number(this.url.match(/parts\/(\d+)/)[1]);this.progressTimer=setTimeout(()=>{if(!this.stopped)this.upload.onprogress?.({loaded:Math.floor(blob.size/2),lengthComputable:true,total:blob.size})},2);this.doneTimer=setTimeout(async()=>{if(this.stopped)return;xhrParts.set(part,new Uint8Array(await blob.arrayBuffer()));this.status=200;this.responseText='{"ok":true}';this.onload?.()},15+part)}
 abort(){if(this.stopped)return;this.stopped=true;xhrAborts++;clearTimeout(this.progressTimer);clearTimeout(this.doneTimer);this.onabort?.()}
}
globalThis.XMLHttpRequest=MockXHR;
globalThis.fetch=async(url,options={})=>{const path=String(url);if(path==='/api/uploads'){xhrCreated++;return Response.json({id:'xhr',chunkBytes:4})}if(path==='/api/uploads/xhr')return Response.json({id:'xhr',chunkBytes:4,parts:[...xhrParts.keys()],completed:false});if(path.endsWith('/complete')){xhrCompleted++;assert.equal(xhrParts.size,4);return Response.json({id:'xhr'})}throw Error(path)};
const pause=new AbortController(),xhrProgress=[];
await assert.rejects(uploadFile(file,{kind:'music'},{signal:pause.signal,onProgress:n=>{xhrProgress.push(n);if(n>0&&n<file.size)pause.abort()},concurrency:4}));
assert.equal(xhrAborts,4);assert.equal(xhrCompleted,0);assert.equal(storage.size,1);assert.ok(xhrProgress.some(n=>n>0&&n<4));
await uploadFile(file,{kind:'music'},{signal:new AbortController().signal,onProgress:()=>{},concurrency:4});assert.equal(xhrCreated,1);assert.equal(xhrCompleted,1);assert.equal(storage.size,0);assert.equal(Buffer.concat([...xhrParts].sort((a,b)=>a[0]-b[0]).map(([,b])=>b)).toString(),'abcdefghijklmn');delete globalThis.XMLHttpRequest;
console.log('Parallel upload checks passed: four simultaneous parts, out-of-order replies, monotonic progress, browser XHR progress, cancellation of every active part, resume and exact reconstruction.');

// Turbo is a batch-wide ceiling, never 32 connections per selected file.
const {createUploadPool,uploadFiles,MAX_UPLOAD_TRANSFERS}=await import('../app/upload-scheduler.js');
storage.clear();active=0;peak=0;const turboParts=new Map();let nextUpload=0;
globalThis.fetch=async(url,options={})=>{
 const path=String(url);
 if(path==='/api/uploads')return Response.json({id:'turbo'+(++nextUpload),chunkBytes:10});
 const m=path.match(/(turbo\d+)\/parts\/(\d+)/);if(m){active++;peak=Math.max(peak,active);await new Promise(resolve=>setTimeout(resolve,5));if(options.signal.aborted){active--;throw new DOMException('pause','AbortError')}turboParts.set(m[1]+':'+m[2],new Uint8Array(await options.body.arrayBuffer()));active--;return Response.json({ok:true})}
 if(path.endsWith('/complete'))return Response.json({id:path.split('/')[3]});throw Error(path)
};
const turboFiles=Array.from({length:4},(_,i)=>new File(['abcdefghij'.repeat(40)],'turbo'+i+'.mp4',{lastModified:i}));
const batchProgress=[];const batchResults=await uploadFiles(turboFiles,(f,i)=>({kind:'series',episode:i+1}),{signal:new AbortController().signal,concurrency:600,upload:uploadFile,onProgress:n=>batchProgress.push(n)});
assert.equal(MAX_UPLOAD_TRANSFERS,32);assert.equal(peak,32);assert.equal(batchResults.length,4);assert.equal(nextUpload,4);assert.equal(turboParts.size,160);assert.equal(batchProgress.at(-1),1600);assert.ok(batchProgress.every((n,i)=>!i||n>=batchProgress[i-1]));
for(let i=1;i<=4;i++)assert.equal(Buffer.concat([...turboParts].filter(([key])=>key.startsWith('turbo'+i+':')).sort((a,b)=>Number(a[0].split(':')[1])-Number(b[0].split(':')[1])).map(([,bytes])=>bytes)).toString(),'abcdefghij'.repeat(40));
// The weighted budget prevents large chunks from multiplying memory use.
const weighted=createUploadPool(32,{maxBytes:20});active=0;peak=0;
await Promise.all(Array.from({length:12},()=>weighted.run(10,new AbortController().signal,async()=>{active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,2));active--})));
assert.equal(peak,2);
const throttled=createUploadPool(16);await assert.rejects(throttled.run(1,new AbortController().signal,async()=>{const error=new Error('busy');error.status=429;throw error}));assert.equal(throttled.limit,8);
for(let i=0;i<16;i++)await throttled.run(1,new AbortController().signal,async()=>{});assert.equal(throttled.limit,9);
// Aborting a full batch cancels both running and queued transfers before exit.
const batchAbort=new AbortController();let stopped=0;
await assert.rejects(uploadFiles(turboFiles,{}, {signal:batchAbort.signal,concurrency:16,upload:async(file,meta,{signal,pool})=>pool.run(1,signal,async()=>{await new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>{stopped++;reject(new DOMException('pause','AbortError'))},{once:true});setTimeout(()=>batchAbort.abort(),2)});})}));assert.equal(stopped,4);
console.log('Turbo upload checks passed: 32-transfer global ceiling for requested 600, four concurrent files, exact reconstruction, progress, memory budget, 429 backoff/recovery and batch cancellation.');
