import assert from 'node:assert/strict';
import {test} from 'node:test';
import {checkRomm,connectRomm,copyRom} from '../app/romm-client.js';

const prefix='http://192.168.1.42:8080/romm/api';
const rom={id:'rom-id',name:'Überraschung.sfc',size:10*1024*1024+1};
const source='/api/files/rom-id/content';
const etag='"rom-v1"';
const credentials={username:'André',password:'Testpasswort'};
const auth='Basic '+Buffer.from('André:Testpasswort').toString('base64');

test('login and copy a ROM directly with authenticated bounded requests',async t=>{
 const calls=[],ranges=[],progress=[];
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  const path=url.startsWith(prefix)?url.slice(prefix.length):url;
  calls.push([options.method||'GET',path]);
  if(url.startsWith(prefix)){
   assert.equal(options.headers.Authorization,auth);
   assert.equal(options.credentials,'omit');
   assert.equal(options.redirect,'error');
   assert.equal(options.targetAddressSpace,'local');
  }
  if(path==='/users/me')return Response.json({username:'André'});
  if(path==='/platforms')return Response.json([{id:7,name:'SNES',display_name:'Super Nintendo'}]);
  if(path===source){
   assert.ok(!options.headers?.Authorization);
   if(options.method==='HEAD')return new Response(null,{headers:{ETag:etag,'Content-Length':rom.size}});
   assert.equal(options.headers['If-Range'],etag);
   const range=options.headers.Range;
   ranges.push(range);
   const [start,end]=range.slice(6).split('-').map(Number);
   const size=end-start+1;
   return new Response(new Uint8Array(size).fill(start?17:99),{status:206,headers:{
    ETag:etag,'Content-Length':size,'Content-Range':'bytes '+start+'-'+end+'/'+rom.size,
   }});
  }
  if(path==='/roms/upload/start'){
   assert.equal(options.headers['X-Upload-Filename'],'%C3%9Cberraschung.sfc');
   assert.equal(options.headers['X-Upload-Platform'],'7');
   assert.equal(options.headers['X-Upload-Total-Chunks'],'2');
   assert.deepEqual(JSON.parse(options.body),{filename:rom.name,overwrite:false});
   return Response.json({upload_id:'test-id'});
  }
  if(path==='/roms/upload/test-id'){
   const first=options.headers['X-Chunk-Index']==='0';
   assert.equal(options.body.byteLength,first?10*1024*1024:1);
   assert.equal(new Uint8Array(options.body)[0],first?99:17);
   return new Response(null,{status:204});
  }
  assert.equal(path,'/roms/upload/test-id/complete');
  return Response.json({id:321});
 });
 const connection=await connectRomm(prefix.slice(0,-4),credentials);
 assert.deepEqual(connection.platforms,[{id:7,name:'Super Nintendo'}]);
 await copyRom(connection.request,rom,7,{onProgress:(bytes,total)=>progress.push([bytes,total])});
 assert.deepEqual(ranges,['bytes=0-10485759','bytes=10485760-10485760']);
 assert.deepEqual(progress,[[10485760,rom.size],[rom.size,rom.size]]);
 assert.deepEqual(calls,[
  ['GET','/users/me'],['GET','/platforms'],['HEAD',source],['POST','/roms/upload/start'],
  ['GET',source],['PUT','/roms/upload/test-id'],['GET',source],['PUT','/roms/upload/test-id'],['POST','/roms/upload/test-id/complete'],
 ]);
});

test('reject public HTTP and wrong credentials',async t=>{
 const fetch=t.mock.method(globalThis,'fetch',async(_url,options)=>{
  assert.equal(options.headers.Authorization,'Bearer rejected-test-token');
  return new Response(null,{status:401});
 });
 await assert.rejects(connectRomm('http://romm.example.com',credentials),/HTTPS/);
 assert.equal(fetch.mock.callCount(),0);
 await assert.rejects(connectRomm('https://romm.example.com',{token:'rejected-test-token'}),/Zugangsdaten abgelehnt/);
 assert.equal(fetch.mock.callCount(),1);
});

test('cancel the RomM upload if AndreDrive no longer serves the original bytes',async t=>{
 const paths=[];
 t.mock.method(globalThis,'fetch',async(_url,options)=>{
  assert.ok(!options.headers?.Authorization);
  return new Response(null,{headers:{ETag:etag,'Content-Length':rom.size}});
 });
 const request=async(path,options)=>{
  assert.equal(options.method,'POST');
  paths.push(path);
  return Response.json({upload_id:'test-id'});
 };
 await assert.rejects(copyRom(request,rom,7,{onProgress:()=>assert.fail()}),/erwarteten Dateiabschnitt/);
 assert.deepEqual(paths,['/roms/upload/start','/roms/upload/test-id/cancel']);
});

test('never use an unsafe upload ID as a request path',async t=>{
 t.mock.method(globalThis,'fetch',async()=>new Response(null,{headers:{ETag:etag,'Content-Length':rom.size}}));
 const paths=[];
 const request=async path=>{
  paths.push(path);
  return Response.json({upload_id:'..'});
 };
 await assert.rejects(copyRom(request,rom,7,{onProgress:()=>assert.fail()}),/Upload-ID/);
 assert.deepEqual(paths,['/roms/upload/start']);
});

test('normalize a local API docs URL and retry read-only slash variants without following redirects',async t=>{
 const calls=[];
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  assert.equal(options.redirect,'error');
  assert.equal(options.targetAddressSpace,'local');
  assert.equal(options.headers.Authorization,'Bearer test-token');
  calls.push(url);
  if(url===prefix+'/users/me')throw new TypeError('Redirect disallowed');
  if(url===prefix+'/users/me/')return Response.json({username:'Tester'});
  if(url===prefix+'/platforms')return new Response(null,{status:404});
  assert.equal(url,prefix+'/platforms/');
  return Response.json([{id:7,name:'SNES'}]);
 });
 const connection=await connectRomm(prefix+'/docs/',{token:'Bearer test-token'});
 assert.equal(connection.username,'Tester');
 assert.deepEqual(calls,['/users/me','/users/me/','/platforms','/platforms/'].map(path=>prefix+path));
});

test('recognize a reachable host that blocks the browser API without exposing the token to the probe',async t=>{
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  if(url.startsWith(prefix+'/users/me'))throw new TypeError('Failed to fetch');
  assert.equal(url,prefix+'/heartbeat');
  assert.equal(options.mode,'no-cors');
  assert.equal(options.credentials,'omit');
  assert.equal(options.headers,undefined);
  return new Response(null);
 });
 await assert.rejects(connectRomm(prefix,{token:'test-token'}),/Server antwortet.*ROMM_CORS_ALLOWED_ORIGINS/);
});

test('the connection check explains loopback addresses on phones',async t=>{
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  assert.equal(url,'http://localhost:8080/api/heartbeat');
  assert.equal(options.targetAddressSpace,'loopback');
  assert.equal(options.headers,undefined);
  throw new TypeError('Connection refused');
 });
 await assert.rejects(checkRomm('http://localhost:8080'),/localhost bezeichnet dieses Gerät/);
});
