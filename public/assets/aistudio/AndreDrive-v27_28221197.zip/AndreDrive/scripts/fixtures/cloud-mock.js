const state={oneDriveExists:true,torExists:true,oneDriveDeletes:0,torDeletes:0,failDelete:false,changed:false,includeBig:false,requests:0,torDownloadHost:"cdn.tb-cdn.cx",torRedirectHost:"edge.tb-cdn.earth"};const deviceScopes=new Map();
export function cloudTestState(){return {...state}}
export function configureCloudTest(input){Object.assign(state,input)}
let movieBytes;
export function configureCloudFixture(value){if(!movieBytes&&value)movieBytes=Uint8Array.from(atob(value),c=>c.charCodeAt(0))}
// Deterministic provider fixtures, installed only inside the integration tests.
export function installCloudMock(){const previous=globalThis.fetch;globalThis.fetch=async(input,options={})=>{
 const url=new URL(String(input));new Request(url,options);const headers=new Headers(options.headers),auth=headers.get('Authorization');
 if(url.hostname==='oauth2.googleapis.com'){
  const b=new URLSearchParams(String(options.body)),refresh=b.get('grant_type')==='refresh_token';
  if(b.get('client_id')!=='123-test.apps.googleusercontent.com'||b.get('client_secret')!=='GOCSPX-test-private'||auth||options.redirect!=='manual')throw Error('Invalid Google token exchange');
  if(refresh){
   if(b.get('refresh_token')!=='google-test-refresh')throw Error('Invalid Google refresh');
  }else{
   const verifier=b.get('code_verifier')||'',hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier));
   const challenge=btoa(String.fromCharCode(...new Uint8Array(hash))).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
   if(b.get('redirect_uri')!=='https://drive.test/api/cloud/google-drive/callback'||b.get('code')!=='code-'+challenge)throw Error('Missing Google PKCE or callback');
  }
  return Response.json({access_token:'google-test-access',...(refresh?{}:{refresh_token:'google-test-refresh'}),scope:'https://www.googleapis.com/auth/drive.readonly',expires_in:refresh?3600:1});
 }
 if(url.hostname==='www.googleapis.com'){
  state.requests++;
  if(auth!=='Bearer google-test-access'||options.redirect!=='manual'||options.method&&options.method!=='GET')throw Error('Invalid Google Drive request');
  const movie={id:'g-movie',name:'Google Film.mp4',mimeType:'video/mp4',size:'36',headRevisionId:state.googleChanged?'revision-2':'revision-1',capabilities:{canDownload:true}};
  if(url.pathname==='/drive/v3/about')return Response.json({user:{permissionId:state.googleOtherAccount?'other':'my-google',displayName:'Testkonto'}});
  if(url.pathname==='/drive/v3/files'){
   if(url.searchParams.get('pageToken')==='next+google'||url.searchParams.get('q').startsWith("'g-folder'"))return Response.json({files:[movie]});
   if(url.searchParams.get('q')!=="'root' in parents and trashed = false")throw Error('Invalid folder query');
   return Response.json({files:[{id:'g-folder',name:'Filme',mimeType:'application/vnd.google-apps.folder'},{id:'g-doc',name:'Google Docs',mimeType:'application/vnd.google-apps.document',capabilities:{canDownload:true}},movie],nextPageToken:'next+google'});
  }
  if(url.pathname==='/drive/v3/files/g-movie'){
   if(!url.searchParams.has('alt'))return Response.json(movie);
   if(state.googleRedirect)return new Response(null,{status:302,headers:{Location:'https://127.0.0.1/untrusted'}});
   const bytes=new TextEncoder().encode('0123456789abcdefghijklmnopqrstuvwxyz'),range=headers.get('Range');
   if(!range)return new Response(bytes);
   const [,first,last]=/^bytes=(\d+)-(\d+)$/.exec(range),start=Number(first),end=Number(last);
   return new Response(bytes.slice(start,end+1),{status:206,headers:{'Content-Length':String(end-start+1),'Content-Range':`bytes ${start}-${end}/36`}});
  }
  return Response.json({error:'missing'},{status:404});
 }
 if(url.hostname==='login.microsoftonline.com'){state.requests++;
  const b=new URLSearchParams(String(options.body));if(b.get('client_id')!=='11111111-1111-1111-1111-111111111111')return Response.json({error:'invalid_client'},{status:400});
  if(url.pathname.endsWith('/devicecode')){const code='private-device-code-'+deviceScopes.size;deviceScopes.set(code,b.get('scope'));return Response.json({device_code:code,user_code:'TEST-CODE',verification_uri:'https://microsoft.com/devicelogin',expires_in:900,interval:5})}
  const write=(deviceScopes.get(b.get('device_code'))||'').includes('ReadWrite')||b.get('refresh_token')==='graph-refresh-token-write';return Response.json({access_token:'graph-access-token',refresh_token:write?'graph-refresh-token-write':'graph-refresh-token',scope:write?'Files.ReadWrite offline_access':'Files.Read offline_access',expires_in:3600});
 }
 if(url.hostname==='graph.microsoft.com'){state.requests++;
  if(!['Bearer graph-access-token','Bearer expired-token'].includes(auth))return Response.json({error:'unauthorized'},{status:401});if(auth==='Bearer expired-token')return Response.json({error:'expired'},{status:401});
  const file={id:'file-1',name:'OneDrive Film.mp4',size:36,file:{mimeType:'video/mp4'},parentReference:{driveId:'drive-1'},lastModifiedDateTime:'2026-11-01T00:00:00Z',eTag:state.changed?'v2':'v1','@microsoft.graph.downloadUrl':'https://example.files.1drv.com/cloud.mp4?grant=secret'};
  if(url.pathname.endsWith('/root/children'))return Response.json({value:[{id:'folder-1',name:'Videos',folder:{},parentReference:{driveId:'drive-1'}},file],'@odata.nextLink':'https://graph.microsoft.com/v1.0/me/drive/root/children?$skiptoken=next'});
  if(url.pathname.endsWith('/items/folder-1/children'))return Response.json({value:[file]});
  if(url.pathname.endsWith('/items/file-1')){if(!state.oneDriveExists)return Response.json({error:'missing'},{status:404});if(options.method==='DELETE'){if(state.failDelete)return new Response(null,{status:403});if(headers.get('If-Match')!==file.eTag)return new Response(null,{status:412});state.oneDriveExists=false;state.oneDriveDeletes++;return new Response(null,{status:204})}return Response.json(file);}
  return Response.json({error:'missing'},{status:404});
 }
 if(url.hostname==='api.torbox.app'){state.requests++;
  if(url.pathname.endsWith('/requestdl')){if(url.searchParams.get('token')!=='torbox-test-token-12345'||auth)throw Error('Invalid TorBox download authorization');return Response.json({success:true,data:'https://'+state.torDownloadHost+'/' +(url.searchParams.get('file_id')==='2'?'fragmented.mp4':url.searchParams.get('file_id')==='3'?'big.bin':'cloud.mp4')+'?grant=secret'})}
  if(auth!=='Bearer torbox-test-token-12345')return Response.json({success:false},{status:401});
  if(url.pathname.endsWith('/user/me'))return Response.json({success:true,data:{id:1,email:'not-returned-to-client@test'}});
  if(url.pathname.includes('/control')){const b=JSON.parse(options.body);if(state.failDelete)return Response.json({success:false},{status:403});if(b.operation!=='delete'||b.all!==false||b.torrent_id!==12)throw Error('Unsafe TorBox deletion');state.torExists=false;state.torDeletes++;return Response.json({success:true})}
  if(url.pathname.endsWith('/mylist'))return Response.json({success:true,data:[...(state.torExists?[{id:12,name:'Cloud Film',download_finished:true,download_present:true,files:[{id:0,name:'Cloud Film/cloud.mp4',short_name:'cloud.mp4',size:36,mimetype:'video/mp4'},{id:1,name:'book.epub',size:36},...(movieBytes?[{id:2,name:'fragmented.mp4',size:movieBytes.length,mimetype:'video/mp4'}]:[])]}]:[]),...(state.includeBig?[{id:13,name:'Large source',download_finished:true,download_present:true,files:[{id:3,name:'big.bin',size:16*1024**2+17}]}]:[])]});
 }
 if(['cdn.torbox.app','cdn.tb-cdn.cx','edge.tb-cdn.earth','example.files.1drv.com'].includes(url.hostname)){state.requests++;
  if(auth||headers.has('Cookie')||headers.has('X-Emby-Token'))throw Error('Credentials leaked to CDN');
  if(url.hostname==='cdn.tb-cdn.cx'&&state.torRedirectHost)return new Response(null,{status:302,headers:{Location:'https://'+state.torRedirectHost+url.pathname+url.search}});
  if(url.searchParams.get('grant')==='expired')return new Response(null,{status:403});const bytes=url.pathname==='/big.bin'?new Uint8Array(16*1024**2+17).map((_,i)=>i*7%251):url.pathname==='/fragmented.mp4'?movieBytes:new TextEncoder().encode('0123456789abcdefghijklmnopqrstuvwxyz'),total=bytes.length,range=headers.get('Range');if(range){const m=/bytes=(\d+)-(\d*)/.exec(range);if(!m)throw Error('Unexpected range');const start=Number(m[1]),end=m[2]?Number(m[2]):total-1;return new Response(bytes.slice(start,end+1),{status:206,headers:{'Content-Length':String(end-start+1),'Content-Range':`bytes ${start}-${end}/${total}`,'Content-Type':'video/mp4'}})}
  return new Response(bytes,{headers:{'Content-Length':String(total),'Content-Type':'video/mp4'}});
 }
 return previous(input,options);
}}
