// Exercises the real Worker fetch API, without replacing global fetch.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import ts from 'typescript';
const require=createRequire(import.meta.resolve('wrangler/package.json'));
const {Miniflare}=require('miniflare');
const {fetch:nodeFetch,ProxyAgent}=require('undici');
// Managed environments provide HTTPS access through the session proxy.
const proxy=process.env.HTTPS_PROXY||process.env.HTTP_PROXY;
const dispatcher=proxy?new ProxyAgent(proxy):undefined;
const modules=[];
for(const name of ['jellyfin','catalog-metadata','file-operations','webdav','media-stream','fragmented-mp4']){
 const contents=ts.transpileModule(await readFile('lib/'+name+'.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replace(/from '(\.\/[^']+)'/g,(_,path)=>`from '${path}.js'`);
 modules.push({type:'ESModule',path:name+'.js',contents});
}
modules.push({type:'ESModule',path:'categories.js',contents:await readFile('lib/categories.js','utf8')});
const provider='https://image.tmdb.org/t/p/w500/vODOVn29fr0nLF9MVfpfKDcxuXF.jpg';
const mf=new Miniflare({modules:[{type:'ESModule',path:'image-test.js',contents:`import {fetchArtwork} from './jellyfin.js';export default {fetch(){return fetchArtwork(${JSON.stringify(provider)})}}`},...modules],compatibilityDate:'2026-05-15',...(dispatcher?{outboundService:async request=>{const r=await nodeFetch(request.url,{method:request.method,headers:Object.fromEntries(request.headers),redirect:'manual',dispatcher});return new Response(await r.arrayBuffer(),{status:r.status,headers:Object.fromEntries(r.headers)})}}:{})});
try{const response=await mf.dispatchFetch('https://test.local/');assert.equal(response.status,200);assert.ok(['image/jpeg','image/webp'].includes(response.headers.get('Content-Type')));const bytes=new Uint8Array(await response.arrayBuffer());assert.ok(bytes.length>1000);assert.ok(bytes[0]===255&&bytes[1]===216&&bytes[2]===255||new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP');console.log('Real Worker artwork fetch passed: HTTP 200, verified JPEG/WebP bytes from TMDB, no fetch mock.')}finally{await mf.dispose();await dispatcher?.close()}
