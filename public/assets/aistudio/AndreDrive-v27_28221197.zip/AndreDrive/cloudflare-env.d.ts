declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    METADATA_SETTINGS_KEY?: string;
    TMDB_API_READ_ACCESS_TOKEN?: string;
    BUCKET?: R2Bucket;
  }
}
