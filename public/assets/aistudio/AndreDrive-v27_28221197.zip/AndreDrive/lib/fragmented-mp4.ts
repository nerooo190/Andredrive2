import {fixedLengthBody,type RequestLifetime} from './media-stream';
type Box={type:string,start:number,end:number,data:number};
type Track={id:number,scale:number,video:boolean,defaultDuration:number};
export type FragmentIndex={version:1,size:number,etag:string,initLength:number,duration:number,segments:{offset:number,length:number,duration:number}[]};
const MAX_META=16*1024**2;
function boxes(bytes:Uint8Array,start=0,end=bytes.length):Box[]{
 const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),out:Box[]=[];
 for(let at=start;at+8<=end;){let size=v.getUint32(at),header=8;const type=String.fromCharCode(...bytes.slice(at+4,at+8));if(size===1){if(at+16>end)break;size=Number(v.getBigUint64(at+8));header=16}else if(size===0)size=end-at;if(!Number.isSafeInteger(size)||size<header||at+size>end)break;out.push({type,start:at,end:at+size,data:at+header});at+=size}
 return out;
}
const view=(b:Uint8Array)=>new DataView(b.buffer,b.byteOffset,b.byteLength);
const flags=(v:DataView,at:number)=>v.getUint32(at)&0xffffff;
async function read(bucket:R2Bucket,key:string,offset:number,length:number){if(length<0||length>MAX_META)throw Error('MP4-Index zu groß.');const o=await bucket.get(key,{range:{offset,length}});if(!o)throw Error('Videodatei nicht gefunden.');return new Uint8Array(await o.arrayBuffer())}
function parseTracks(init:Uint8Array):Track[]{
 const v=view(init),moov=boxes(init).find(b=>b.type==='moov');if(!moov)return [];
 const children=boxes(init,moov.data,moov.end),tracks:Track[]=[];
 for(const trak of children.filter(b=>b.type==='trak')){
  const c=boxes(init,trak.data,trak.end),tkhd=c.find(b=>b.type==='tkhd'),mdia=c.find(b=>b.type==='mdia');if(!tkhd||!mdia)continue;
  const m=boxes(init,mdia.data,mdia.end),mdhd=m.find(b=>b.type==='mdhd'),hdlr=m.find(b=>b.type==='hdlr');if(!mdhd||!hdlr)continue;
  const id=v.getUint32(tkhd.data+(init[tkhd.data]===1?20:12)),scale=v.getUint32(mdhd.data+(init[mdhd.data]===1?20:12));
  const handler=String.fromCharCode(...init.slice(hdlr.data+8,hdlr.data+12));if(scale)tracks.push({id,scale,video:handler==='vide',defaultDuration:0});
 }
 const mvex=children.find(b=>b.type==='mvex');if(mvex)for(const trex of boxes(init,mvex.data,mvex.end).filter(b=>b.type==='trex')){const track=tracks.find(t=>t.id===v.getUint32(trex.data+4));if(track)track.defaultDuration=v.getUint32(trex.data+12)}
 return tracks;
}
function fragmentDuration(data:Uint8Array,track:Track){
 const v=view(data),moof=boxes(data).find(b=>b.type==='moof');if(!moof)return 0;
 for(const traf of boxes(data,moof.data,moof.end).filter(b=>b.type==='traf')){
  const children=boxes(data,traf.data,traf.end),tfhd=children.find(b=>b.type==='tfhd');if(!tfhd||v.getUint32(tfhd.data+4)!==track.id)continue;
  const f=flags(v,tfhd.data);let pos=tfhd.data+8;if(f&1)pos+=8;if(f&2)pos+=4;const defaultDuration=f&8?v.getUint32(pos):track.defaultDuration;
  let ticks=0;
  for(const trun of children.filter(b=>b.type==='trun')){
   const f=flags(v,trun.data),count=v.getUint32(trun.data+4);let pos=trun.data+8;if(f&1)pos+=4;if(f&4)pos+=4;
   if(!(f&0x100)){ticks+=count*defaultDuration;continue}
   for(let i=0;i<count;i++){if(pos+4>trun.end)throw Error('Ungültige MP4-Fragmente.');ticks+=v.getUint32(pos);pos+=4;if(f&0x200)pos+=4;if(f&0x400)pos+=4;if(f&0x800)pos+=4}
  }
  return ticks/track.scale;
 }
 return 0;
}
export async function fragmentIndex(bucket:R2Bucket,key:string,head:R2Object):Promise<FragmentIndex|null>{
 if(head.size<32)return null;
 const cacheKey=`stream-index/v1/${key}/${head.etag}.json`,cached=await bucket.get(cacheKey);
 if(cached){const index=await cached.json<FragmentIndex>();if(index.version===1&&index.size===head.size&&index.etag===head.etag)return index}
 // ffmpeg's fragmented MP4 footer gives the random access table's exact size.
 const tail=await read(bucket,key,head.size-16,16),tv=view(tail);
 if(tv.getUint32(0)!==16||String.fromCharCode(...tail.slice(4,8))!=='mfro')return null;
 const mfraSize=tv.getUint32(12);if(mfraSize<24||mfraSize>MAX_META||mfraSize>head.size)return null;
 const mfraOffset=head.size-mfraSize,mfra=await read(bucket,key,mfraOffset,mfraSize),mv=view(mfra),root=boxes(mfra).find(b=>b.type==='mfra');if(!root)return null;
 // Read only the initial metadata; the first moof marks the end of the init segment.
 let at=0,initLength=0;
 for(let i=0;i<32&&at+8<head.size;i++){
  const b=await read(bucket,key,at,Math.min(16,head.size-at)),v=view(b);let length=v.getUint32(0);const type=String.fromCharCode(...b.slice(4,8));if(type==='moof'){initLength=at;break}if(length===1)length=Number(v.getBigUint64(8));if(!Number.isSafeInteger(length)||length<8||at+length>MAX_META)return null;at+=length;
 }
 if(!initLength||initLength>MAX_META)return null;
 const init=await read(bucket,key,0,initLength),tracks=parseTracks(init),track=tracks.find(t=>t.video)||tracks[0];if(!track)return null;
 const tfra=boxes(mfra,root.data,root.end).find(b=>b.type==='tfra'&&mv.getUint32(b.data+4)===track.id);if(!tfra)return null;
 const version=mfra[tfra.data],field=mv.getUint32(tfra.data+8),counterBytes=((field>>4)&3)+1+((field>>2)&3)+1+(field&3)+1,count=mv.getUint32(tfra.data+12);
 if(count===0||count>100000)return null;
 let pos=tfra.data+16;const entries:{offset:number,time:number}[]=[];
 for(let i=0;i<count;i++){
  const width=version===1?8:4;if(pos+width*2+counterBytes>tfra.end)return null;
  const time=width===8?Number(mv.getBigUint64(pos)):mv.getUint32(pos);pos+=width;
  const offset=width===8?Number(mv.getBigUint64(pos)):mv.getUint32(pos);pos+=width+counterBytes;
  if(!Number.isSafeInteger(offset)||offset<initLength||offset>=mfraOffset)return null;
  if(entries.at(-1)?.offset!==offset)entries.push({offset,time:time/track.scale});
 }
 const last=entries.at(-1)!;const lastHeader=await read(bucket,key,last.offset,Math.min(256*1024,mfraOffset-last.offset));
 const lastDuration=fragmentDuration(lastHeader,track)||(entries.length>1?last.time-entries[entries.length-2].time:0);
 const segments=entries.map((e,i)=>({offset:e.offset,length:(entries[i+1]?.offset??mfraOffset)-e.offset,duration:entries[i+1]?entries[i+1].time-e.time:lastDuration}));
 if(segments.some(s=>s.length<=0||s.duration<=0||!Number.isFinite(s.duration)))return null;
 const index:FragmentIndex={version:1,size:head.size,etag:head.etag,initLength,duration:segments.reduce((n,s)=>n+s.duration,0),segments};
 await bucket.put(cacheKey,JSON.stringify(index),{httpMetadata:{contentType:'application/json'}});
 return index;
}
// HLS segments are independent resources: convert absolute tfhd data pointers
// into offsets relative to this segment while leaving sample bytes untouched.
export function rebaseFragment(bytes:Uint8Array,sourceOffset:number):Uint8Array{
 const copy=bytes.slice(),v=view(copy);
 for(const moof of boxes(copy).filter(b=>b.type==='moof'))for(const traf of boxes(copy,moof.data,moof.end).filter(b=>b.type==='traf')){
  const children=boxes(copy,traf.data,traf.end),tfhd=children.find(b=>b.type==='tfhd');
  if(tfhd&&(flags(v,tfhd.data)&1)){
   const oldBase=Number(v.getBigUint64(tfhd.data+8)),delta=oldBase-(sourceOffset+moof.start);
   for(const trun of children.filter(b=>b.type==='trun'))if(flags(v,trun.data)&1){const offset=v.getInt32(trun.data+8)+delta;if(!Number.isSafeInteger(offset)||offset< -2147483648||offset>2147483647)throw Error('Ungültiger Fragmentzeiger.');v.setInt32(trun.data+8,offset)}
   // MSE/HLS requires movie-fragment-relative addressing. Shorten tfhd by
   // eight bytes and put a valid free box in the gap, preserving all offsets.
   v.setUint32(tfhd.data,(v.getUint32(tfhd.data)&~1)|0x020000);
   copy.copyWithin(tfhd.data+8,tfhd.data+16,tfhd.end);
   v.setUint32(tfhd.start,tfhd.end-tfhd.start-8);
   v.setUint32(tfhd.end-8,8);copy.set([102,114,101,101],tfhd.end-4);
  }
 }
 return copy;
}
export async function fragmentBody(bucket:R2Bucket,key:string,offset:number,length:number,lifetime?:RequestLifetime){
 if(length<=MAX_META){const bytes=await read(bucket,key,offset,length);return new Response(rebaseFragment(bytes,offset).buffer as ArrayBuffer).body!}
 // Rare very large fragments: patch the moof header and stream mdat without buffering it.
 const header=await read(bucket,key,offset,16),v=view(header),moofLength=v.getUint32(0)===1?Number(v.getBigUint64(8)):v.getUint32(0);
 if(String.fromCharCode(...header.slice(4,8))!=='moof'||moofLength>MAX_META)throw Error('Fragmentkopf nicht unterstützt.');
 const prefix=rebaseFragment(await read(bucket,key,offset,moofLength),offset),rest=await bucket.get(key,{range:{offset:offset+moofLength,length:length-moofLength}});if(!rest)throw Error('Video nicht gefunden.');const reader=rest.body.getReader();let first=true;
 const stream=new ReadableStream<Uint8Array>({async pull(c){if(first){first=false;c.enqueue(prefix);return}const next=await reader.read();if(next.done)c.close();else c.enqueue(next.value)},cancel(reason){return reader.cancel(reason)}});
 return fixedLengthBody(stream,length,lifetime);
}
export function hlsManifest(index:FragmentIndex,base:string){
 const lines=['#EXTM3U','#EXT-X-VERSION:7','#EXT-X-PLAYLIST-TYPE:VOD',`#EXT-X-TARGETDURATION:${Math.ceil(index.segments.reduce((n,s)=>Math.max(n,s.duration),0))}`,'#EXT-X-MEDIA-SEQUENCE:0',`#EXT-X-MAP:URI="${base}/init.mp4"`];
 index.segments.forEach((segment,i)=>lines.push(`#EXTINF:${segment.duration.toFixed(6)},`,`${base}/segment${i}.m4s`));lines.push('#EXT-X-ENDLIST');return lines.join('\n')+'\n';
}
