export type CatalogMetadata={title:string,author?:string,narrator?:string,original_title:string,year:string,plot:string,genres:string,runtime_minutes:number,rating:number,cast:string,people?:{id:string,name:string,role:string,profile_url:string}[],people_source?:string,director:string,country:string,language:string,poster_url:string,poster_source:string,backdrop_url:string,tmdb_id:string,imdb_id:string,episode_title:string,episode_image_url:string,tvg_id:string,group_title:string,source:string};
const text=(v:unknown,n:number)=>String(v??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').trim().slice(0,n);
export function safeImageUrl(value:unknown){const s=text(value,2000);if(!s)return '';try{const u=new URL(s);if(u.protocol!=='https:'||u.username||u.password||u.hostname==='localhost'||u.hostname.endsWith('.local')||/^[\d.]+$/.test(u.hostname)||u.hostname.includes(':'))throw Error();return u.href}catch{throw Error('Cover-Links müssen öffentliche HTTPS-Adressen sein.')}}
export function normalizeMetadata(input:Record<string,unknown>):CatalogMetadata{
 return {people:Array.isArray(input.people)?input.people.slice(0,30).filter((p:any)=>p&&p.name).map((p:any)=>({id:/^\d+$/.test(String(p.id||''))?String(p.id):'',name:text(p.name,200),role:text(p.role,300),profile_url:safeImageUrl(p.profile_url)})):[],people_source:text(input.people_source,100),title:text(input.title,250),...(input.author!==undefined?{author:text(input.author,200)}:{}),...(input.narrator!==undefined?{narrator:text(input.narrator,200)}:{}),original_title:text(input.original_title,250),year:/^\d{4}$/.test(String(input.year||''))?String(input.year):'',plot:text(input.plot,8000),genres:text(Array.isArray(input.genres)?input.genres.join(', '):input.genres,500),runtime_minutes:Math.max(0,Math.min(10000,Number(input.runtime_minutes)||0)),rating:Math.round(Math.max(0,Math.min(10,Number(input.rating)||0))*10)/10,cast:text(Array.isArray(input.cast)?input.cast.join(', '):input.cast,1500),director:text(input.director,500),country:text(input.country,300),language:text(input.language,100),poster_url:safeImageUrl(input.poster_url),poster_source:input.poster_source==='upload'?'upload':'url',backdrop_url:safeImageUrl(input.backdrop_url),tmdb_id:/^\d+$/.test(String(input.tmdb_id||''))?String(input.tmdb_id):'',imdb_id:/^tt\d+$/.test(String(input.imdb_id||''))?String(input.imdb_id):'',episode_title:text(input.episode_title,250),episode_image_url:safeImageUrl(input.episode_image_url),tvg_id:text(input.tvg_id,200),group_title:text(input.group_title,300),source:input.source==='tmdb'?'tmdb':'manual'};
}
function keyBytes(key:string){if(!/^[a-f\d]{64}$/i.test(key))throw Error('Geschützte TMDB-Einstellungen sind nicht verfügbar.');return Uint8Array.from(key.match(/../g)!,x=>parseInt(x,16))}
const encode=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes));
const decode=(s:string)=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
export async function sealToken(token:string,key:string,userId:string){const iv=crypto.getRandomValues(new Uint8Array(12)),aes=await crypto.subtle.importKey('raw',keyBytes(key),'AES-GCM',false,['encrypt']);const bytes=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(userId)},aes,new TextEncoder().encode(token));return encode(iv)+'.'+encode(new Uint8Array(bytes))}
export async function openToken(value:string,key:string,userId:string){const [iv,data]=value.split('.'),aes=await crypto.subtle.importKey('raw',keyBytes(key),'AES-GCM',false,['decrypt']);const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(iv),additionalData:new TextEncoder().encode(userId)},aes,decode(data));return new TextDecoder().decode(bytes)}
export class TmdbError extends Error{constructor(public status:number,message:string){super(message)}}
export async function tmdbGet(path:string,query:Record<string,string>,token:string){
 if(!/^\/(configuration|search\/(movie|tv)|(movie|tv)\/\d+(\/season\/\d+(\/episode\/\d+)?)?)$/.test(path))throw new TmdbError(400,'Ungültige TMDB-Anfrage.');
 const url=new URL('https://api.themoviedb.org/3'+path);for(const [k,v] of Object.entries(query))if(v)url.searchParams.set(k,v);
 const headers:Record<string,string>={Accept:'application/json'};if(/^[a-f\d]{32}$/i.test(token))url.searchParams.set('api_key',token);else headers.Authorization='Bearer '+token;
 let response:Response;try{response=await fetch(url,{headers,signal:AbortSignal.timeout(12000)})}catch{throw new TmdbError(502,'TMDB ist momentan nicht erreichbar. Manuelle Metadaten bleiben verfügbar.')}
 if(!response.ok)throw new TmdbError(response.status===401?401:response.status===404?404:response.status===429?429:502,response.status===401?'TMDB-Schlüssel ungültig. Bitte in den Einstellungen prüfen.':response.status===404?'Der TMDB-Eintrag wurde nicht gefunden.':response.status===429?'TMDB-Anfragelimit erreicht. Bitte etwas später erneut versuchen.':'TMDB-Daten konnten nicht geladen werden.');
 return await response.json() as Record<string,any>;
}
export const tmdbPeople=(data:Record<string,any>)=>(data.credits?.cast||[]).slice(0,30).map((x:any)=>({id:String(x.id||''),name:x.name,role:x.character||'',profile_url:typeof x.profile_path==='string'&&/^\/[\w.-]+$/.test(x.profile_path)?'https://image.tmdb.org/t/p/w185'+x.profile_path:''}));
const tmdbLanguage={language:'de-DE'};
export const tmdbTitle=(kind:'movie'|'series',id:string,token:string)=>tmdbGet('/'+(kind==='series'?'tv':'movie')+'/'+id,{...tmdbLanguage,append_to_response:'credits,external_ids'},token);
export function tmdbMetadata(kind:'movie'|'series',id:string,data:Record<string,any>,ep?:Record<string,any>|null){
 const image=(path:unknown,width='w500')=>typeof path==='string'&&/^\/[\w.-]+$/.test(path)?`https://image.tmdb.org/t/p/${width}${path}`:'';
 const metadata=normalizeMetadata({title:kind==='series'?data.name:data.title,original_title:data.original_title||data.original_name,year:(ep?.air_date||data.release_date||data.first_air_date||'').slice(0,4),plot:ep?.overview||data.overview,genres:(data.genres||[]).map((g:any)=>g.name),runtime_minutes:ep?.runtime||data.runtime||data.episode_run_time?.[0]||0,rating:ep?.vote_average||data.vote_average,cast:(data.credits?.cast||[]).slice(0,12).map((x:any)=>x.name),people:tmdbPeople(data),people_source:kind+':'+id,director:(data.credits?.crew||[]).filter((x:any)=>x.job==='Director').map((x:any)=>x.name).join(', ')||(data.created_by||[]).map((x:any)=>x.name).join(', '),country:(data.production_countries||[]).map((x:any)=>x.name).join(', '),language:data.original_language,poster_url:image(data.poster_path),backdrop_url:image(data.backdrop_path,'w1280'),tmdb_id:id,imdb_id:data.imdb_id||data.external_ids?.imdb_id,episode_title:ep?.name,episode_image_url:image(ep?.still_path,'w780'),source:'tmdb'});
 return metadata;
}
export async function tmdbDetails(kind:'movie'|'series',id:string,season:number,episode:number,token:string){
 const [data,ep]=await Promise.all([tmdbTitle(kind,id,token),kind==='series'?tmdbGet(`/tv/${id}/season/${season}/episode/${episode}`,tmdbLanguage,token):null]);
 return {kind,series:kind==='series'?data.name:'',season,episode,metadata:tmdbMetadata(kind,id,data,ep)};
}

const matchTitle=(value:string)=>value.normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function tmdbScrapeInput(file:Record<string,any>){
 const metadata=file.metadata||{},base=String(file.name||'').replace(/\.[^.]+$/,'').replace(/[._]/g,' ');
 const marker=file.kind==='series'?/\b(?:S(\d{1,4})[ ._-]*E(\d{1,4})|(\d{1,4})x(\d{1,4}))(?=$|[^\d])/i.exec(base):null;
 const filename=marker?base.slice(0,marker.index):base;
 const trailingYear=/\b(?:19|20)\d{2}\b(?=[ )\]-]*(?:$|\b(?:2160p|1080p|720p|480p|4k|UHD|BluRay|WEB|HDR|German|DL)\b))/i.exec(filename);
 const yearMatch=trailingYear?.index?trailingYear:null;
 const release=filename.search(/\b(?:2160p|1080p|720p|480p|4k|UHD|BluRay|WEB[- ]?(?:DL|Rip)|HDR|x26[45]|h26[45]|German|HEVC)\b/i);
 const guess=filename.slice(0,yearMatch?.index??(release>=0?release:undefined)).replace(/[()\[\] -]+$/g,'').trim();
 const preferred=String((file.kind==='series'&&file.series)||metadata.title||'').trim().replace(/[._]/g,' ');
 const titledYear=/\s*[([]((?:19|20)\d{2})[)\]]\s*$/.exec(preferred);
 const fromFilename=!!marker&&(!preferred||matchTitle(preferred)===matchTitle(base)||/\b(?:S\d{1,4}\s*E\d{1,4}|\d{1,4}x\d{1,4})\b/i.test(preferred));
 const query=(fromFilename?guess:preferred.slice(0,titledYear?.index)||guess).trim().slice(0,200);
 const year=String(titledYear?.[1]||file.kind==='movie'&&metadata.year||yearMatch?.[0]||'');
 const inferred=!!marker&&!metadata.tmdb_id&&!metadata.episode_title&&Number(file.season)===1&&Number(file.episode)===1;
 const id=/^\d+$/.test(String(metadata.tmdb_id||''))?String(metadata.tmdb_id):'';
 return {id,query,key:matchTitle(query),year,season:inferred?Number(marker[1]||marker[3]):Number(file.season),episode:inferred?Number(marker[2]||marker[4]):Number(file.episode),inferred};
}

type ScrapeInput=ReturnType<typeof tmdbScrapeInput>;
const episodeCoordinatesValid=(info:ScrapeInput)=>Number.isInteger(info.season)&&info.season>=0&&Number.isInteger(info.episode)&&info.episode>=1;
export function tmdbScraper(token:string,seriesEvidence:(info:ScrapeInput)=>Promise<ScrapeInput[]> = async()=>[]){
 const cached=new Map<string,Promise<any>>();
 const once=<T>(key:string,fn:()=>Promise<T>):Promise<T>=>{
  if(!cached.has(key))cached.set(key,fn());
  return cached.get(key)!;
 };
 const episodesFor=(id:string,season:number)=>once('season:'+id+':'+season,async()=>{
  try{
   const data=await tmdbGet(`/tv/${id}/season/${season}`,tmdbLanguage,token);
   return new Map<number,Record<string,any>>((data.episodes||[]).map((episode:any)=>[episode.episode_number,episode]));
  }catch(e){
   if(e instanceof TmdbError&&e.status===404)return new Map<number,Record<string,any>>();
   throw e;
  }
 });
 async function chooseSeries(matches:string[],info:ScrapeInput){
  const peers=await seriesEvidence(info),known=new Set(peers.map(p=>p.id).filter(id=>matches.includes(id)));
  const ambiguous=()=>new TmdbError(409,'Mehrere gleichnamige Serien passen. Ergänze das Erscheinungsjahr in Klammern im Serientitel oder wähle einen TMDB-Treffer in den Dateidaten.');
  if(known.size>1||matches.length>6||new Set(peers.map(peer=>peer.year).filter(Boolean)).size>1)throw ambiguous();
  const wanted=new Map<number,Set<number>>();
  for(const p of [info,...peers]){
   if(!episodeCoordinatesValid(p))continue;
   if(!wanted.has(p.season))wanted.set(p.season,new Set());
   wanted.get(p.season)!.add(p.episode);
  }
  if(wanted.size>12)throw ambiguous();
  const compatible:string[]=[];
  const seasons=[...wanted].sort((a,b)=>b[0]-a[0]);
  const candidates=known.size?[...known]:matches;
  for(const id of candidates){
   let fits=true;
   for(const [season,numbers] of seasons){
    const episodes=await episodesFor(id,season);
    if([...numbers].some(number=>!episodes.has(number))){fits=false;break}
   }
   if(fits)compatible.push(id);
  }
  if(!compatible.length)throw new TmdbError(409,'Keine der gleichnamigen Serien enthält alle vorhandenen Staffel- und Folgennummern. Prüfe die Nummern oder wähle den TMDB-Titel in den Dateidaten.');
  if(compatible.length>1)throw ambiguous();
  return compatible[0];
 }
 return async(file:Record<string,any>)=>{
  const info=tmdbScrapeInput(file),kind=file.kind as 'movie'|'series',type=kind==='series'?'tv':'movie';
  if(kind==='series'&&!episodeCoordinatesValid(info))throw new TmdbError(404,'Staffel oder Episodennummer fehlt oder ist ungültig.');
  if(!info.id&&info.key.length<2)throw new TmdbError(404,'Kein verwendbarer Titel für die TMDB-Suche gefunden.');
  const id=info.id||await once('match:'+type+':'+info.key+':'+info.year,async()=>{
   const data=await tmdbGet('/search/'+type,{...tmdbLanguage,include_adult:'false',query:info.query,[type==='tv'?'first_air_date_year':'year']:info.year},token);
   const matches=new Set<string>();
   for(const hit of data.results||[]){
    if(!/^\d+$/.test(String(hit.id||'')))continue;
    if(info.year&&String(hit.release_date||hit.first_air_date||'').slice(0,4)!==info.year)continue;
    if([hit.title,hit.original_title,hit.name,hit.original_name].some(value=>matchTitle(String(value||''))===info.key))matches.add(String(hit.id));
   }
   if(!matches.size)throw new TmdbError(404,'Kein passender TMDB-Titel für „'+info.query+'“ gefunden.');
   if(matches.size===1)return [...matches][0];
   if(kind==='series')return chooseSeries([...matches],info);
   throw new TmdbError(409,'Mehrere gleichnamige Filme gefunden. Ergänze das Erscheinungsjahr in den Dateidaten.');
  });
  const ep=kind==='series'?(await episodesFor(id,info.season)).get(info.episode):null;
  if(kind==='series'&&!ep)throw new TmdbError(404,'Bei TMDB fehlt Staffel '+info.season+', Folge '+info.episode+' für den gewählten Titel.');
  const title=await once('title:'+type+':'+id,()=>tmdbTitle(kind,id,token));
  return {...info,series:kind==='series'?title.name:'',metadata:tmdbMetadata(kind,id,title,ep)};
 };
}

const clean=(value:unknown)=>String(value??'').replace(/[\r\n"<>\x00-\x1f]/g,' ').trim();
export function m3uMetadata(file:Record<string,any>,token:string,origin:string,duration:number){
 const m=file.metadata||{},base=m.title||file.name.replace(/\.[^.]+$/,''),series=file.series||m.title||base;
 const title=file.kind==='series'?`${series} S${String(file.season).padStart(2,'0')}E${String(file.episode).padStart(2,'0')}${m.episode_title?' · '+m.episode_title:''}`:`${base}${m.year?' ('+m.year+')':''}`;
 const logo=(file.kind==='series'&&m.episode_image_url)||(m.poster_source==='upload'?`${origin}/thumb/${token}/${file.id}`:m.poster_url)||'';
 const group=m.group_title||(file.kind==='series'?'Serien | '+series:'Filme'+(m.genres?' | '+m.genres.split(',')[0].trim():''));
 const attrs:Record<string,unknown>={'tvg-id':m.tvg_id||m.imdb_id||(m.tmdb_id?`tmdb-${file.kind}-${m.tmdb_id}`:''),'tvg-name':title,'tvg-logo':logo,'group-title':group,'tvg-type':file.kind,type:file.kind,'tvg-tmdb':m.tmdb_id,'tvg-imdb':m.imdb_id,'tvg-serie':file.kind==='series'?series:'','serie-title':file.kind==='series'?series:'','tvg-season':file.kind==='series'?file.season:'','tvg-episode':file.kind==='series'?file.episode:'','tmdb-id':m.tmdb_id,'imdb-id':m.imdb_id,year:m.year,genre:m.genres,plot:m.plot,rating:m.rating||'',director:m.director,cast:m.cast,country:m.country,language:m.language,series:file.kind==='series'?series:'',season:file.kind==='series'?file.season:'',episode:file.kind==='series'?file.episode:'','episode-title':m.episode_title};
 return `#EXTINF:${duration>0?duration.toFixed(3):'-1'} ${Object.entries(attrs).filter(([,v])=>v!==''&&v!=null).map(([k,v])=>`${k}="${clean(v)}"`).join(' ')},${clean(title)}`;
}
export function imageMime(bytes:Uint8Array){if(bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)return 'image/jpeg';if(bytes.length>=8&&bytes.slice(0,8).every((b,i)=>b===[137,80,78,71,13,10,26,10][i]))return 'image/png';const s=new TextDecoder().decode(bytes.slice(0,12));if(s.startsWith('GIF87a')||s.startsWith('GIF89a'))return 'image/gif';if(s.startsWith('RIFF')&&s.slice(8)==='WEBP')return 'image/webp';return null}
