import {DriveError,newId,driveStorage} from './file-operations';
import {MAX_FILE_BYTES,UPLOAD_CHUNK_BYTES} from './upload-limits';
import {BUILTIN_CATEGORIES,inferCategory} from './categories';
type Row=Record<string,any>;
type Services={connection:(id:string,owner:string)=>Promise<Row>,resolveItem:(c:Row,ref:Row)=>Promise<Row>,canMove:(c:Row)=>Promise<boolean>,allTorFiles:(c:Row,ref:Row)=>Promise<Row[]>,sourceBucket:()=>R2Bucket,deleteSource:(c:Row,item:Row)=>Promise<void>};
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'private, no-store'}});
const finished=new Set(['done','kept','cancelled']);
// Hash while forwarding bytes with backpressure; even 100 GB transfers never
// accumulate a movie (or an entire part) in the Worker's memory.
async function checkedStream(body:ReadableStream<Uint8Array>,expected:number,upload?:((stream:ReadableStream<Uint8Array>)=>Promise<R2UploadedPart>)){
 const Digest=(crypto as Crypto&{DigestStream:new(algorithm:string)=>WritableStream<Uint8Array>&{digest:Promise<ArrayBuffer>}}).DigestStream;
 const digest=new Digest('SHA-256'),writer=digest.getWriter(),controller=new AbortController();let size=0;
 const digestResult=digest.digest.then(value=>Array.from(new Uint8Array(value),b=>b.toString(16).padStart(2,'0')).join(''),()=>null);
 const fixed=upload?new FixedLengthStream(expected):null,deadline=setTimeout(()=>controller.abort(),180000);
 const validator=new TransformStream<Uint8Array,Uint8Array>({async transform(bytes,c){size+=bytes.byteLength;if(size>expected)throw new DriveError(502,'Zu viele Daten im Cloud-Abschnitt.');await writer.write(bytes);c.enqueue(bytes)},async flush(){if(size!==expected)throw new DriveError(502,'Unvollständiger Cloud-Abschnitt. Die Quelle bleibt erhalten.');await writer.close()}});
 const pump=body.pipeThrough(validator).pipeTo(fixed?fixed.writable:new WritableStream({write(){}}),{signal:controller.signal}).then(()=>null,error=>error);
 try{const result=upload?await upload(fixed!.readable):null,error=await pump;if(error)throw error;const sha256=await digestResult;if(!sha256)throw new DriveError(502,'Prüfsumme konnte nicht berechnet werden.');return {sha256,result}}
 catch(e){controller.abort();await writer.abort().catch(()=>{});await pump;throw e}finally{clearTimeout(deadline)}
}
export function cloudTransfers(db:D1Database,bucket:R2Bucket,services:Services){
 const one=async(sql:string,...args:any[])=>db.prepare(sql).bind(...args).first<Row>();
 const all=async(sql:string,...args:any[])=>(await db.prepare(sql).bind(...args).all<Row>()).results;
 const run=(sql:string,...args:any[])=>db.prepare(sql).bind(...args).run();
 const object=(j:Row)=>`files/${j.user_id}/${j.id}`;
 const stats=(id:string)=>one('SELECT COUNT(*) AS count,COALESCE(SUM(size),0) AS copied,COALESCE(SUM(CASE WHEN verified=1 THEN size ELSE 0 END),0) AS verified FROM cloud_transfer_parts WHERE transfer_id=?',id);
 const parts=(id:string)=>all('SELECT * FROM cloud_transfer_parts WHERE transfer_id=? ORDER BY part',id);
 const job=async(id:string,owner:string)=>await one('SELECT * FROM cloud_transfers WHERE id=? AND user_id=?',id,owner)??Promise.reject(new DriveError(404,'Übertragung nicht gefunden.'));
 const summary=async(j:Row)=>{const d=JSON.parse(j.data),p=(await stats(j.id))!;return {id:j.id,connectionId:j.connection_id,operation:j.operation,status:j.status,name:d.file.name,size:d.file.size,copied:p.copied,verified:p.verified,error:j.error,created:j.created,busy:j.lease_until>Date.now(),fileId:['source_pending','done','kept'].includes(j.status)?j.id:null}};
 const lease=async(j:Row,transfer=false)=>{const token=newId(),now=Date.now();const locked=await db.prepare('UPDATE cloud_transfers SET lease_until=?,lease_token=? WHERE id=? AND user_id=? AND lease_until<? AND (?=0 OR (SELECT COUNT(*) FROM cloud_transfers WHERE user_id=? AND lease_until>?)<32) RETURNING id').bind(now+360000,token,j.id,j.user_id,now,transfer?1:0,j.user_id,now).first();if(!locked){const current=await job(j.id,j.user_id);if(current.lease_until>now)throw new DriveError(409,'Ein Übertragungsabschnitt läuft bereits. Bitte kurz warten.');throw new DriveError(429,'Es laufen bereits 32 Cloud-Übertragungen. Bitte kurz warten.')}return token};
 const assertLease=async(j:Row,token:string)=>{if(!await one('SELECT id FROM cloud_transfers WHERE id=? AND user_id=? AND lease_token=?',j.id,j.user_id,token))throw new DriveError(409,'Übertragung wurde zwischenzeitlich übernommen.')};
 const unchanged=(a:Row,b:Row)=>a.key===b.key&&a.size===b.size&&(!a.version||a.version===b.version);
 async function verifyLocal(j:Row){const d=JSON.parse(j.data),head=await bucket.head(object(j));if(!head||head.size!==d.file.size)throw new DriveError(409,'Die lokale Kopie ist nicht vollständig. Die Quelle wird nicht gelöscht.');const p=(await stats(j.id))!,count=Math.ceil(d.file.size/j.chunk_bytes);if(p.count!==count||p.copied!==d.file.size||p.verified!==d.file.size)throw new DriveError(409,'Die lokale Kopie ist noch nicht vollständig geprüft.');return d}
 async function start(owner:string,connectionId:string,b:Row){
  if(!['copy','move'].includes(b.operation)||!Array.isArray(b.keys)||!b.keys.length||b.keys.length>100)throw new DriveError(400,'Bitte 1 bis 100 Dateien und Kopieren oder Verschieben wählen.');
  const c=await services.connection(connectionId,owner),folder=b.folder||null;if(folder&&!await one('SELECT id FROM folders WHERE id=? AND user_id=?',folder,owner))throw new DriveError(404,'Zielordner nicht gefunden.');
  if(b.operation==='move'&&(!b.confirmMove||!await services.canMove(c)))throw new DriveError(403,'Verschieben benötigt deine Bestätigung und Schreibzugriff auf die Cloud-Quelle.');
  const selected:Row[]=[];for(const key of [...new Set<string>(b.keys.map(String))]){let ref:Row;try{ref=JSON.parse(key)}catch{throw new DriveError(400,'Ungültige Cloud-Datei.')}const item=await services.resolveItem(c,ref);if(!Number.isSafeInteger(item.size)||item.size<0||item.size>MAX_FILE_BYTES)throw new DriveError(413,'Kopieren und Verschieben ist bis 100 GB pro Datei möglich.');selected.push(item)}
  if(b.operation==='move'&&c.provider==='torbox')for(const item of selected){const entire=await services.allTorFiles(c,item.ref);if(!entire.length||entire.some(x=>!selected.some(s=>s.key===x.key)))throw new DriveError(409,'TorBox kann nur einen ganzen Download löschen. Wähle alle Dateien dieses Downloads oder nutze Kopieren.');}
  const requestId=/^[a-f0-9]{32}$/.test(String(b.requestId||''))?b.requestId:newId(),created:Row[]=[];
  const active=(await one("SELECT COUNT(*) AS n FROM cloud_transfers WHERE user_id=? AND status NOT IN ('done','kept','cancelled')",owner))!.n,reused=(await one("SELECT COUNT(*) AS n FROM cloud_transfers WHERE user_id=? AND connection_id=? AND json_extract(data,'$.requestId')=? AND status NOT IN ('done','kept','cancelled')",owner,c.id,requestId))!.n;if(active+selected.length-reused>100)throw new DriveError(429,'Maximal 100 laufende Cloud-Übertragungen. Bitte vorhandene Übertragungen abschließen oder verwerfen.');
  for(const [index,item] of selected.entries()){
   const prior=await one("SELECT * FROM cloud_transfers WHERE user_id=? AND connection_id=? AND json_extract(data,'$.requestId')=? AND json_extract(data,'$.item.key')=?",owner,c.id,requestId,item.key);if(prior&&prior.operation!==b.operation)throw new DriveError(409,'Diese Anfrage gehört zu einer anderen Übertragungsart.');if(prior){created.push(await summary(prior));continue}
   const old=await one('SELECT f.*,m.data AS metadata FROM files f JOIN cloud_files cf ON cf.object_id=COALESCE(f.object_id,f.id) AND cf.user_id=f.user_id LEFT JOIN file_metadata m ON m.file_id=f.id AND m.user_id=f.user_id WHERE f.user_id=? AND cf.connection_id=? AND cf.remote_key=? LIMIT 1',owner,c.id,item.key);
   const kind=!b.kind||b.kind==='auto'?old?.kind||inferCategory(item.name,item.mime):String(b.kind);if(!BUILTIN_CATEGORIES.some(x=>x.id===kind)&&!await one('SELECT id FROM categories WHERE id=? AND user_id=?',kind,owner))throw new DriveError(400,'Kategorie nicht gefunden.');
   const id=newId(),now=new Date().toISOString(),match=/S(\d+)E(\d+)/i.exec(item.name),file={id,user_id:owner,folder,name:item.name,mime:item.mime,size:item.size,created:now,kind,series:String(b.series||old?.series||'').slice(0,200),season:match?Number(match[1]):old?.season||1,episode:match?Number(match[2]):Math.max(1,Number(b.episode)||1)+index,poster_id:old?.poster_id||old?.id||null};
   const metadata=old?.metadata?JSON.parse(old.metadata):{title:item.name.replace(/\.[^.]+$/,''),source:'manual'},data={requestId,item,file,metadata,provider:c.provider,torGroup:c.provider==='torbox'?item.ref.type+':'+item.ref.parent:null},upload=await bucket.createMultipartUpload(`files/${owner}/${id}`,{httpMetadata:{contentType:item.mime}});
   try{await db.batch([db.prepare('INSERT INTO cloud_transfers(id,user_id,connection_id,operation,status,data,upload_id,chunk_bytes,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(id,owner,c.id,b.operation,'copying',JSON.stringify(data),upload.uploadId,UPLOAD_CHUNK_BYTES,now,now),db.prepare('INSERT INTO cloud_files(object_id,user_id,connection_id,remote_key,data) VALUES(?,?,?,?,?)').bind(id,owner,c.id,item.key,JSON.stringify(item))])}catch(e){await upload.abort().catch(()=>{});throw e}
   created.push(await summary(await job(id,owner)));
  }return json({transfers:created},201);
 }
 async function step(j:Row){
  if(finished.has(j.status)||j.status==='source_pending')return json(await summary(j));
  const token=await lease(j,true);
  try{
   j=await job(j.id,j.user_id);const d=JSON.parse(j.data),size=d.file.size,stored=(await stats(j.id))!,count=Math.ceil(size/j.chunk_bytes),upload=bucket.resumeMultipartUpload(object(j),j.upload_id);
   if(j.status==='copying'){
    const n=stored.count+1;
    if(n<=count){const length=Math.min(j.chunk_bytes,size-(n-1)*j.chunk_bytes),source=await services.sourceBucket().get(object(j),{range:{offset:(n-1)*j.chunk_bytes,length}});if(!source)throw new DriveError(404,'Cloud-Datei nicht verfügbar.');const {sha256,result}=await checkedStream(source.body,length,stream=>upload.uploadPart(n,stream));await assertLease(j,token);await run('INSERT INTO cloud_transfer_parts(transfer_id,part,etag,size,sha256) VALUES(?,?,?,?,?) ON CONFLICT(transfer_id,part) DO UPDATE SET etag=excluded.etag,size=excluded.size,sha256=excluded.sha256,verified=0',j.id,n,result!.etag,length,sha256)}
    else{
     const c=await services.connection(j.connection_id,j.user_id),current=await services.resolveItem(c,d.item.ref);if(!unchanged(d.item,current))throw new DriveError(409,'Die Quelldatei wurde verändert. Bitte die Übertragung verwerfen und neu starten.');
     if(stored.count!==count||stored.copied!==size)throw new DriveError(409,'Unvollständige Übertragung.');
     if(!size){await upload.abort().catch(()=>{});await bucket.put(object(j),new Uint8Array(),{httpMetadata:{contentType:d.file.mime}})}
     else if(!await bucket.head(object(j)))await upload.complete((await parts(j.id)).map(p=>({partNumber:p.part,etag:p.etag})));
     const head=await bucket.head(object(j));if(!head||head.size!==size)throw new DriveError(409,'Die Dateigröße der Kopie stimmt nicht überein.');await run("UPDATE cloud_transfers SET status='verifying' WHERE id=? AND lease_token=?",j.id,token);
    }
   }else if(j.status==='verifying'){
    const part=await one('SELECT * FROM cloud_transfer_parts WHERE transfer_id=? AND verified=0 ORDER BY part LIMIT 1',j.id);
    if(part){const objectPart=await bucket.get(object(j),{range:{offset:(part.part-1)*j.chunk_bytes,length:part.size}});if(!objectPart||(await checkedStream(objectPart.body,part.size)).sha256!==part.sha256)throw new DriveError(409,'Prüfsummenfehler in der Kopie. Die Quelle bleibt erhalten.');await assertLease(j,token);await run('UPDATE cloud_transfer_parts SET verified=1 WHERE transfer_id=? AND part=?',j.id,part.part)}
    else{
     await verifyLocal(j);const storage=driveStorage(db,bucket,j.user_id),file=d.file;if(file.folder&&!await one('SELECT id FROM folders WHERE id=? AND user_id=?',file.folder,j.user_id))file.folder=null;file.name=await storage.freeName(file.name,file.folder);
     if(!BUILTIN_CATEGORIES.some(x=>x.id===file.kind)&&!await one('SELECT id FROM categories WHERE id=? AND user_id=?',file.kind,j.user_id))file.kind='other';
     await db.batch([db.prepare('INSERT INTO files(id,user_id,folder,name,mime,size,created,kind,series,season,episode,poster_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(j.id,j.user_id,file.folder,file.name,file.mime,file.size,file.created,file.kind,file.series,file.season,file.episode,file.poster_id),db.prepare('INSERT INTO file_metadata(file_id,user_id,data,updated) VALUES(?,?,?,?) ON CONFLICT(file_id) DO NOTHING').bind(j.id,j.user_id,JSON.stringify(d.metadata),new Date().toISOString()),db.prepare('DELETE FROM cloud_files WHERE object_id=? AND user_id=?').bind(j.id,j.user_id),db.prepare('UPDATE cloud_transfers SET status=? WHERE id=? AND lease_token=?').bind(j.operation==='move'?'source_pending':'done',j.id,token)]);
    }
   }
   await run("UPDATE cloud_transfers SET error='',updated=? WHERE id=? AND lease_token=?",new Date().toISOString(),j.id,token);return json(await summary(await job(j.id,j.user_id)));
  }catch(e){await run('UPDATE cloud_transfers SET error=?,updated=? WHERE id=? AND lease_token=?',e instanceof DriveError?e.message:'Übertragung unterbrochen. Bitte fortsetzen.',new Date().toISOString(),j.id,token);throw e}
  finally{await run("UPDATE cloud_transfers SET lease_until=0,lease_token='' WHERE id=? AND lease_token=?",j.id,token)}
 }
 async function finish(j:Row){
  if(finished.has(j.status))return json(await summary(j));if(j.status!=='source_pending')throw new DriveError(409,'Die Kopie muss zuerst vollständig geprüft werden.');
  const d=JSON.parse(j.data),group=await all("SELECT * FROM cloud_transfers WHERE user_id=? AND connection_id=? AND json_extract(data,'$.requestId')=? AND json_extract(data,'$.torGroup') IS ?",j.user_id,j.connection_id,d.requestId,d.torGroup);
  const members=d.provider==='torbox'?group:[j];if(members.some(m=>m.status!=='source_pending'&&m.status!=='done'))throw new DriveError(409,'Zuerst alle Dateien dieses TorBox-Downloads vollständig übertragen und prüfen.');
  // One lock for each provider deletion group, including requests on sibling jobs.
  const lock=members.slice().sort((a,b)=>a.id.localeCompare(b.id))[0],token=await lease(lock);
  try{
   const fresh=await job(j.id,j.user_id);if(finished.has(fresh.status))return json(await summary(fresh));const c=await services.connection(j.connection_id,j.user_id);let sourceGone=false;
   if(!await services.canMove(c))throw new DriveError(403,'Zum Löschen der Quelle fehlt die Berechtigung. Die Kopie bleibt in AndreDrive.');
   for(const member of members){await verifyLocal(member);if(!await one('SELECT id FROM files WHERE id=? AND user_id=?',member.id,member.user_id))throw new DriveError(409,'Die lokale Datei wurde entfernt. Die Quelle bleibt erhalten.')}
   if(d.provider==='torbox'){const current=await services.allTorFiles(c,d.item.ref),expected=members.map(m=>JSON.parse(m.data).item);sourceGone=!current.length;if(current.length&&(current.length!==expected.length||current.some(x=>!expected.some(y=>unchanged(y,x)))))throw new DriveError(409,'Der TorBox-Download hat sich geändert. Die Quelle bleibt erhalten.')}
   if(!sourceGone)await services.deleteSource(c,d.item);
   await db.batch(members.map(member=>db.prepare("UPDATE cloud_transfers SET status='done',error='',updated=? WHERE id=? AND user_id=?").bind(new Date().toISOString(),member.id,member.user_id)));
   return json(await summary(await job(j.id,j.user_id)));
  }catch(e){await run('UPDATE cloud_transfers SET error=? WHERE id=? AND user_id=?',e instanceof DriveError?e.message:'Quelle konnte nicht entfernt werden. Die Kopie bleibt erhalten.',j.id,j.user_id);throw e}
  finally{await run("UPDATE cloud_transfers SET lease_until=0,lease_token='' WHERE id=? AND lease_token=?",lock.id,token)}
 }
 async function handle(request:Request,owner:string){
  const url=new URL(request.url),path=url.pathname,method=request.method;
  if(path==='/api/cloud/transfers'&&method==='GET')return json({transfers:await Promise.all((await all("SELECT * FROM cloud_transfers WHERE user_id=? ORDER BY CASE WHEN status IN ('done','kept','cancelled') THEN 1 ELSE 0 END,created DESC LIMIT 100",owner)).map(summary))});
  let match=/^\/api\/cloud\/connections\/([a-f0-9]{32})\/transfers$/.exec(path);
  if(match&&method==='POST'){if(Number(request.headers.get('Content-Length')||0)>262144)throw new DriveError(413,'Anfrage zu groß.');return start(owner,match[1],await request.json() as Row)}
  match=/^\/api\/cloud\/transfers\/([a-f0-9]{32})(?:\/(step|finish|cancel))?$/.exec(path);
  if(match){const j=await job(match[1],owner);if(method==='GET'&&!match[2])return json(await summary(j));if(method==='POST'&&match[2]==='step')return step(j);if(method==='POST'&&match[2]==='finish')return finish(j);
   if(method==='POST'&&match[2]==='cancel'){
    const token=await lease(j);let groupLock:Row|null=null,groupToken='';
    try{
     Object.assign(j,await job(j.id,owner));const d=JSON.parse(j.data);
     if(d.provider==='torbox'&&j.operation==='move'){
      const canonical=(await all("SELECT * FROM cloud_transfers WHERE user_id=? AND connection_id=? AND json_extract(data,'$.requestId')=? AND json_extract(data,'$.torGroup')=? ORDER BY id",owner,j.connection_id,d.requestId,d.torGroup))[0];
      if(canonical&&canonical.id!==j.id){groupLock=canonical;groupToken=await lease(canonical)}
      Object.assign(j,await job(j.id,owner));
     }
     if(j.status==='source_pending'){
      if(d.provider==='torbox')await run("UPDATE cloud_transfers SET status='kept',error='' WHERE user_id=? AND connection_id=? AND json_extract(data,'$.requestId')=? AND json_extract(data,'$.torGroup')=? AND status='source_pending'",owner,j.connection_id,d.requestId,d.torGroup);
      else await run("UPDATE cloud_transfers SET status='kept',error='' WHERE id=?",j.id);
     }else if(!finished.has(j.status)){
      await bucket.resumeMultipartUpload(object(j),j.upload_id).abort().catch(()=>{});
      if(!await one('SELECT id FROM files WHERE user_id=? AND (id=? OR object_id=?)',owner,j.id,j.id)){
       await bucket.delete(object(j));await db.batch([db.prepare('DELETE FROM cloud_files WHERE object_id=? AND user_id=?').bind(j.id,owner),db.prepare('DELETE FROM cloud_transfer_parts WHERE transfer_id=?').bind(j.id)]);
      }
      await run("UPDATE cloud_transfers SET status='cancelled',error='' WHERE id=?",j.id);await driveStorage(db,bucket,owner).cleanup({...d.file,user_id:owner});
     }
     return json(await summary(await job(j.id,owner)));
    }finally{
     if(groupLock&&groupToken)await run("UPDATE cloud_transfers SET lease_until=0,lease_token='' WHERE id=? AND lease_token=?",groupLock.id,groupToken);
     await run("UPDATE cloud_transfers SET lease_until=0,lease_token='' WHERE id=? AND lease_token=?",j.id,token);
    }
   }
  }throw new DriveError(404,'Übertragung nicht gefunden.');
 }
 return {handle};
}
