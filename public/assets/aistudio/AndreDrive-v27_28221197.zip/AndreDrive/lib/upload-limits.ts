export const MAX_FILE_BYTES=100_000_000_000; // 100 GB (decimal), not a single request.
export const UPLOAD_CHUNK_BYTES=16*1024**2;
export const LEGACY_CHUNK_BYTES=8*1024**2;
export const MAX_PARTS=10_000;
export function uploadChunkBytes(metadata:{chunkBytes?:number}){return metadata.chunkBytes===UPLOAD_CHUNK_BYTES?UPLOAD_CHUNK_BYTES:LEGACY_CHUNK_BYTES}
