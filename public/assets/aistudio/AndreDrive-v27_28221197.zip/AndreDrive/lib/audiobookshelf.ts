import {createHmac,timingSafeEqual} from 'node:crypto';
import {Buffer} from 'node:buffer';
import {DriveError, newId, objectKey} from './file-operations';
import {webdavHash} from './webdav';
import {audioFilter, audioMime, audioSuffix} from './audio-formats';
import {probeAudioDuration} from './audiobook-audio';

type Row = Record<string, any>;
type Services = {
  body: () => Promise<Row>;
  content(file: Row, options: {mime: string; download: boolean}): Promise<Response>;
  poster(file: Row): Promise<Response>;
};
type Book = {id:string; title:string; files:Row[]; created:number; author:string; narrator:string; description:string; year:string; language:string; genres:string[]; cover?:Row};
const base = '/audiobookshelf';
const libraryId = 'lib_andredrive_audiobooks';
const folderId = 'fol_andredrive_audiobooks';
const version = '2.26.0';
const day = 86400000;
const authPath = /^\/api\/audiobookshelf\/accounts(?:\/([a-f0-9]{32}))?$/;
export const audiobookshelfPath = (path: string) => path === base || path.startsWith(base + '/');
export const audiobookshelfAccountPath = (path: string) => authPath.test(path);
const headers = {'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
const json = (value: unknown, status = 200) => Response.json(value,{status,headers});
const empty = () => new Response(null,{status:204,headers});
const notFound = () => json({error:'Nicht gefunden.'},404);
const unauthorized = () => json({error:'Ungültiger oder abgelaufener Audiobookshelf-Zugang.'},401);
const passwordFormat = /^[a-f0-9]{64}$/;
const tokenFormat = /^[\w-]{1,100}\.[\w-]{1,500}\.[\w-]{43}$/;
const token = () => newId() + newId();
const equal = (a:string,b:string) => a.length===b.length && timingSafeEqual(new TextEncoder().encode(a),new TextEncoder().encode(b));
const number = (value:unknown) => typeof value === 'number' && Number.isFinite(value) && value >= 0 ? Math.min(value,36000000) : undefined;
const queries = (db:D1Database) => ({
  one:(sql:string,...args:any[]) => db.prepare(sql).bind(...args).first<Row>(),
  all:async(sql:string,...args:any[]) => (await db.prepare(sql).bind(...args).all<Row>()).results,
  run:(sql:string,...args:any[]) => db.prepare(sql).bind(...args).run(),
});
const eligible = "(f.kind='audiobook' OR lower(f.name) GLOB '*.m4b') AND " + audioFilter;

export async function manageAudiobookshelfAccounts(request:Request, db:D1Database, owner:string, body:Services['body']) {
  const url = new URL(request.url);
  const id = authPath.exec(url.pathname)?.[1];
  const serverUrl = url.origin + base;
  const {all,run} = queries(db);
  if (request.method==='GET' && !id) {
    return json({serverUrl,accounts:await all('SELECT id,username,label,created FROM abs_accounts WHERE user_id=? ORDER BY created DESC',owner)});
  }
  if (request.method==='POST' && !id) {
    const input=await body();
    if (!input || typeof input.label!=='string') throw new DriveError(400,'Bitte einen Gerätenamen eingeben.');
    const account={id:newId(),username:'abs_'+newId(),label:input.label.trim().slice(0,80)||'Hörbuchplayer',created:Date.now()};
    const password=token();
    const created=await run(
      'INSERT INTO abs_accounts(id,user_id,username,label,password_hash,created) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM abs_accounts WHERE user_id=?)<50',
      account.id,owner,account.username,account.label,await webdavHash(password),account.created,owner,
    );
    if (!created.meta.changes) throw new DriveError(429,'Maximal 50 Audiobookshelf-Zugänge pro Workspace.');
    return json({...account,password,serverUrl},201);
  }
  if (request.method==='DELETE' && id) {
    const [removed] = await db.batch([
      db.prepare('DELETE FROM abs_accounts WHERE id=? AND user_id=?').bind(id,owner),
      db.prepare('DELETE FROM abs_sessions WHERE account_id=? AND NOT EXISTS (SELECT 1 FROM abs_accounts WHERE id=?)').bind(id,id),
      db.prepare('DELETE FROM abs_playback WHERE account_id=? AND NOT EXISTS (SELECT 1 FROM abs_accounts WHERE id=?)').bind(id,id),
    ]);
    return removed.meta.changes ? json({ok:true}) : notFound();
  }
  return json({error:'Methode nicht unterstützt.'},405);
}

const library = {
  id:libraryId,name:'Hörbücher',mediaType:'book',icon:'audiobook',displayOrder:1,
  provider:'AndreDrive',folders:[{id:folderId,libraryId,fullPath:'/Hörbücher',addedAt:0}],
  settings:{coverAspectRatio:1,disableWatcher:true},createdAt:0,lastUpdate:0,
};
const serverSettings = {version,language:'de',serverVersion:version,allowIframe:false,storeCoverWithItem:false,
  authActiveAuthMethods:['local'],scannerFindCovers:false,sortingIgnorePrefix:false,sortingPrefixes:[]};

const trackNumber = (name:string) => {
  const stem=name.replace(/\.[^.]+$/,'');
  const found=/^(?:(?:track|teil|part|kapitel|chapter)[ _.-]*)?(\d{1,4})(?:$|[ _.-])/i.exec(stem) ||
    /(?:track|teil|part|kapitel|chapter)[ _.-]*(\d{1,4})$/i.exec(stem);
  return found ? Number(found[1]) : null;
};
const order = (a:string,b:string) => a.localeCompare(b,'de',{numeric:true,sensitivity:'base'});
const fileBook = (id:string) => 'file_' + id;
const folderBook = (id:string) => 'folder_' + id;
const itemPattern = /^(file|folder)_([a-f0-9]{32})$/;

async function loadBooks(db:D1Database, owner:string, id?:string) {
  const {all} = queries(db);
  const match=id ? itemPattern.exec(id) : null;
  if (id && !match) return [];
  const constraint=match ? match[1]==='folder' ? ' AND f.folder=?' : ' AND (f.id=? OR f.folder=(SELECT folder FROM files WHERE user_id=? AND id=?))' : '';
  const args=match ? match[1]==='folder' ? [match[2]] : [match[2],owner,match[2]] : [];
  const rows=await all(`SELECT f.*, d.name AS folder_name, a.duration AS detected_duration,
    json_extract(m.data,'$.title') AS book_title,json_extract(m.data,'$.author') AS author,
    json_extract(m.data,'$.narrator') AS narrator,json_extract(m.data,'$.plot') AS description,
    json_extract(m.data,'$.year') AS year,json_extract(m.data,'$.language') AS language,
    json_extract(m.data,'$.genres') AS genres,json_extract(m.data,'$.runtime_minutes') AS minutes,
    json_extract(m.data,'$.poster_source') AS poster_source
    FROM files f LEFT JOIN folders d ON d.user_id=f.user_id AND d.id=f.folder
    LEFT JOIN file_metadata m ON m.user_id=f.user_id AND m.file_id=f.id
    LEFT JOIN abs_audio a ON a.user_id=f.user_id AND a.object_id=COALESCE(f.object_id,f.id) AND a.size=f.size
    WHERE f.user_id=? AND ${eligible}${constraint} ORDER BY f.created DESC,f.id`,owner,...args);
  const folders=new Map<string,Row[]>();
  const groups=new Map<string,Row[]>();
  for (const file of rows) {
    if (!audioMime(file)) continue;
    if (file.folder && audioSuffix(file.name)!=='m4b' && trackNumber(file.name)!==null) {
      if (!folders.has(file.folder)) folders.set(file.folder,[]);
      folders.get(file.folder)!.push(file);
    } else groups.set(fileBook(file.id),[file]);
  }
  for (const [folder,files] of folders) {
    if (new Set(files.map(f=>trackNumber(f.name))).size!==files.length) {
      for (const file of files) groups.set(fileBook(file.id),[file]);
    } else {
      files.sort((a,b)=>trackNumber(a.name)!-trackNumber(b.name)! || order(a.name,b.name));
      groups.set(folderBook(folder),files);
    }
  }
  return [...groups].filter(([key])=>!id || id===key).map(([id,files]):Book=>{
    const first=files[0];
    return {
      id,files,title:id.startsWith('folder_') && first.folder_name ? first.folder_name : first.book_title || first.name.replace(/\.[^.]+$/,''),
      created:files.reduce((latest,file)=>Math.max(latest,Date.parse(file.created)||0),0),
      author:first.author||'',narrator:first.narrator||'',description:first.description||'',year:first.year||'',
      language:first.language||'',genres:String(first.genres||'').split(',').map(x=>x.trim()).filter(Boolean),
      cover:files.find(file=>file.poster_source==='upload'),
    };
  });
}

const streamName = (file:Row) => file.id + '.' + (audioSuffix(file.name).replace(/[^a-z0-9]/g,'').slice(0,8) || 'audio');
const durationOf = (file:Row) => Number(file.detected_duration) || Math.max(0,Number(file.minutes)||0)*60;
function itemDto(book:Book, expanded=false) {
  const meta={
    title:book.title,titleIgnorePrefix:book.title,subtitle:null,authorName:book.author,narratorName:book.narrator,seriesName:'',
    authors:book.author?[{id:'author_'+encodeURIComponent(book.author),name:book.author}]:[],
    narrators:book.narrator?[book.narrator]:[],series:[],genres:book.genres,publishedYear:book.year||null,
    publishedDate:null,publisher:null,description:book.description ? book.description.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : null,descriptionPlain:book.description||null,
    isbn:null,asin:null,language:book.language||null,explicit:false,abridged:false,
  };
  let startOffset=0;
  const tracks=book.files.map((file,index)=>{
    const duration=durationOf(file);
    const data={
      index:index+1,startOffset,duration,title:file.book_title||file.name,
      contentUrl:'/s/item/'+book.id+'/'+streamName(file),mimeType:audioMime(file),
      metadata:{filename:file.name,ext:'.'+audioSuffix(file.name),path:file.name,relPath:file.name,size:file.size,
        mtimeMs:book.created,ctimeMs:book.created,birthtimeMs:book.created},
    };
    startOffset+=duration;
    return data;
  });
  const size=book.files.reduce((sum,file)=>sum+file.size,0);
  const chapters=tracks.filter(track=>track.duration>0).map(track=>({
    id:track.index-1,start:track.startOffset,end:track.startOffset+track.duration,title:track.title,
  }));
  return {
    id:book.id,ino:book.id,libraryId,folderId,path:book.title,relPath:book.title,isFile:!book.id.startsWith('folder_'),
    mtimeMs:book.created,ctimeMs:book.created,birthtimeMs:book.created,addedAt:book.created,updatedAt:book.created,
    isMissing:false,isInvalid:false,mediaType:'book',numFiles:tracks.length,size,
    media:{id:book.id,metadata:meta,coverPath:book.cover?'/api/items/'+book.id+'/cover':null,tags:[],duration:startOffset,size,
      numTracks:tracks.length,numAudioFiles:tracks.length,numChapters:chapters.length,ebookFormat:null,
      ...(expanded?{tracks,chapters,ebookFile:null,audioFiles:tracks.map((track,index)=>({
        ino:book.files[index].id,index:track.index,metadata:track.metadata,duration:track.duration,
        mimeType:track.mimeType,chapters:[],metaTags:{},
      }))}:{}),
    },
    ...(expanded?{libraryFiles:tracks.map((track,index)=>({ino:book.files[index].id,metadata:track.metadata,fileType:'audio'}))}:{}),
  };
}

function progressDto(row:Row) {
  return {
    id:row.item_id,libraryItemId:row.item_id,episodeId:null,duration:row.duration,currentTime:row.current_time,
    progress:row.finished?1:row.duration?Math.min(1,row.current_time/row.duration):0,isFinished:!!row.finished,
    hideFromContinueListening:false,lastUpdate:row.updated,startedAt:row.started,finishedAt:row.finished?row.updated:null,
  };
}

export async function handleAudiobookshelf(request:Request, db:D1Database, bucket:R2Bucket, services:Services, signingKey?:string) {
  const url=new URL(request.url), path=url.pathname.slice(base.length).replace(/\/+$/,'')||'/', method=request.method;
  const reading=method==='GET'||method==='HEAD';
  const now=Date.now();
  const {one,all,run}=queries(db);
  if (reading && (path==='/' || path==='/status')) {
    return json({isInit:true,language:'de',serverVersion:version,authMethods:['local'],
      authFormData:{authLoginCustomMessage:'AndreDrive · Audiobookshelf-Gerätezugang'},serverName:'AndreDrive',andredriveCompatibility:true});
  }
  if (reading && (path==='/ping'||path==='/healthcheck')) return json({success:true});

  async function user(account:Row, tokens?:{access:string;refresh:string}) {
    const progress=await all('SELECT * FROM abs_progress WHERE user_id=? ORDER BY updated DESC LIMIT 5000',account.user_id);
    return {
      id:account.id,username:account.username,type:'user',mediaProgress:progress.map(progressDto),
      seriesHideFromContinueListening:[],bookmarks:[],isActive:true,isLocked:false,lastSeen:now,createdAt:account.created,
      permissions:{download:true,update:false,delete:false,upload:false,accessAllLibraries:true,accessAllTags:true,accessExplicitContent:true},
      librariesAccessible:[libraryId],itemTagsAccessible:[],
      ...(tokens?{token:tokens.access,accessToken:tokens.access,refreshToken:tokens.refresh}:{}),
    };
  }
  const authorize=async (account:Row, tokens?:{access:string;refresh:string}) =>
    json({user:await user(account,tokens),userDefaultLibraryId:libraryId,serverSettings,ereaderDevices:[]});
  const newTokens=async(account:Row)=>{
    if (!signingKey) throw new DriveError(503,'Geschützte Audiobookshelf-Zugänge sind noch nicht verfügbar.');
    const encode=(data:unknown)=>Buffer.from(JSON.stringify(data)).toString('base64url');
    const issue=(type:string,validDays:number)=>{
      const unsigned=encode({alg:'HS256',typ:'JWT'})+'.'+encode({
        sub:account.id,userId:account.id,type,jti:newId(),iat:Math.floor(now/1000),exp:Math.floor((now+validDays*day)/1000),
      });
      return unsigned+'.'+createHmac('sha256','andredrive:abs:'+signingKey).update(unsigned).digest('base64url');
    };
    // Only hashes of issued tokens are accepted, so refresh rotation and revocation are immediate.
    const access=issue('access',30), refresh=issue('refresh',90);
    return {access,refresh,accessHash:await webdavHash(access),refreshHash:await webdavHash(refresh)};
  };
  if (path==='/login' && method==='POST') {
    const input=await services.body();
    const username=input?.username, password=input?.password;
    if (typeof username!=='string'||!/^abs_[a-f0-9]{32}$/.test(username)||typeof password!=='string'||!passwordFormat.test(password)) return unauthorized();
    const account=await one('SELECT * FROM abs_accounts WHERE username=?',username);
    if (!account || !equal(await webdavHash(password),account.password_hash)) return unauthorized();
    const tokens=await newTokens(account);
    await db.batch([
      db.prepare('DELETE FROM abs_sessions WHERE account_id=? AND refresh_expires<=?').bind(account.id,now),
      db.prepare('INSERT INTO abs_sessions(id,account_id,access_hash,refresh_hash,expires,refresh_expires) VALUES(?,?,?,?,?,?)')
        .bind(newId(),account.id,tokens.accessHash,tokens.refreshHash,now+30*day,now+90*day),
      db.prepare('DELETE FROM abs_sessions WHERE account_id=? AND id NOT IN (SELECT id FROM abs_sessions WHERE account_id=? ORDER BY refresh_expires DESC LIMIT 20)')
        .bind(account.id,account.id),
    ]);
    return authorize(account,tokens);
  }
  const refresh=request.headers.get('x-refresh-token')||'';
  if ((path==='/auth/refresh'||path==='/logout') && method==='POST' && tokenFormat.test(refresh)) {
    const hash=await webdavHash(refresh);
    const session=await one('SELECT a.*,s.id AS session_id FROM abs_sessions s JOIN abs_accounts a ON a.id=s.account_id WHERE s.refresh_hash=? AND s.refresh_expires>?',hash,now);
    if (!session) return unauthorized();
    if (path==='/logout') {
      await run('DELETE FROM abs_sessions WHERE id=? AND refresh_hash=?',session.session_id,hash);
      return json({success:true});
    }
    const tokens=await newTokens(session);
    const updated=await run('UPDATE abs_sessions SET access_hash=?,refresh_hash=?,expires=?,refresh_expires=? WHERE id=? AND refresh_hash=?',
      tokens.accessHash,tokens.refreshHash,now+30*day,now+90*day,session.session_id,hash);
    return updated.meta.changes ? authorize(session,tokens) : unauthorized();
  }
  const bearer=/^Bearer ([^\s]{1,700})$/i.exec(request.headers.get('Authorization')||'')?.[1];
  const supplied=bearer || (reading ? url.searchParams.get('token') || '' : '');
  if (!tokenFormat.test(supplied)) return unauthorized();
  const account=await one('SELECT a.*,s.id AS session_id FROM abs_sessions s JOIN abs_accounts a ON a.id=s.account_id WHERE s.access_hash=? AND s.expires>?',
    await webdavHash(supplied),now);
  if (!account) return unauthorized();
  const owner=account.user_id;
  if (path==='/logout' && method==='POST') {
    await run('DELETE FROM abs_sessions WHERE id=?',account.session_id);
    return json({success:true});
  }
  if (path==='/api/authorize' && (reading||method==='POST')) return authorize(account);
  if (path==='/api/me' && reading) return json(await user(account));
  if (path==='/api/libraries' && reading) return json({libraries:[library]});
  if (path==='/api/settings' && reading) return json({serverSettings});
  if (path==='/api/playlists' && reading) return json({playlists:[]});
  if (path==='/api/me/listening-sessions' && reading) return json({total:0,numPages:0,page:0,itemsPerPage:10,sessions:[]});

  const getBook=async(id:string)=>(await loadBooks(db,owner,id))[0];
  const getProgress=(id:string)=>one('SELECT * FROM abs_progress WHERE user_id=? AND item_id=?',owner,id);
  const saveProgress=async(id:string, input:Row, knownDuration:number)=>{
    const previous=await getProgress(id);
    const duration=number(input?.duration)||knownDuration||previous?.duration||0;
    const fraction=number(input?.progress);
    const value=number(input?.currentTime) ?? (fraction!==undefined && fraction<=1 ? fraction*duration : undefined);
    let current=value ?? previous?.current_time ?? 0;
    if (duration) current=Math.min(current,duration);
    const finished=typeof input?.isFinished==='boolean'?input.isFinished :
      value===undefined ? !!previous?.finished : duration>0 && current/duration>=0.995;
    if (finished && duration) current=duration;
    await run(`INSERT INTO abs_progress(user_id,item_id,current_time,duration,finished,started,updated) VALUES(?,?,?,?,?,?,?)
      ON CONFLICT(user_id,item_id) DO UPDATE SET current_time=excluded.current_time,duration=excluded.duration,
      finished=excluded.finished,updated=excluded.updated WHERE abs_progress.updated<=excluded.updated`,
    owner,id,current,duration,Number(finished),previous?.started||now,now);
    return progressDto((await getProgress(id))!);
  };

  let match=/^\/api\/session\/([a-f0-9]{32})\/(sync|close)$/.exec(path);
  if (match && method==='POST') {
    const session=await one('SELECT * FROM abs_playback WHERE id=? AND account_id=? AND expires>?',match[1],account.id,now);
    if (!session) return notFound();
    const input=request.body?await services.body():{};
    if (number(input?.currentTime)!==undefined || typeof input?.isFinished==='boolean') {
      if (!await getBook(session.item_id)) return notFound();
      await saveProgress(session.item_id,input,session.duration);
    }
    if (match[2]==='close') await run('DELETE FROM abs_playback WHERE id=? AND account_id=?',session.id,account.id);
    else await run('UPDATE abs_playback SET expires=? WHERE id=? AND account_id=?',now+day,session.id,account.id);
    return json({success:true});
  }

  match=/^\/api\/me\/progress\/(\w+)$/.exec(path);
  if (match && ['GET','HEAD','PATCH','DELETE'].includes(method)) {
    const book=await getBook(match[1]);
    if (!book) return notFound();
    if (method==='DELETE') {
      await run('DELETE FROM abs_progress WHERE user_id=? AND item_id=?',owner,book.id);
      return json({success:true});
    }
    if (method==='PATCH') {
      const input=await services.body();
      return json(await saveProgress(book.id,input,itemDto(book).media.duration));
    }
    const progress=await getProgress(book.id);
    return progress?json(progressDto(progress)):notFound();
  }

  match=/^\/s\/item\/(\w+)\/([^/]+)$/.exec(path);
  if (match && reading) {
    let filename:string;
    try { filename=decodeURIComponent(match[2]); } catch { return notFound(); }
    const book=await getBook(match[1]), file=book?.files.find(file=>streamName(file)===filename || file.name===filename);
    return file?services.content(file,{mime:audioMime(file),download:false}):notFound();
  }

  match=/^\/api\/items\/(\w+)(?:\/(cover|play|download|file\/([a-f0-9]{32})(?:\/download)?))?$/.exec(path);
  if (match) {
    const book=await getBook(match[1]);
    if (!book) return notFound();
    const action=match[2]||'';
    if (action==='cover' && reading) return book.cover?services.poster(book.cover):notFound();
    if (reading && (action==='download'||match[3])) {
      const file=match[3]?book.files.find(file=>file.id===match![3]):book.files.length===1?book.files[0]:null;
      return file?services.content(file,{mime:audioMime(file),download:true}):notFound();
    }
    if ((!action && reading) || (action==='play' && method==='POST')) {
      // Probe only on detail/play. A catalog refresh never opens every audio file.
      const expanded=action==='play'||url.searchParams.get('expanded')==='1'||url.searchParams.get('expanded')==='true';
      if (expanded) {
        const unknown=book.files.filter(file=>!durationOf(file));
        for (let i=0;i<unknown.length;i+=4) {
          await Promise.all(unknown.slice(i,i+4).map(async file=>{
            try {
              const duration=number(await probeAudioDuration(bucket,objectKey(file),file.size,audioMime(file)));
              if (duration) {
                file.detected_duration=duration;
                await run('INSERT OR REPLACE INTO abs_audio(user_id,object_id,size,duration) VALUES(?,?,?,?)',owner,file.object_id||file.id,file.size,duration);
              }
            } catch { /* Unavailable cloud probes are retried on the next detail request. */ }
          }));
        }
      }
      const item=itemDto(book,expanded);
      const progress=await getProgress(book.id);
      if (action==='play') {
        const input=request.body?await services.body():{};
        const id=newId(), duration=item.media.duration||progress?.duration||0;
        const position=progress?.finished ? 0 : progress?.current_time||0;
        await db.batch([
          db.prepare('DELETE FROM abs_playback WHERE account_id=? AND expires<=?').bind(account.id,now),
          db.prepare('INSERT INTO abs_playback(id,account_id,item_id,duration,expires) VALUES(?,?,?,?,?)').bind(id,account.id,book.id,duration,now+day),
        ]);
        return json({
          id,userId:account.id,libraryId,libraryItemId:book.id,episodeId:null,mediaType:'book',mediaMetadata:item.media.metadata,
          displayTitle:book.title,displayAuthor:book.author,coverPath:item.media.coverPath,duration,playMethod:0,
          mediaPlayer:typeof input?.mediaPlayer==='string'?input.mediaPlayer.slice(0,80):'direct',deviceInfo:input?.deviceInfo||{},
          serverVersion:version,date:new Date(now).toISOString().slice(0,10),dayOfWeek:new Date(now).toLocaleDateString('en',{weekday:'long'}),
          timeListening:0,startTime:position,currentTime:position,startedAt:now,updatedAt:now,
          audioTracks:item.media.tracks,videoTrack:null,chapters:item.media.chapters,libraryItem:item,
        });
      }
      return json({...item,...(progress && url.searchParams.get('include')?.split(',').includes('progress') ? {userMediaProgress:progressDto(progress)}:{})});
    }
  }

  match=/^\/api\/libraries\/([^/]+)(?:\/(\w+))?$/.exec(path);
  if (match && reading && match[1]===libraryId) {
    const endpoint=match[2]||'';
    if (['series','collections','playlists'].includes(endpoint)) {
      return json({results:[],total:0,limit:0,page:0,[endpoint]:[]});
    }
    if (['','items','personalized','search','filterdata','authors','stats'].includes(endpoint)) {
      const books=await loadBooks(db,owner);
      const authors=[...new Set(books.map(book=>book.author).filter(Boolean))].sort(order)
        .map(name=>({id:'author_'+encodeURIComponent(name),name,numBooks:books.filter(b=>b.author===name).length}));
      const filterdata={authors,genres:[...new Set(books.flatMap(book=>book.genres))],narrators:[...new Set(books.map(book=>book.narrator).filter(Boolean))],
        series:[],tags:[],languages:[...new Set(books.map(book=>book.language).filter(Boolean))],publishers:[]};
      if (!endpoint) return json({library,filterdata,issues:0,numUserPlaylists:0});
      if (endpoint==='authors') return json({authors});
      if (endpoint==='filterdata') return json(filterdata);
      if (endpoint==='stats') return json({totalItems:books.length,totalSize:books.reduce((sum,book)=>sum+itemDto(book).size,0),totalDuration:books.reduce((sum,book)=>sum+itemDto(book).media.duration,0)});
      if (endpoint==='search') {
        const q=(url.searchParams.get('q')||'').trim().slice(0,240).toLocaleLowerCase('de');
        const hits=books.filter(book=>[book.title,book.author,book.narrator].some(value=>value.toLocaleLowerCase('de').includes(q))).slice(0,100);
        return json({book:hits.map(book=>({libraryItem:itemDto(book),matchKey:'title',matchText:book.title})),authors:[],narrators:[],series:[],tags:[],genres:[]});
      }
      if (endpoint==='personalized') {
        const byId=new Map(books.map(book=>[book.id,book]));
        const progress=await all('SELECT item_id FROM abs_progress WHERE user_id=? AND finished=0 AND current_time>0 ORDER BY updated DESC LIMIT 25',owner);
        return json([
          {id:'continue-listening',label:'Weiterhören',labelStringKey:'HeaderContinueListening',type:'book',
            entities:progress.flatMap(row=>byId.has(row.item_id)?[itemDto(byId.get(row.item_id)!)]:[])},
          {id:'recently-added',label:'Kürzlich hinzugefügt',labelStringKey:'HeaderRecentlyAdded',type:'book',
            entities:books.sort((a,b)=>b.created-a.created).slice(0,25).map(book=>itemDto(book))},
        ]);
      }
      const requestedLimit=Number(url.searchParams.get('limit')||0);
      const limit=requestedLimit===0?0:Math.max(1,Math.min(500,Math.floor(requestedLimit)||100));
      const page=Math.max(0,Math.min(100000,Math.floor(Number(url.searchParams.get('page'))||0)));
      const sort=url.searchParams.get('sort')||'media.metadata.title';
      const desc=url.searchParams.get('desc')==='1'||url.searchParams.get('desc')==='true';
      const compare=(a:Book,b:Book)=>sort==='addedAt'||sort==='updatedAt'?a.created-b.created:
        sort==='media.metadata.authorName'?order(a.author,b.author)||order(a.title,b.title):order(a.title,b.title);
      books.sort((a,b)=>(desc?-1:1)*compare(a,b)||a.id.localeCompare(b.id));
      return json({results:(limit?books.slice(page*limit,(page+1)*limit):books).map(book=>itemDto(book)),total:books.length,limit,page,sort,desc,
        mediaType:'book',filterBy:url.searchParams.get('filter')||'all',minified:true,collapseseries:false});
    }
  }
  return notFound();
}
