import {cloudSources} from './cloud-sources';
import {jellyfinPath,handleJellyfin} from './jellyfin';
import {subsonicPath,subsonicAccountPath,handleSubsonic,manageSubsonicAccounts} from './subsonic';
import {opdsPath,opdsAccountPath,handleOpds,manageOpdsAccounts} from './opds';
import {audiobookshelfPath,audiobookshelfAccountPath,handleAudiobookshelf,manageAudiobookshelfAccounts} from './audiobookshelf';
import {BUILTIN_CATEGORIES,categoryKey,inferCategory} from './categories';
import {driveStorage,DriveError,objectKey,posterKey,newId} from './file-operations';
import {webdavPath,handleWebDav,webdavHash} from './webdav';
import {iptvPath,iptvCredentials,iptvCatalog,iptvLogin} from './iptv-catalog';
import {MAX_FILE_BYTES,UPLOAD_CHUNK_BYTES,uploadChunkBytes,MAX_PARTS} from './upload-limits';
import {normalizeMetadata,sealToken,openToken,tmdbGet,tmdbDetails,tmdbScrapeInput,tmdbScraper,tmdbPeople,TmdbError,m3uMetadata,imageMime} from './catalog-metadata';
import {fragmentIndex,fragmentBody,hlsManifest} from './fragmented-mp4';
import {fixedLengthBody,singleRange,mediaType,inspectMp4,type RequestLifetime} from './media-stream';
import {Zip,ZipPassThrough} from 'fflate';
type Row=Record<string,any>;
type Bindings={DB?:D1Database,BUCKET?:R2Bucket,METADATA_SETTINGS_KEY?:string,TMDB_API_READ_ACCESS_TOKEN?:string,ONEDRIVE_CLIENT_ID?:string};
const CHUNK=UPLOAD_CHUNK_BYTES,MAX=MAX_FILE_BYTES;
const uuid=()=>crypto.randomUUID().replaceAll('-','');
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});
class ApiError extends Error{constructor(public status:number,message:string){super(message)}}
function fail(status:number,message:string):never{throw new ApiError(status,message)}
const str=(v:unknown,max=200)=>String(v??'').trim().slice(0,max);
const pos=(v:unknown)=>Math.max(1,Math.min(100000,Math.floor(Number(v)||1)));
const clean=(s:unknown)=>String(s??'').replace(/[\r\n"<>]/g,' ').trim();
const filename=(name:string)=>`attachment; filename="download"; filename*=UTF-8''${encodeURIComponent(name).replace(/['()*]/g,c=>'%'+c.charCodeAt(0).toString(16))}`;
const sharedPath=(path:string)=>/^\/api\/shared\/[^/]+$/.test(path)||/^\/(media|thumb|hls)\/[^/]+\/[^/]+(?:\/.*)?$/.test(path)||/^\/playlist\/[^/]+\/library\.m3u8?$/.test(path);
export async function handleDrive(request:Request,env:Bindings,lifetime?:RequestLifetime):Promise<Response>{
 let response:Response;
 const pathname=new URL(request.url).pathname;
 const subsonic=subsonicPath(pathname),opds=opdsPath(pathname),audiobookshelf=audiobookshelfPath(pathname);
 const share=sharedPath(pathname)||iptvPath(pathname);
 if((subsonic||opds||audiobookshelf)&&request.method==='OPTIONS')return new Response(null,{status:204,headers:{
  'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':opds?'GET, HEAD, OPTIONS':audiobookshelf?'GET, HEAD, POST, PATCH, DELETE, OPTIONS':'GET, HEAD, POST, OPTIONS',
  'Access-Control-Allow-Headers':'Authorization, Content-Type, Range, If-Range, X-Return-Tokens, X-Refresh-Token','Access-Control-Max-Age':'86400',
 }});
 if(share&&request.method==='OPTIONS')return new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, HEAD, OPTIONS','Access-Control-Allow-Headers':'Range','Access-Control-Max-Age':'86400'}});
 try{response=await route(request,env,lifetime)}catch(e){if(e instanceof ApiError||e instanceof TmdbError||e instanceof DriveError)response=json({error:e.message},e.status);else{console.error('AndreDrive request failed',e instanceof Error?e.message:'unknown');response=json({error:'Die Aktion konnte nicht abgeschlossen werden. Bitte erneut versuchen.'},500)}}
 if(share&&['GET','HEAD'].includes(request.method)){response.headers.set('Access-Control-Allow-Origin','*');response.headers.set('Access-Control-Expose-Headers','Content-Length, Content-Range, Accept-Ranges, ETag, Content-Disposition');response.headers.set('Referrer-Policy','no-referrer');}
 if(jellyfinPath(new URL(request.url).pathname)){response.headers.set('Access-Control-Allow-Origin','*');response.headers.set('Access-Control-Allow-Methods','GET, HEAD, POST, DELETE, OPTIONS');response.headers.set('Access-Control-Allow-Headers','Authorization, Content-Type, X-Emby-Authorization, X-Emby-Token, X-MediaBrowser-Token, Range, If-Range');response.headers.set('Access-Control-Expose-Headers','Content-Length, Content-Range, Accept-Ranges, ETag');response.headers.set('Referrer-Policy','no-referrer');}
 if(subsonic||opds||audiobookshelf){
  response.headers.set('Access-Control-Allow-Origin','*');
  response.headers.set('Access-Control-Expose-Headers','Content-Length, Content-Range, Accept-Ranges, ETag, Content-Disposition');
  response.headers.set('Referrer-Policy','no-referrer');
 }
 return request.method==='HEAD'?new Response(null,{status:response.status,headers:response.headers}):response;
}
async function route(request:Request,{DB:db,BUCKET:rawBucket,METADATA_SETTINGS_KEY:settingsKey,TMDB_API_READ_ACCESS_TOKEN:siteTmdbToken,ONEDRIVE_CLIENT_ID:oneDriveClientId}:Bindings,lifetime?:RequestLifetime):Promise<Response>{
 const cloud=db?cloudSources(db,settingsKey,oneDriveClientId,rawBucket):null,bucket=rawBucket&&cloud?cloud.wrapBucket(rawBucket):rawBucket;
 const url=new URL(request.url),path=url.pathname,method=request.method;
 const userId=request.headers.get('oai-authenticated-user-id');
 const subsonic=subsonicPath(path),audiobookshelf=audiobookshelfPath(path);
 if(!['GET','HEAD','OPTIONS'].includes(method)){
  const origin=request.headers.get('origin');if(origin&&origin!==url.origin&&!jellyfinPath(path)&&!subsonic&&!audiobookshelf)fail(403,'Ungültiger Ursprung.');
 }
 if(path==='/api'||path==='/api/health')return json({ok:!!db&&!!bucket,storage:'sites-r2',database:'sites-d1',backendUrl:url.origin+'/api',quota:null,maxFileBytes:MAX,chunkBytes:CHUNK,hls:'fragmented-mp4',access:'public-token-links-private-library'});
 if(webdavPath(path)){if(!db||!bucket)fail(503,'Speicher noch nicht verfügbar.');return handleWebDav(request,db,bucket,lifetime)}
 if(path==='/api/me'){
  if(!userId)return json(null);
  const email=request.headers.get('oai-authenticated-user-email')||'';let name=request.headers.get('oai-authenticated-user-full-name')||'';
  if(request.headers.get('oai-authenticated-user-full-name-encoding')==='percent-encoded-utf-8'){try{name=decodeURIComponent(name)}catch{name=''}}
  return json({id:userId,name:name||email.split('@')[0]||'Mein',email});
 }
 if(!userId&&!subsonic&&!audiobookshelf&&!opdsPath(path)&&!jellyfinPath(path)&&!((sharedPath(path)||iptvPath(path))&&['GET','HEAD'].includes(method)))fail(401,'Bitte melde dich mit ChatGPT an.');
 if(!db||!bucket)fail(503,'Cloud-Speicher wird eingerichtet. Bitte später erneut versuchen.');
 const one=async(sql:string,...args:any[])=>db.prepare(sql).bind(...args).first<Row>();
 const all=async(sql:string,...args:any[])=>(await db.prepare(sql).bind(...args).all<Row>()).results;
 const run=(sql:string,...args:any[])=>db.prepare(sql).bind(...args).run();
 const body=async()=>{if(Number(request.headers.get('content-length')||0)>1024**2)fail(413,'Anfrage zu groß.');try{return await request.json() as Row}catch{fail(400,'Ungültige Anfrage.')}};
 const file=async(id:string)=>await one('SELECT * FROM files WHERE id=? AND user_id=?',id,userId)??fail(404,'Datei nicht gefunden.');
 const folder=async(id:string)=>await one('SELECT * FROM folders WHERE id=? AND user_id=?',id,userId)??fail(404,'Ordner nicht gefunden.');
 const key=(id:string,owner:string|null=userId)=>`files/${owner}/${id}`;
 const metadata=async(id:string,owner:string)=>{const row=await one('SELECT data FROM file_metadata WHERE file_id=? AND user_id=?',id,owner);return row?JSON.parse(row.data):{}};
 const saveMetadata=async(id:string,owner:string,data:Row)=>run('INSERT INTO file_metadata(file_id,user_id,data,updated) VALUES(?,?,?,?) ON CONFLICT(file_id) DO UPDATE SET data=excluded.data,updated=excluded.updated WHERE file_metadata.user_id=excluded.user_id',id,owner,JSON.stringify(data),new Date().toISOString());
 const categories=async(owner:string)=>[...BUILTIN_CATEGORIES,...(await all('SELECT id,name FROM categories WHERE user_id=? ORDER BY name',owner)).map(c=>({id:c.id,name:c.name,builtin:false,icon:'folder'}))];
 const category=async(value:unknown,name:string,mime:string)=>{if(value==null||value===''||value==='auto')return inferCategory(name,mime);const id=String(value);if(BUILTIN_CATEGORIES.some(c=>c.id===id)||await one('SELECT id FROM categories WHERE id=? AND user_id=?',id,userId))return id;fail(400,'Kategorie nicht gefunden.');};
 const decorate=async(rows:Row[]):Promise<Row[]>=>{const found=new Map<string,Row>(),sources=new Map<string,string>(),labels=new Map<string,string>();for(const c of BUILTIN_CATEGORIES)labels.set(c.id,c.name);for(const owner of new Set(rows.map(f=>f.user_id))){for(const f of await all('SELECT f.id,c.provider FROM files f JOIN cloud_files cf ON cf.object_id=COALESCE(f.object_id,f.id) AND cf.user_id=f.user_id LEFT JOIN cloud_connections c ON c.id=cf.connection_id AND c.user_id=cf.user_id WHERE f.user_id=?',owner))sources.set(f.id,f.provider||'disconnected');for(const c of await categories(owner))labels.set(c.id,c.name);const ids=rows.filter(f=>f.user_id===owner).map(f=>f.id);for(let start=0;start<ids.length;start+=90){const batch=ids.slice(start,start+90),records=await all(`SELECT file_id,data FROM file_metadata WHERE user_id=? AND file_id IN (${batch.map(()=>'?').join(',')})`,owner,...batch);for(const record of records)found.set(record.file_id,JSON.parse(record.data))}}return rows.map(f=>({...f,mime:mediaType(f.name,f.mime),category_name:labels.get(f.kind)||'Sonstiges',metadata:found.get(f.id)||{},cloud_source:sources.get(f.id)||null}))};
 const insertFile=async(f:Row)=>{if(!BUILTIN_CATEGORIES.some(c=>c.id===f.kind)&&!await one('SELECT id FROM categories WHERE id=? AND user_id=?',f.kind,userId))f.kind='other';await run('INSERT INTO files(id,user_id,folder,name,mime,size,created,kind,series,season,episode) VALUES(?,?,?,?,?,?,?,?,?,?,?)',f.id,userId,f.folder,f.name,f.mime,f.size,f.created,f.kind,f.series,f.season,f.episode);if(f.metadata)await saveMetadata(f.id,userId!,normalizeMetadata(f.metadata))};
 const tmdbToken=async(owner=userId)=>{const row=await one('SELECT tmdb_token FROM metadata_settings WHERE user_id=?',owner);if(row){if(!settingsKey)fail(503,'TMDB-Einstellungen sind noch nicht verfügbar.');return openToken(row.tmdb_token,settingsKey,owner!)}if(siteTmdbToken)return siteTmdbToken;fail(428,'Bitte zuerst in den Einstellungen einen TMDB-Schlüssel hinterlegen.')};
 if(subsonicAccountPath(path))return manageSubsonicAccounts(request,db,userId!,settingsKey);
 if(opdsAccountPath(path))return manageOpdsAccounts(request,db,userId!,body);
 if(audiobookshelfAccountPath(path))return manageAudiobookshelfAccounts(request,db,userId!,body);
 if(path.startsWith('/api/cloud/'))return cloud!.handle(request,userId!);
 const readBounded=async(limit:number)=>{if(Number(request.headers.get('content-length')||0)>limit)fail(413,'Dateiabschnitt zu groß.');const reader=request.body?.getReader();if(!reader)return new Uint8Array();const chunks:Uint8Array[]=[];let length=0;for(;;){const part=await reader.read();if(part.done)break;length+=part.value.length;if(length>limit){await reader.cancel();fail(413,'Dateiabschnitt zu groß.')}chunks.push(part.value)}const bytes=new Uint8Array(length);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.length}return bytes};
 const uploadPart=async(upload:R2MultipartUpload,number:number,expected:number)=>{
  if(!request.body)fail(400,'Upload-Abschnitt fehlt.');
  const stream=new FixedLengthStream(expected),controller=new AbortController();let length=0;
  const validator=new TransformStream<Uint8Array,Uint8Array>({transform(bytes,c){length+=bytes.byteLength;if(length>expected)fail(400,'Ungültige Abschnittsgröße.');c.enqueue(bytes)},flush(){if(length!==expected)fail(400,'Ungültige Abschnittsgröße.')}});
  const transfer=request.body.pipeThrough(validator).pipeTo(stream.writable,{signal:controller.signal}).then(()=>null,error=>error);
  try{const result=await upload.uploadPart(number,stream.readable);const error=await transfer;if(error)throw error;return result}catch(error){controller.abort();await transfer;if(length!==expected)fail(400,'Ungültige Abschnittsgröße.');throw error}
 };
 const poster=async(f:Row)=>{const image=await bucket.get(posterKey(f));if(!image)return new Response(null,{status:404});const headers=new Headers({'Content-Type':image.httpMetadata?.contentType||'image/jpeg','Content-Length':String(image.size),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'});return new Response(method==='HEAD'?null:fixedLengthBody(image.body,image.size,lifetime),{headers})};
 if(path==='/api/tmdb/settings'){
  if(method==='GET'){const row=await one('SELECT user_id FROM metadata_settings WHERE user_id=?',userId);return json({configured:!!row||!!siteTmdbToken,personal:!!row})}
  if(method==='PUT'){if(!settingsKey)fail(503,'Geschützte TMDB-Einstellungen sind noch nicht bereit.');const b=await body(),token=str(b.token,4096);if(!/^[a-zA-Z0-9._-]{24,4096}$/.test(token))fail(400,'Bitte einen gültigen API Read Access Token oder API-Schlüssel eingeben.');await tmdbGet('/configuration',{},token);const encrypted=await sealToken(token,settingsKey,userId!);await run('INSERT INTO metadata_settings(user_id,tmdb_token,updated) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET tmdb_token=excluded.tmdb_token,updated=excluded.updated',userId,encrypted,new Date().toISOString());return json({configured:true})}
  if(method==='DELETE'){await run('DELETE FROM metadata_settings WHERE user_id=?',userId);return json({configured:!!siteTmdbToken})}
 }
 if(path==='/api/tmdb/search'&&method==='GET'){const query=str(url.searchParams.get('q'),200),kind=url.searchParams.get('kind')==='series'?'series':'movie';if(query.length<2)fail(400,'Bitte mindestens zwei Zeichen eingeben.');const data=await tmdbGet('/search/'+(kind==='series'?'tv':'movie'),{query,language:'de-DE',include_adult:'false'},await tmdbToken());return json({results:(data.results||[]).slice(0,12).map((r:Row)=>({id:r.id,title:r.title||r.name,year:(r.release_date||r.first_air_date||'').slice(0,4),plot:r.overview,poster_url:r.poster_path?`https://image.tmdb.org/t/p/w185${r.poster_path}`:'',kind}))})}
 if(path==='/api/tmdb/scrape'&&method==='POST'){
  const {ids}=await body();
  if(!Array.isArray(ids)||!ids.length||ids.length>48||ids.some(id=>typeof id!=='string'||!/^\w{1,64}$/.test(id)))fail(400,'Bitte 1 bis 48 gültige Dateien auswählen.');
  const selected=[...new Set<string>(ids)],token=await tmdbToken();
  let seriesIndex:Promise<Map<string,ReturnType<typeof tmdbScrapeInput>[]>>|undefined;
  const scrape=tmdbScraper(token,async info=>{
   seriesIndex??=all(`SELECT f.name,f.kind,f.series,f.season,f.episode,
    json_extract(m.data,'$.title') AS meta_title,json_extract(m.data,'$.tmdb_id') AS meta_id,
    json_extract(m.data,'$.episode_title') AS meta_episode FROM files f
    LEFT JOIN file_metadata m ON m.file_id=f.id AND m.user_id=f.user_id WHERE f.user_id=? AND f.kind='series'`,userId).then(rows=>{
     const index=new Map<string,ReturnType<typeof tmdbScrapeInput>[]>();
     for(const row of rows){
      const peer=tmdbScrapeInput({...row,metadata:{title:row.meta_title,tmdb_id:row.meta_id,episode_title:row.meta_episode}});
      if(!index.has(peer.key))index.set(peer.key,[]);
      index.get(peer.key)!.push(peer);
     }
     return index;
    });
   return ((await seriesIndex).get(info.key)||[]).filter(peer=>!info.year||!peer.year||peer.year===info.year);
  });
  const rows=await all(`SELECT f.*,m.data AS metadata_json FROM files f LEFT JOIN file_metadata m ON m.file_id=f.id AND m.user_id=f.user_id
   WHERE f.user_id=? AND f.id IN (${selected.map(()=>'?').join(',')})`,userId,...selected);
  const byId=new Map(rows.map(row=>[row.id,row]));
  let stopStatus=0;
  const scrapeFile=async(id:string)=>{
   const f=byId.get(id);
   if(!f||!['movie','series'].includes(f.kind))return {id,status:'skipped',message:'Datei ist kein Film und keine Serienepisode.'};
   if(stopStatus)return {id,status:'error',message:stopStatus===429?'TMDB-Anfragelimit erreicht.':'TMDB-Anmeldung fehlgeschlagen.'};
   try{
    const before=f.metadata_json?JSON.parse(f.metadata_json):{},result=await scrape({...f,metadata:before});
    const merged={...before};
    for(const [key,value] of Object.entries(result.metadata)){
     if((!merged[key]||Array.isArray(merged[key])&&!merged[key].length)&&(Array.isArray(value)?value.length:value))merged[key]=value;
    }
    if(!before.people?.length&&merged.people?.length)merged.people_source=result.metadata.people_source;
    const series=f.series||result.series||'',season=result.inferred?result.season:f.season,episode=result.inferred?result.episode:f.episode;
    const next=JSON.stringify(merged),sameFile=series===f.series&&season===f.season&&episode===f.episode;
    if(next===f.metadata_json&&sameFile)return {id,status:'unchanged'};
    const upsert=db.prepare(`INSERT INTO file_metadata(file_id,user_id,data,updated)
     SELECT id,user_id,?,? FROM files WHERE id=? AND user_id=? AND kind=? AND name=? AND series=? AND season=? AND episode=?
      AND (SELECT data FROM file_metadata WHERE file_id=files.id AND user_id=files.user_id) IS ?
     ON CONFLICT(file_id) DO UPDATE SET data=excluded.data,updated=excluded.updated WHERE file_metadata.user_id=excluded.user_id`)
     .bind(next,new Date().toISOString(),id,userId,f.kind,f.name,f.series,f.season,f.episode,f.metadata_json);
    const changes=sameFile?[await upsert.run()]:await db.batch([upsert,db.prepare(`UPDATE files SET series=?,season=?,episode=?
     WHERE id=? AND user_id=? AND changes()=1`).bind(series,season,episode,id,userId)]);
    return changes[0].meta.changes?{id,status:'updated'}:{id,status:'skipped',message:'Datei wurde während des Abrufs geändert.'};
   }catch(e){
    if(e instanceof TmdbError){
     if(e.status===401||e.status===429)stopStatus=e.status;
     return {id,status:[404,409].includes(e.status)?'skipped':'error',message:e.message};
    }
    throw e;
   }
  };
  const results:Awaited<ReturnType<typeof scrapeFile>>[]=[];
  for(let start=0;start<selected.length;start+=4)results.push(...await Promise.all(selected.slice(start,start+4).map(scrapeFile)));
  return json({results,stopStatus});
 }
 let tmdbMatch=path.match(/^\/api\/tmdb\/(movie|series)\/(\d+)$/);if(tmdbMatch&&method==='GET'){const kind=tmdbMatch[1] as 'movie'|'series',season=Math.max(0,Math.floor(Number(url.searchParams.get('season'))||0)),episode=pos(url.searchParams.get('episode'));return json(await tmdbDetails(kind,tmdbMatch[2],season,episode,await tmdbToken()))}

 const getLink=async(token:string)=>await one('SELECT * FROM links WHERE token=?',token)??fail(404,'Dieser Link wurde widerrufen oder existiert nicht.');
 const sharedFiles=async(l:Row)=>{
  if(l.type==='file')return all('SELECT * FROM files WHERE id=? AND user_id=?',l.target,l.user_id);
  if(l.type==='folder')return all('WITH RECURSIVE tree(id) AS (SELECT id FROM folders WHERE id=? AND user_id=? UNION ALL SELECT f.id FROM folders f JOIN tree t ON f.parent=t.id WHERE f.user_id=?) SELECT * FROM files WHERE user_id=? AND folder IN (SELECT id FROM tree)',l.target,l.user_id,l.user_id,l.user_id);
  const ids:string[]=JSON.parse(l.target),found=new Map<string,Row>();for(let i=0;i<ids.length;i+=90){const batch=ids.slice(i,i+90);for(const f of await all(`SELECT * FROM files WHERE user_id=? AND id IN (${batch.map(()=>'?').join(',')})`,l.user_id,...batch))found.set(f.id,f)}return ids.map(id=>found.get(id)).filter((f):f is Row=>!!f);
 };
 const content=async(f:Row, options?:{mime:string,download:boolean})=>{
  const mediaMethod=options&&method==='POST'?'GET':method;
  const storageKey=objectKey(f),head=await bucket.head(storageKey);if(!head)fail(404,'Datei nicht gefunden.');
  const mime=options?.mime||mediaType(f.name,f.mime);
  if(!options&&url.searchParams.get('info')==='1'&&mediaMethod==='GET'){
   const info=await inspectMp4(bucket,storageKey,head.size),index=info.fragmented?await fragmentIndex(bucket,storageKey,head):null;
   return json({name:f.name,mime,...info,duration:index?.duration||info.duration,hls:!!index,segments:index?.segments.length||0});
  }
  const headers=new Headers({'Content-Type':mime,'Cache-Control':'private, no-store, no-transform','Accept-Ranges':'bytes','X-Content-Type-Options':'nosniff','Content-Encoding':'identity','ETag':head.httpEtag,'Last-Modified':head.uploaded.toUTCString()});
  headers.set('Content-Disposition',(options?options.download:url.searchParams.get('download')==='1')||!mime.startsWith('video/')&&!mime.startsWith('audio/')&&!['image/jpeg','image/png','image/webp','image/gif'].includes(mime)?filename(f.name):filename(f.name).replace('attachment;','inline;'));
  if(!mime.startsWith('video/')&&!mime.startsWith('audio/'))headers.set('Content-Security-Policy',"sandbox; default-src 'none'");
  const ifRange=request.headers.get('if-range');
  const rangeHeader=mediaMethod==='GET'&&(!ifRange||ifRange===head.httpEtag||ifRange===head.uploaded.toUTCString())?request.headers.get('range'):null;
  let range:{offset:number,length:number}|null;
  try{range=singleRange(rangeHeader,head.size)}catch{headers.set('Content-Range',`bytes */${head.size}`);headers.set('Content-Length','0');return new Response(null,{status:416,headers})}
  const length=range?.length??head.size,status=range?206:200;
  headers.set('Content-Length',String(length));
  if(range)headers.set('Content-Range',`bytes ${range.offset}-${range.offset+length-1}/${head.size}`);
  if(mediaMethod==='HEAD'||!length)return new Response(null,{status,headers});
  const object=await bucket.get(storageKey,range?{range}:{});if(!object)fail(404,'Datei nicht gefunden.');
  return new Response(fixedLengthBody(object.body,length,lifetime),{status,headers,encodeBody:'manual'} as ResponseInit);
 };
 if(audiobookshelf)return handleAudiobookshelf(request,db,bucket,{body,content,poster},settingsKey);
 if(opdsPath(path))return handleOpds(request,db,{content,poster});
 if(subsonic)return handleSubsonic(request,db,settingsKey,{content,poster});
 const hls=async(f:Row,part:string,base:string)=>{
  if(!['GET','HEAD'].includes(method))fail(405,'Nur Lesezugriff erlaubt.');
  const storageKey=objectKey(f),head=await bucket.head(storageKey);if(!head)fail(404,'Video nicht gefunden.');
  const index=await fragmentIndex(bucket,storageKey,head);if(!index)fail(409,'Für dieses Video ist kein kompatibler Fragmentindex verfügbar. Bitte Originaldatei verwenden.');
  if(f.hls!=='ready')await run("UPDATE files SET hls='ready' WHERE id=? AND user_id=?",f.id,f.user_id);
  if(part==='index.m3u8')return new Response(method==='HEAD'?null:hlsManifest(index,base),{headers:{'Content-Type':'application/vnd.apple.mpegurl','Cache-Control':'private, no-store, no-transform'}});
  const segment=/^segment(\d+)\.m4s$/.exec(part);
  const item=part==='init.mp4'?{offset:0,length:index.initLength}:segment?index.segments[Number(segment[1])]:null;
  if(!item)fail(404,'Videofragment nicht gefunden.');
  const headers=new Headers({'Content-Type':'video/mp4','Cache-Control':'private, no-store, no-transform','Content-Length':String(item.length),'Accept-Ranges':'bytes'});
  if(method==='HEAD')return new Response(null,{headers});
  if(part==='init.mp4'){const object=await bucket.get(storageKey,{range:item});if(!object)fail(404,'Video nicht gefunden.');return new Response(fixedLengthBody(object.body,item.length,lifetime),{headers})}
  return new Response(await fragmentBody(bucket,storageKey,item.offset,item.length,lifetime),{headers});
 };
 if(jellyfinPath(path))return handleJellyfin(request,db,bucket,{files:async owner=>decorate(await all('SELECT * FROM files WHERE user_id=? ORDER BY created DESC',owner)),content,poster,hls,people:async f=>{
   const m=f.metadata||{},source=f.kind+':'+m.tmdb_id;if(!m.tmdb_id||!m.cast||m.people_source===source)return;
   // Backfill portraits only. Existing titles, genres and manual edits stay intact.
   try{const detail=await tmdbGet('/'+(f.kind==='series'?'tv':'movie')+'/'+m.tmdb_id,{language:'de-DE',append_to_response:'credits'},await tmdbToken(f.user_id)),people=tmdbPeople(detail);
    await run("UPDATE file_metadata SET data=json_set(data,'$.people',json(?),'$.people_source',?) WHERE file_id=? AND user_id=? AND json_extract(data,'$.tmdb_id')=?",JSON.stringify(people),source,f.id,f.user_id,m.tmdb_id);
    f.metadata={...m,people,people_source:source};
   }catch{/* A missing provider or profile must never block playback. */}
  }});
 if(iptvPath(path)){
  if(!['GET','HEAD'].includes(method))fail(405,'Nur Lesezugriff erlaubt.');
  const {username,password,token,playback}=iptvCredentials(url);
  if(!token)fail(401,'Ungültige Xtream-Zugangsdaten.');
  const link=await one('SELECT * FROM links WHERE token=?',token);if(!link)fail(401,'Dieser Zugang wurde widerrufen oder existiert nicht.');
  const action=url.searchParams.get('action');
  if(path==='/get.php')return new Response(null,{status:302,headers:{Location:`${url.origin}/playlist/${token}/library.m3u`,'Cache-Control':'private, no-store'}});
  if(path==='/xmltv.php')return new Response('<?xml version="1.0" encoding="UTF-8"?><tv generator-info-name="AndreDrive"/>',{headers:{'Content-Type':'application/xml','Cache-Control':'private, no-store'}});
  if(!playback&&!action)return iptvLogin(url,link,username,password);
  if(['get_live_categories','get_live_streams'].includes(action||''))return json([]);
  if(['get_short_epg','get_simple_data_table'].includes(action||''))return json({epg_listings:[]});
  const catalog=await iptvCatalog(db,bucket,await decorate(await sharedFiles(link)),url.origin,token);
  if(playback){const f=catalog.files.find(f=>String(f.iptv_id)===playback[4]&&f.kind===(playback[1]==='movie'?'movie':'series'));if(!f)fail(404,'Video nicht gefunden.');const extension=await catalog.prepare(f);if(playback[5].toLowerCase()!==extension)fail(404,'Videoformat nicht gefunden.');return extension==='m3u8'?hls(f,'index.m3u8',`${url.origin}/hls/${token}/${f.id}`):content(f)}
  return catalog.api(url);
 }
 const storage=driveStorage(db,bucket,userId!);
 if(path==='/api/jellyfin/accounts'){
  if(method==='GET')return json({serverUrl:url.origin+'/jellyfin',accounts:await all('SELECT id,label,username,created FROM jelly_accounts WHERE user_id=? ORDER BY created DESC',userId)});
  if(method==='POST'){const b=await body(),password=uuid()+uuid(),account={id:uuid(),label:str(b.label,80)||'Mein Jellyfin-Zugang',username:'jf_'+uuid(),created:new Date().toISOString()};await run('INSERT INTO jelly_accounts(id,user_id,label,username,password_hash,created) VALUES(?,?,?,?,?,?)',account.id,userId,account.label,account.username,await webdavHash(password),account.created);return json({...account,password,serverUrl:url.origin+'/jellyfin'},201)}
 }
 const jellyAccount=path.match(/^\/api\/jellyfin\/accounts\/([^/]+)$/);if(jellyAccount&&method==='DELETE'){const account=await one('SELECT id FROM jelly_accounts WHERE id=? AND user_id=?',jellyAccount[1],userId);if(!account)fail(404,'Zugang nicht gefunden.');await db.batch([db.prepare('DELETE FROM jelly_sessions WHERE account_id=?').bind(account.id),db.prepare('DELETE FROM jelly_accounts WHERE id=? AND user_id=?').bind(account.id,userId)]);return json({ok:true})}
 if(path==='/api/romm/settings'){
  if(method==='GET'){
   const settings=await one('SELECT server_url,folder_id,username FROM romm_settings WHERE user_id=?',userId);
   return json({settings,endpoint:url.origin+'/romm-library/'});
  }
  if(method==='PUT'){
   const b=await body();
   let server:URL;
   try{server=new URL(typeof b.server_url==='string'&&b.server_url.length<=2048?b.server_url.trim():'')}catch{fail(400,'Bitte eine vollständige RomM-URL eingeben.')}
   if(!['https:','http:'].includes(server.protocol)||server.username||server.password||server.search||server.hash)fail(400,'Bitte eine HTTP- oder HTTPS-URL ohne Zugangsdaten, Abfrage oder Anker eingeben.');
   const source=await folder(typeof b.folder_id==='string'?b.folder_id:'');
   await run(`INSERT INTO romm_settings(user_id,server_url,folder_id) VALUES(?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET server_url=excluded.server_url,folder_id=excluded.folder_id,
    username=CASE WHEN romm_settings.folder_id=excluded.folder_id THEN romm_settings.username END,
    password_hash=CASE WHEN romm_settings.folder_id=excluded.folder_id THEN romm_settings.password_hash END`,userId,server.href,source.id);
   return json({ok:true});
  }
 }
 if(path==='/api/romm/access'){
  if(method==='POST'){
   const settings=await one('SELECT folder_id FROM romm_settings WHERE user_id=?',userId);
   if(!settings)fail(409,'Bitte zuerst die RomM-Einstellungen speichern.');
   await folder(settings.folder_id);
   const username='romm_'+uuid(),password=uuid()+uuid();
   const result=await run('UPDATE romm_settings SET username=?,password_hash=? WHERE user_id=? AND folder_id=?',username,await webdavHash(password),userId,settings.folder_id);
   if(!result.meta.changes)fail(409,'Der ROM-Ordner wurde geändert. Bitte erneut versuchen.');
   return json({username,password},201);
  }
  if(method==='DELETE'){
   await run('UPDATE romm_settings SET username=NULL,password_hash=NULL WHERE user_id=?',userId);
   return json({ok:true});
  }
 }
 if(path==='/api/webdav/accounts'){
  if(method==='GET')return json({endpoint:url.origin+'/webdav/',accounts:await all('SELECT id,label,username,can_write,created FROM webdav_accounts WHERE user_id=? ORDER BY created DESC',userId),maxPutBytes:64*1024**2});
  if(method==='POST'){const b=await body(),password=uuid()+uuid(),account={id:uuid(),label:str(b.label,80)||'Mein WebDAV',username:'ad_'+uuid(),can_write:Number(b.can_write===true),created:new Date().toISOString()};await run('INSERT INTO webdav_accounts(id,user_id,label,username,password_hash,can_write,created) VALUES(?,?,?,?,?,?,?)',account.id,userId,account.label,account.username,await webdavHash(password),account.can_write,account.created);return json({...account,password,endpoint:url.origin+'/webdav/'},201)}
 }
 const davAccount=path.match(/^\/api\/webdav\/accounts\/([^/]+)$/);if(davAccount&&method==='DELETE'){await run('DELETE FROM webdav_accounts WHERE id=? AND user_id=?',davAccount[1],userId);return json({ok:true})}
 if(path==='/api/files/transfer'&&method==='POST'){
  const b=await body();if(!Array.isArray(b.ids)||!b.ids.length||b.ids.length>100||!['move','copy'].includes(b.action))fail(400,'Bitte 1 bis 100 Dateien und eine Aktion auswählen.');
  const ids=[...new Set<string>(b.ids.map(String))],parent=b.folder||null;await storage.folder(parent);for(const id of ids)await storage.file(id);
  const result=[];for(const id of ids)result.push(await storage.transfer(id,parent,b.action==='copy'));return json({files:await decorate(result)});
 }
 if(path==='/api/files/delete'&&method==='POST'){const b=await body();if(!Array.isArray(b.ids)||!b.ids.length||b.ids.length>100)fail(400,'Bitte 1 bis 100 Dateien pro Anfrage auswählen.');const ids=[...new Set<string>(b.ids.map(String))];for(const id of ids)await file(id);for(const id of ids)await storage.trashFile(id);return json({ok:true,count:ids.length})}
 if(path==='/api/trash'&&method==='GET'){const rows=await all('SELECT data,deleted FROM trash_files WHERE user_id=? ORDER BY deleted DESC',userId);return json({files:rows.map(t=>({...JSON.parse(t.data),deleted:t.deleted}))})}
 if(path==='/api/trash'&&['POST','DELETE'].includes(method)){const b=await body();if(!Array.isArray(b.ids)||!b.ids.length||b.ids.length>100)fail(400,'Bitte 1 bis 100 Dateien pro Anfrage auswählen.');const ids=[...new Set<string>(b.ids.map(String))];for(const id of ids)if(!await one('SELECT id FROM trash_files WHERE id=? AND user_id=?',id,userId))fail(404,'Datei im Papierkorb nicht gefunden.');for(const id of ids){if(method==='POST')await storage.restoreFile(id);else await storage.purgeFile(id)}return json({ok:true,count:ids.length})}
 if(path==='/api/categories'){
  if(method==='GET')return json({categories:await categories(userId!)});
  if(method==='POST'){const b=await body(),name=str(b.name,60).replace(/\s+/g,' '),name_key=categoryKey(name);if(!name_key)fail(400,'Bitte einen Kategorienamen eingeben.');if(BUILTIN_CATEGORIES.some(c=>categoryKey(c.name)===name_key)||await one('SELECT id FROM categories WHERE user_id=? AND name_key=?',userId,name_key))fail(409,'Diese Kategorie existiert bereits.');const c={id:'custom_'+uuid(),user_id:userId,name,name_key,created:new Date().toISOString()};await run('INSERT INTO categories(id,user_id,name,name_key,created) VALUES(?,?,?,?,?)',c.id,userId,name,name_key,c.created);return json({...c,builtin:false,icon:'folder'},201)}
 }
 const categoryMatch=path.match(/^\/api\/categories\/([^/]+)$/);
 if(categoryMatch){const c=await one('SELECT * FROM categories WHERE id=? AND user_id=?',categoryMatch[1],userId);if(!c)fail(404,'Eigene Kategorie nicht gefunden.');
  if(method==='PATCH'){const b=await body(),name=str(b.name,60).replace(/\s+/g,' '),name_key=categoryKey(name);if(!name_key)fail(400,'Bitte einen Kategorienamen eingeben.');if(BUILTIN_CATEGORIES.some(c=>categoryKey(c.name)===name_key)||await one('SELECT id FROM categories WHERE user_id=? AND name_key=? AND id<>?',userId,name_key,c.id))fail(409,'Diese Kategorie existiert bereits.');await run('UPDATE categories SET name=?,name_key=? WHERE id=? AND user_id=?',name,name_key,c.id,userId);return json({ok:true})}
  if(method==='DELETE'){await db.batch([db.prepare("UPDATE files SET kind='other' WHERE kind=? AND user_id=?").bind(c.id,userId),db.prepare('DELETE FROM categories WHERE id=? AND user_id=?').bind(c.id,userId)]);return json({ok:true})}
 }
 if(path==='/api/files/category'&&method==='POST'){
  const b=await body();if(!Array.isArray(b.ids)||!b.ids.length||b.ids.length>100)fail(400,'Bitte 1 bis 100 Dateien auswählen.');const kind=await category(b.kind,'',''),ids=[...new Set<string>(b.ids.map(String))];for(const id of ids)await file(id);await db.batch(ids.map(id=>db.prepare('UPDATE files SET kind=? WHERE id=? AND user_id=?').bind(kind,id,userId)));return json({ok:true});
 }
 if(path==='/api/library'&&method==='GET'){const [files,folders,links]=await Promise.all([all('SELECT * FROM files WHERE user_id=? ORDER BY created DESC',userId),all('SELECT * FROM folders WHERE user_id=? ORDER BY name',userId),all('SELECT * FROM links WHERE user_id=? ORDER BY created DESC',userId)]);return json({files:await decorate(files),folders,links,categories:await categories(userId!)})}
 if(path==='/api/folders'&&method==='POST'){const b=await body(),name=str(b.name,120);if(!name)fail(400,'Bitte einen Ordnernamen eingeben.');const parent=b.parent||null;if(parent)await folder(parent);const f={id:uuid(),user_id:userId,name,parent,created:new Date().toISOString()};await run('INSERT INTO folders VALUES(?,?,?,?,?)',f.id,userId,name,parent,f.created);return json(f)}
 if(path==='/api/uploads'&&method==='POST'){
  const b=await body(),name=str(b.name,255),size=Number(b.size),folderId=b.folder||null;
  if(!name||!Number.isSafeInteger(size)||size<0||size>MAX)fail(400,'Dateiname und gültige Größe bis 100 GB erforderlich.');if(folderId)await folder(folderId);if(Math.ceil(size/CHUNK)>MAX_PARTS)fail(400,'Zu viele Upload-Abschnitte.');
  // Discard abandoned multipart uploads after 24 hours when starting a new upload.
  const stale=await all('SELECT id,upload_id FROM uploads WHERE user_id=? AND created<? LIMIT 10',userId,Date.now()-86400000);
  for(const u of stale){try{await bucket.resumeMultipartUpload(key(u.id),u.upload_id).abort()}catch{}await db.batch([db.prepare('DELETE FROM upload_parts WHERE upload=?').bind(u.id),db.prepare('DELETE FROM uploads WHERE id=? AND user_id=?').bind(u.id,userId)])}
  const pending=await one('SELECT COUNT(*) AS n FROM uploads WHERE user_id=?',userId);if(Number(pending?.n)>=20)fail(429,'Zu viele laufende Uploads. Bitte vorhandene Uploads abschließen.');
  const f={id:uuid(),user_id:userId,folder:folderId,name,mime:/^[\w.+-]+\/[\w.+-]+$/.test(b.mime)?b.mime:'application/octet-stream',size,created:new Date().toISOString(),kind:await category(b.kind,name,str(b.mime,100)),series:str(b.series),season:pos(b.season),episode:pos(b.episode),chunkBytes:CHUNK,metadata:b.metadata?normalizeMetadata(b.metadata):undefined};
  const upload=await bucket.createMultipartUpload(key(f.id),{httpMetadata:{contentType:f.mime}});try{await run('INSERT INTO uploads VALUES(?,?,?,?,?)',f.id,userId,upload.uploadId,JSON.stringify(f),Date.now())}catch(e){await upload.abort();throw e}return json({id:f.id,chunkBytes:CHUNK});
 }
 let m=path.match(/^\/api\/uploads\/([^/]+)(?:\/(parts\/\d+|complete|empty))?$/);
 if(m){const id=m[1],action=m[2];const u=await one('SELECT * FROM uploads WHERE id=? AND user_id=?',id,userId);if(!u){if((action==='complete'&&method==='POST')||(!action&&method==='GET')){const f=await one('SELECT * FROM files WHERE id=? AND user_id=?',id,userId);if(f)return json(!action?{completed:true,file:f}:f)}fail(404,'Upload nicht gefunden.')}const f=JSON.parse(u.metadata),chunk=uploadChunkBytes(f),upload=bucket.resumeMultipartUpload(key(id),u.upload_id);
  if(!action&&method==='GET')return json({id,name:f.name,size:f.size,chunkBytes:chunk,completed:false,parts:(await all('SELECT part FROM upload_parts WHERE upload=? ORDER BY part',id)).map(p=>p.part)});
  if(!action&&method==='DELETE'){await upload.abort();await db.batch([db.prepare('DELETE FROM upload_parts WHERE upload=?').bind(id),db.prepare('DELETE FROM uploads WHERE id=? AND user_id=?').bind(id,userId)]);return json({ok:true})}
  if(action?.startsWith('parts/')&&method==='PUT'){const number=Number(action.split('/')[1]),count=Math.ceil(f.size/chunk);if(number<1||number>count)fail(400,'Ungültiger Upload-Abschnitt.');const expected=Math.min(chunk,f.size-(number-1)*chunk),declared=request.headers.get('content-length');if(declared&&Number(declared)!==expected)fail(400,'Ungültige Abschnittsgröße.');const part=await uploadPart(upload,number,expected);await run('INSERT INTO upload_parts(upload,part,etag,size) VALUES(?,?,?,?) ON CONFLICT(upload,part) DO UPDATE SET etag=excluded.etag,size=excluded.size',id,number,part.etag,expected);await run('UPDATE uploads SET created=? WHERE id=? AND user_id=?',Date.now(),id,userId);return json({ok:true,partNumber:number})}
  if(action==='empty'&&method==='POST'&&f.size===0){await upload.abort();await bucket.put(key(id),new Uint8Array(),{httpMetadata:{contentType:f.mime}});await insertFile(f);await run('DELETE FROM uploads WHERE id=? AND user_id=?',id,userId);return json(f)}
  if(action==='complete'&&method==='POST'&&f.size>0){const parts=await all('SELECT part,etag,size FROM upload_parts WHERE upload=? ORDER BY part',id);if(parts.length!==Math.ceil(f.size/chunk)||parts.reduce((s,p)=>s+p.size,0)!==f.size)fail(409,'Es fehlen Upload-Abschnitte. Bitte erneut hochladen.');const existing=await bucket.head(key(id));if(!existing)await upload.complete(parts.map(p=>({partNumber:p.part,etag:p.etag})));const object=await bucket.head(key(id));if(!object||object.size!==f.size)fail(409,'Upload konnte nicht geprüft werden.');await insertFile(f);await db.batch([db.prepare('DELETE FROM upload_parts WHERE upload=?').bind(id),db.prepare('DELETE FROM uploads WHERE id=? AND user_id=?').bind(id,userId)]);return json(f)}
 }
 m=path.match(/^\/api\/files\/([^/]+)(?:\/(content|thumb|poster|hls\/.*))?$/);
 if(m){const f=await file(m[1]);if(m[2]==='content'&&['GET','HEAD'].includes(method))return content(f);if((m[2]==='thumb'||m[2]==='poster')&&['GET','HEAD'].includes(method))return poster(f);
  if(m[2]==='poster'&&method==='POST'){const bytes=await readBounded(10*1024**2),mime=imageMime(bytes);if(!mime)fail(400,'Bitte JPG, PNG, WebP oder GIF als Cover verwenden.');const posterId=uuid();await bucket.put(`posters/${userId}/${posterId}`,bytes,{httpMetadata:{contentType:mime}});await run('UPDATE files SET poster_id=? WHERE id=? AND user_id=?',posterId,f.id,userId);await saveMetadata(f.id,userId!,{...await metadata(f.id,userId!),poster_source:'upload',poster_url:''});return json({ok:true})}if(m[2]?.startsWith('hls/'))return hls(f,m[2].slice(4),`${url.origin}/api/files/${f.id}/hls`);
  if(!m[2]&&method==='PATCH'){const b=await body();let normalized:Row|undefined;if(b.metadata!==undefined){try{normalized=normalizeMetadata({...await metadata(f.id,userId!),...b.metadata})}catch(e){fail(400,e instanceof Error?e.message:'Ungültige Metadaten.')}}await run('UPDATE files SET starred=?,kind=?,series=?,season=?,episode=? WHERE id=? AND user_id=?',b.starred==null?f.starred:Number(!!b.starred),b.kind==null?f.kind:await category(b.kind,f.name,f.mime),b.series==null?f.series:str(b.series),b.season==null?f.season:Math.max(0,Math.min(100000,Math.floor(Number(b.season)||0))),b.episode==null?f.episode:pos(b.episode),f.id,userId);if(normalized)await saveMetadata(f.id,userId!,normalized);return json({ok:true})}
 }
 if(path==='/api/links'&&method==='POST'){const b=await body();if(!['file','folder','playlist','collection'].includes(b.type))fail(400,'Ungültiger Linktyp.');let target:string;if(b.type==='playlist'||b.type==='collection'){const max=b.type==='playlist'?500:10000;if(!Array.isArray(b.target)||!b.target.length||b.target.length>max)fail(400,`Bitte 1 bis ${max} Dateien auswählen.`);const ids=[...new Set<string>(b.target.map(String))].sort();for(let i=0;i<ids.length;i+=90){const batch=ids.slice(i,i+90),rows=await all(`SELECT * FROM files WHERE user_id=? AND id IN (${batch.map(()=>'?').join(',')})`,userId,...batch);if(rows.length!==batch.length)fail(404,'Datei nicht gefunden.');if(b.type==='playlist'&&rows.some(f=>!mediaType(f.name,f.mime).startsWith('video/')||!['movie','series'].includes(f.kind)))fail(400,'Nur Filme und Serien in VOD-Playlists erlaubt.')}target=JSON.stringify(ids)}else{target=String(b.target);if(b.type==='file')await file(target);else await folder(target)}let link=await one('SELECT * FROM links WHERE user_id=? AND type=? AND target=?',userId,b.type,target);if(!link){link={token:uuid()+uuid(),user_id:userId,type:b.type,target,created:new Date().toISOString()};await run('INSERT INTO links VALUES(?,?,?,?,?)',link.token,userId,link.type,target,link.created)}return json(link)}
 m=path.match(/^\/api\/links\/([^/]+)$/);if(m&&method==='DELETE'){await run('DELETE FROM links WHERE token=? AND user_id=?',m[1],userId);return json({ok:true})}
 m=path.match(/^\/api\/shared\/([^/]+)$/);if(m&&['GET','HEAD'].includes(method)){const l=await getLink(m[1]);return json({name:l.type==='folder'?(await one('SELECT name FROM folders WHERE id=? AND user_id=?',l.target,l.user_id))?.name||'Geteilter Ordner':'Geteilte Sammlung',type:l.type,files:(await decorate(await sharedFiles(l))).map(({user_id,...f})=>f)})}
 m=path.match(/^\/(media|thumb|hls)\/([^/]+)\/([^/]+)(?:\/.*)?$/);if(m){const l=await getLink(m[2]),f=(await sharedFiles(l)).find(f=>f.id===m![3]);if(!f)fail(404,'Datei nicht gefunden.');if(m[1]==='media'&&['GET','HEAD'].includes(method))return content(f);if(m[1]==='thumb'&&['GET','HEAD'].includes(method))return poster(f);if(m[1]==='hls')return hls(f,path.split('/').slice(4).join('/'),`${url.origin}/hls/${l.token}/${f.id}`);fail(404,'Datei nicht gefunden.');}
 m=path.match(/^\/playlist\/([^/]+)\/(library\.m3u8?)$/);if(m&&['GET','HEAD'].includes(method)){const l=await getLink(m[1]);const files=(await decorate(await sharedFiles(l))).filter(f=>mediaType(f.name,f.mime).startsWith('video/')&&['movie','series'].includes(f.kind)),lines=['#EXTM3U','# AndreDrive: Freigabelink gueltig bis zum Widerruf.'];for(const f of files){const title=f.kind==='series'?`${f.series||f.name} S${String(f.season).padStart(2,'0')}E${String(f.episode).padStart(2,'0')}`:f.name.replace(/\.[^.]+$/,'');const head=await bucket.head(objectKey(f)),index=head&&/\.mp4$/i.test(f.name)?await fragmentIndex(bucket,objectKey(f),head):null;
   lines.push(m3uMetadata(f,l.token,url.origin,index?.duration||Number(f.metadata?.runtime_minutes||0)*60),index?`${url.origin}/hls/${l.token}/${f.id}/index.m3u8`:`${url.origin}/media/${l.token}/${f.id}/${encodeURIComponent(f.name)}`)}return new Response(lines.join('\n')+'\n',{headers:{'Content-Type':'application/vnd.apple.mpegurl','Content-Disposition':filename('AndreDrive.m3u'),'Cache-Control':'private, no-store'}})}
 if(path==='/api/download'&&method==='POST'){
  const b=request.headers.get('content-type')?.includes('application/json')?await body():Object.fromEntries(await request.formData());let ids=b.ids;try{if(typeof ids==='string')ids=JSON.parse(ids)}catch{fail(400,'Ungültige Auswahl.')}if(!Array.isArray(ids)||!ids.length||ids.length>100)fail(400,'Bitte 1 bis 100 Dateien auswählen.');const files:Row[]=[];for(const id of [...new Set<string>(ids.map(String))])files.push(await file(id));if(files.reduce((n,f)=>n+f.size,0)>1024**3)fail(413,'ZIP-Downloads sind bis 1 GiB möglich. Größere Dateien einzeln herunterladen.');
  const headers=new Headers({'Content-Type':'application/zip','Content-Disposition':filename('AndreDrive.zip'),'Cache-Control':'private, no-store'});let zip:Zip,reader:ReadableStreamDefaultReader<Uint8Array>|undefined,cancelled=false,started=false,complete=false,index=0,current:ZipPassThrough|undefined;const queue:Uint8Array[]=[];
  const stream=new ReadableStream<Uint8Array>({async pull(controller){try{if(!started){started=true;zip=new Zip((err,data,final)=>{if(err){controller.error(err);return}if(data.length)queue.push(data);if(final)complete=true})}while(!queue.length&&!complete&&!cancelled){if(!reader){if(index>=files.length){zip.end();break}const f=files[index++],object=await bucket.get(objectKey(f));if(!object)throw Error('Datei fehlt');current=new ZipPassThrough(f.id.slice(0,6)+'-'+f.name.replace(/[\/\\]/g,'_'));zip.add(current);reader=object.body.getReader()}const part=await reader.read();current!.push(part.value||new Uint8Array(),part.done);if(part.done){reader.releaseLock();reader=undefined;current=undefined}}if(queue.length)controller.enqueue(queue.shift()!);else if(complete)controller.close()}catch(e){await reader?.cancel();controller.error(e)}},async cancel(){cancelled=true;await reader?.cancel();zip?.terminate()}});
  return new Response(stream,{headers});
 }
 return json({error:'API-Endpunkt nicht gefunden.'},404);
}
