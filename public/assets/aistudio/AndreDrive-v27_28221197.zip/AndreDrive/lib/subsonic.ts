import {createHash, timingSafeEqual} from 'node:crypto';
import {audioFilter, audioMime as mime, audioSuffix as suffix} from './audio-formats';
import {openToken, sealToken} from './catalog-metadata';
import {DriveError, newId} from './file-operations';

type Row = Record<string, any>;
type Payload = Record<string, unknown>;
type Services = {
  content: (file: Row, options: {mime: string, download: boolean}) => Promise<Response>;
  poster: (file: Row) => Promise<Response>;
};

const route = /^\/(?:navidrome\/)?rest\/([A-Za-z][A-Za-z0-9]*)(?:\.view)?\/?$/;
export const subsonicPath = (path: string) => route.test(path);
const accountPath = /^\/api\/navidrome\/accounts(?:\/([a-f0-9]{32}))?$/;
export const subsonicAccountPath = (path: string) => accountPath.test(path);
const headers = {'Cache-Control':'private, no-store', 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer'};
const protocol = '1.16.1';
const digest = (type: string, value: string) => createHash(type).update(value).digest('hex');
const scopedId = (kind: string, values: string[]) => kind + '_' + digest('sha256', JSON.stringify(values)).slice(0, 32);
const aad = (owner: string, id: string) => 'subsonic:' + owner + ':' + id;
const escapeXml = (value: unknown) => String(value)
  .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '')
  .replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&apos;'}[ch]!));

function xml(name: string, value: any): string {
  if (Array.isArray(value)) return value.map(item => xml(name, item)).join('');
  if (value === null || value === undefined) return '';
  if (typeof value !== 'object') return '<' + name + '>' + escapeXml(value) + '</' + name + '>';
  let attrs = '', children = '';
  for (const [key, item] of Object.entries(value)) {
    if (item === null || item === undefined) continue;
    if (key === 'value' && name === 'genre') children += escapeXml(item);
    else if (typeof item === 'object') children += xml(key, item);
    else attrs += ' ' + key + '="' + escapeXml(item) + '"';
  }
  return '<' + name + attrs + (children ? '>' + children + '</' + name + '>' : '/>');
}

function answer(params: URLSearchParams, payload: Payload = {}, error?: {code: number, message: string}) {
  const result = {
    status: error ? 'failed' : 'ok', version: protocol, type:'andredrive',
    serverVersion:'1.0.0', openSubsonic:true, ...payload, ...(error ? {error} : {}),
  };
  const data = {'subsonic-response': result};
  const format = params.get('f');
  if (format === 'json') return Response.json(data, {headers});
  if (format === 'jsonp') {
    const callback = params.get('callback') || '';
    if (!/^[A-Za-z_$][\w$]*(\.[A-Za-z_$][\w$]*){0,5}$/.test(callback) || callback.length > 128) {
      return Response.json({'subsonic-response': {...result, status:'failed', error:{code:10, message:'Ungültiger Callback.'}}}, {headers});
    }
    const safe = JSON.stringify(data).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    return new Response('/**/' + callback + '(' + safe + ');', {headers:{...headers, 'Content-Type':'application/javascript; charset=utf-8'}});
  }
  return new Response('<?xml version="1.0" encoding="UTF-8"?>' +
    xml('subsonic-response', {xmlns:'http://subsonic.org/restapi', ...result}),
  {headers:{...headers, 'Content-Type':'application/xml; charset=utf-8'}});
}

async function boundedText(request: Request, limit: number) {
  if (!request.body) return '';
  if (Number(request.headers.get('Content-Length') || 0) > limit) {
    throw new DriveError(413, 'Anfrage zu groß.');
  }
  const reader = request.body.getReader();
  const decoder = new TextDecoder();
  let size = 0, body = '';
  for (;;) {
    const part = await reader.read();
    if (part.done) break;
    size += part.value.length;
    if (size > limit) {
      await reader.cancel();
      throw new DriveError(413, 'Anfrage zu groß.');
    }
    body += decoder.decode(part.value, {stream:true});
  }
  return body + decoder.decode();
}

async function formParams(request: Request, params: URLSearchParams) {
  if (request.method !== 'POST' || !request.body) return;
  if (!/^application\/x-www-form-urlencoded(?:;|$)/i.test(request.headers.get('Content-Type') || '')) {
    throw new DriveError(400, 'Formulardaten erwartet.');
  }
  const form = new URLSearchParams(await boundedText(request, 65536));
  for (const key of new Set(form.keys())) {
    params.delete(key);
    for (const value of form.getAll(key)) params.append(key, value);
  }
}

const databases = (db: D1Database) => ({
  one: (sql: string, ...args: any[]) => db.prepare(sql).bind(...args).first<Row>(),
  all: async (sql: string, ...args: any[]) => (await db.prepare(sql).bind(...args).all<Row>()).results,
  run: (sql: string, ...args: any[]) => db.prepare(sql).bind(...args).run(),
});

export async function manageSubsonicAccounts(request: Request, db: D1Database, owner: string, key?: string) {
  const url = new URL(request.url);
  const id = accountPath.exec(url.pathname)?.[1];
  const {all, run} = databases(db);
  const serverUrl = url.origin;
  if (request.method === 'GET' && !id) {
    const accounts = await all('SELECT id,username,label,created FROM subsonic_accounts WHERE user_id=? ORDER BY created DESC', owner);
    return Response.json({serverUrl, accounts}, {headers});
  }
  if (request.method === 'POST' && !id) {
    if (!key) throw new DriveError(503, 'Geschützte Gerätezugänge sind noch nicht verfügbar.');
    const raw = await boundedText(request, 4096);
    let body: Row | null = null;
    try { body = JSON.parse(raw); } catch { /* Invalid JSON is handled below. */ }
    if (!body || typeof body.label !== 'string') throw new DriveError(400, 'Bitte einen Gerätenamen eingeben.');
    const account = {id:newId(), username:'nd_' + newId(), label:body.label.trim().slice(0,80) || 'Musikplayer', created:new Date().toISOString()};
    const password = newId() + newId();
    const secret = await sealToken(password, key, aad(owner, account.id));
    const inserted = await run(
      'INSERT INTO subsonic_accounts(id,user_id,username,label,secret,created) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM subsonic_accounts WHERE user_id=?)<50',
      account.id, owner, account.username, account.label, secret, account.created, owner,
    );
    if (!inserted.meta.changes) throw new DriveError(429, 'Maximal 50 Musikplayer-Zugänge pro Workspace.');
    return Response.json({...account, password, serverUrl}, {status:201, headers});
  }
  if (request.method === 'DELETE' && id) {
    const removed = await run('DELETE FROM subsonic_accounts WHERE id=? AND user_id=?', id, owner);
    if (!removed.meta.changes) throw new DriveError(404, 'Zugang nicht gefunden.');
    return Response.json({ok:true}, {headers});
  }
  throw new DriveError(405, 'Methode nicht unterstützt.');
}

async function authenticate(request: Request, params: URLSearchParams, db: D1Database, key?: string) {
  let username = params.get('u') || '', password = params.get('p') || '';
  const token = params.get('t') || '', salt = params.get('s') || '';
  const basic = /^Basic ([A-Za-z0-9+/=]{1,256})$/i.exec(request.headers.get('Authorization') || '');
  if (!username && basic) {
    let credentials: string;
    try { credentials = atob(basic[1]); } catch { return null; }
    const separator = credentials.indexOf(':');
    if (separator > 0) {
      username = credentials.slice(0, separator);
      password = credentials.slice(separator + 1);
    }
  }
  if (!key || !/^nd_[a-f0-9]{32}$/.test(username)) return null;
  if (/^enc:[a-f0-9]{128}$/i.test(password)) {
    password = String.fromCharCode(...password.slice(4).match(/../g)!.map(hex => parseInt(hex, 16)));
  }
  const tokenAuth = /^[a-f0-9]{32}$/i.test(token) && salt.length > 0 && salt.length <= 128;
  if (!tokenAuth && !/^[a-f0-9]{64}$/.test(password)) return null;
  const account = await databases(db).one('SELECT id,user_id,username,secret FROM subsonic_accounts WHERE username=?', username);
  if (!account) return null;
  const secret = await openToken(account.secret, key, aad(account.user_id, account.id));
  const received = new TextEncoder().encode(tokenAuth ? token.toLowerCase() : password);
  const expected = new TextEncoder().encode(tokenAuth ? digest('md5', secret + salt) : secret);
  return received.length === expected.length && timingSafeEqual(received, expected) ? account : null;
}

type Song = {
  id: string; parent: string; isDir: false; isVideo: false; type: 'music';
  title: string; album: string; albumId: string; artist: string; artistId: string;
  genre: string; track?: number; year?: number; duration?: number; coverArt?: string;
  contentType: string; suffix: string; size: number; path: string; created: string; starred?: string;
};
type Album = {
  id: string; name: string; artist: string; artistId: string; songCount: number;
  duration: number; created: string; year?: number; genre: string; coverArt?: string;
};
type Artist = {id: string; name: string; albumCount: number; coverArt?: string};
const byName = (a: string, b: string) => a.localeCompare(b, undefined, {numeric:true, sensitivity:'base'});

async function catalog(db: D1Database, owner: string) {
  const {all} = databases(db);
  const [rows, folders] = await Promise.all([
    all(`SELECT f.id,f.name,f.folder,f.kind,f.mime,f.size,f.created,f.starred,
      json_extract(m.data,'$.title') AS title,json_extract(m.data,'$.genres') AS genres,
      json_extract(m.data,'$.artist') AS artist,json_extract(m.data,'$.album') AS album,
      json_extract(m.data,'$.track') AS track,json_extract(m.data,'$.year') AS year,
      json_extract(m.data,'$.runtime_minutes') AS minutes,json_extract(m.data,'$.poster_source') AS artwork
      FROM files f LEFT JOIN file_metadata m ON m.file_id=f.id AND m.user_id=f.user_id
      WHERE f.user_id=? AND ${audioFilter} ORDER BY f.created DESC,f.id`, owner),
    all('SELECT id,name,parent FROM folders WHERE user_id=?', owner),
  ]);
  const folderById = new Map(folders.map(f => [f.id, f]));
  const songs = new Map<string, Song>();
  const albums = new Map<string, Album>();
  const artists = new Map<string, Artist>();
  const tracksByAlbum = new Map<string, Song[]>();
  const albumsByArtist = new Map<string, Album[]>();
  for (const file of rows) {
    const contentType = mime(file);
    if (!contentType) continue;
    const folder = folderById.get(file.folder);
    const parent = folderById.get(folder?.parent);
    const basename = file.name.replace(/\.[^.]+$/, '');
    const fallback = file.kind === 'audiobook' ? 'Hörbücher' : file.kind === 'podcast' ? 'Podcasts' : 'Musik';
    const artist = String(file.artist || parent?.name || 'Unbekannter Künstler');
    const albumName = String(file.album || folder?.name || fallback);
    const artistId = scopedId('artist', [artist]);
    const albumId = scopedId('album', [artistId, albumName, file.album ? '' : file.folder || '']);
    const year = Number(file.year) || undefined;
    const track = Number(file.track || /^\s*(\d{1,3})[. _-]/.exec(basename)?.[1]) || undefined;
    const duration = Number(file.minutes) > 0 ? Math.round(Number(file.minutes) * 60) : undefined;
    const genre = String(file.genres || '').split(',')[0].trim() || fallback;
    const coverArt = file.artwork === 'upload' ? file.id : undefined;
    const song: Song = {
      id:file.id, parent:albumId, isDir:false, isVideo:false, type:'music',
      title:file.title || basename, album:albumName, albumId, artist, artistId,
      genre, track, year, duration, coverArt, contentType, suffix:suffix(file.name),
      size:file.size, path:[artist, albumName, file.name].join('/'), created:file.created,
      starred:file.starred ? file.created : undefined,
    };
    songs.set(song.id, song);
    let artistInfo = artists.get(artistId);
    if (!artistInfo) {
      artistInfo = {id:artistId, name:artist, albumCount:0};
      artists.set(artistId, artistInfo);
      albumsByArtist.set(artistId, []);
    }
    let album = albums.get(albumId);
    if (!album) {
      album = {id:albumId, name:albumName, artist, artistId, songCount:0, duration:0, created:file.created, year, genre};
      albums.set(albumId, album);
      tracksByAlbum.set(albumId, []);
      albumsByArtist.get(artistId)!.push(album);
      artistInfo.albumCount++;
    }
    album.songCount++;
    album.duration += duration || 0;
    album.coverArt ||= coverArt;
    artistInfo.coverArt ||= coverArt;
    tracksByAlbum.get(albumId)!.push(song);
  }
  for (const tracks of tracksByAlbum.values()) {
    tracks.sort((a,b) => (a.track ?? Infinity) - (b.track ?? Infinity) || byName(a.path,b.path) || a.id.localeCompare(b.id));
    for (const song of tracks) song.coverArt ||= albums.get(song.albumId)?.coverArt;
  }
  for (const releases of albumsByArtist.values()) releases.sort((a,b) => byName(a.name,b.name));
  return {songs, albums, artists, tracksByAlbum, albumsByArtist};
}

function shuffled<T>(input: T[]) {
  const items = input.slice();
  for (let i = items.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items;
}

export async function handleSubsonic(request: Request, db: D1Database, key: string | undefined, services: Services) {
  const url = new URL(request.url);
  const command = route.exec(url.pathname)![1];
  const params = url.searchParams;
  const ok = (payload?: Payload) => answer(params, payload);
  const error = (code: number, message: string) => answer(params, {}, {code,message});
  const missing = () => error(70, 'Eintrag nicht gefunden.');
  if (!['GET','HEAD','POST'].includes(request.method)) return error(0, 'Methode nicht unterstützt.');
  if (request.method === 'HEAD' && /^(star|unstar|createPlaylist|updatePlaylist|deletePlaylist)$/.test(command)) {
    return new Response(null, {status:405, headers});
  }
  try {
    await formParams(request, params);
    const account = await authenticate(request, params, db, key);
    if (!account) return error(40, 'Ungültiger Benutzername oder ungültiges Passwort.');
    const owner = account.user_id;
    const {one, all, run} = databases(db);
    const id = params.get('id') || '';
    const libraryId = params.get('musicFolderId');
    const number = (name: string, fallback: number, limit = 500) => {
      const value = params.get(name);
      return value !== null && /^\d+$/.test(value) ? Math.min(limit, Number(value)) : fallback;
    };
    const page = <T>(items: T[], count = 'size', offset = 'offset', fallback = 10) => {
      const start = number(offset, 0, 100000000);
      return items.slice(start, start + number(count, fallback));
    };
    const ownedFile = (fileId: string) => one('SELECT f.* FROM files f WHERE f.id=? AND f.user_id=? AND ' + audioFilter, fileId, owner);
    if (command === 'ping') return ok();
    if (command === 'getLicense') return ok({license:{valid:true}});
    if (command === 'getOpenSubsonicExtensions') return ok({openSubsonicExtensions:[{name:'formPost',versions:[1]}]});
    if (command === 'getMusicFolders') return ok({musicFolders:{musicFolder:[{id:1,name:'AndreDrive Audio'}]}});
    if (command === 'getUser' || command === 'getUsers') {
      if (command === 'getUsers') return error(50, 'Keine Administratorrechte.');
      if (params.get('username') && params.get('username') !== account.username) return error(50, 'Zugriff verweigert.');
      return ok({user:{username:account.username, adminRole:false, settingsRole:false, streamRole:true, downloadRole:true,
        playlistRole:true, uploadRole:false, shareRole:false, coverArtRole:false, scrobblingEnabled:false, folder:[1]}});
    }
    if (command === 'stream' || command === 'download') {
      const file = await ownedFile(id);
      const audioMime = file && mime(file);
      if (!file || !audioMime) return missing();
      return await services.content(file, {mime:audioMime, download:command === 'download'});
    }
    if (command === 'getCoverArt') {
      const file = await ownedFile(id);
      if (!file) return missing();
      const response = await services.poster(file);
      return response.ok ? response : missing();
    }
    if (command === 'getNowPlaying') return ok({nowPlaying:{entry:[]}});
    if (command === 'getInternetRadioStations') return ok({internetRadioStations:{internetRadioStation:[]}});
    if (command === 'getBookmarks') return ok({bookmarks:{bookmark:[]}});
    if (command === 'getPlayQueue') return ok();
    if (command === 'star' || command === 'unstar') {
      if (params.has('albumId') || params.has('artistId')) return error(0, 'Favoriten werden für einzelne Audiodateien unterstützt.');
      const ids = [...new Set(params.getAll('id'))];
      if (!ids.length || ids.length > 90) return error(10, 'Bitte gültige Titel angeben.');
      const updated = await run(`UPDATE files AS f SET starred=? WHERE user_id=? AND id IN (${ids.map(() => '?').join(',')}) AND ${audioFilter}`, command === 'star' ? 1 : 0, owner, ...ids);
      return updated.meta.changes ? ok() : missing();
    }

    const supported = new Set([
      'getArtists','getIndexes','getArtist','getAlbum','getMusicDirectory','getSong','getAlbumList','getAlbumList2',
      'search','search2','search3','getGenres','getSongsByGenre','getRandomSongs','getStarred','getStarred2',
      'getAlbumInfo','getAlbumInfo2','getArtistInfo','getArtistInfo2','getTopSongs','getSimilarSongs','getSimilarSongs2',
      'getScanStatus','getPlaylists','getPlaylist','createPlaylist','updatePlaylist','deletePlaylist',
    ]);
    if (!supported.has(command)) return error(0, 'Diese Subsonic-Funktion wird von AndreDrive nicht unterstützt.');
    if (libraryId && libraryId !== '1' && libraryId !== '0') return missing();
    const data = await catalog(db, owner);
    const songs = [...data.songs.values()];
    const albums = [...data.albums.values()];
    const artists = [...data.artists.values()].sort((a,b) => byName(a.name,b.name));
    const song = data.songs.get(id), album = data.albums.get(id), artist = data.artists.get(id);
    const genre = params.get('genre')?.toLocaleLowerCase() || '';
    const inGenre = (value: {genre:string}) => value.genre.toLocaleLowerCase() === genre;
    const starredSongs = songs.filter(s => s.starred);
    const directories = (release: Album) => ({...release, title:release.name, album:release.name, parent:release.artistId, isDir:true});
    if (command === 'getArtists' || command === 'getIndexes') {
      const groups = new Map<string, Artist[]>();
      for (const item of artists) {
        const first = item.name.normalize('NFD').replace(/\p{M}/gu,'').charAt(0).toUpperCase();
        const letter = /^[A-Z]$/.test(first) ? first : '#';
        if (!groups.has(letter)) groups.set(letter, []);
        groups.get(letter)!.push(item);
      }
      const index = [...groups].map(([name, artist]) => ({name, artist}));
      return command === 'getArtists' ? ok({artists:{ignoredArticles:'', index}}) :
        ok({indexes:{ignoredArticles:'', lastModified:Date.now(), index, child:[]}});
    }
    if (command === 'getArtist') return artist ? ok({artist:{...artist, album:data.albumsByArtist.get(id)}}) : missing();
    if (command === 'getAlbum') return album ? ok({album:{...album, song:data.tracksByAlbum.get(id)}}) : missing();
    if (command === 'getSong') return song ? ok({song}) : missing();
    if (command === 'getMusicDirectory') {
      if (artist) return ok({directory:{id, name:artist.name, child:data.albumsByArtist.get(id)!.map(directories)}});
      if (album) return ok({directory:{id, parent:album.artistId, name:album.name, child:data.tracksByAlbum.get(id)}});
      return missing();
    }
    if (command === 'getAlbumList' || command === 'getAlbumList2') {
      const type = params.get('type') || 'newest';
      let result = albums;
      if (type === 'random') result = shuffled(albums);
      else if (type === 'alphabeticalByName') result.sort((a,b) => byName(a.name,b.name));
      else if (type === 'alphabeticalByArtist') result.sort((a,b) => byName(a.artist,b.artist) || byName(a.name,b.name));
      else if (type === 'starred') result = albums.filter(a => data.tracksByAlbum.get(a.id)!.some(s => s.starred));
      else if (type === 'byGenre') result = albums.filter(inGenre);
      else if (type === 'byYear') {
        const from = number('fromYear', 0, 9999), to = number('toYear', 9999, 9999);
        result = albums.filter(a => a.year && a.year >= Math.min(from,to) && a.year <= Math.max(from,to))
          .sort((a,b) => (a.year! - b.year!) * (from <= to ? 1 : -1));
      } else if (type === 'recent' || type === 'frequent') result = [];
      else if (type !== 'newest') return error(10, 'Unbekannter Listentyp.');
      const items = page(result);
      return command === 'getAlbumList2' ? ok({albumList2:{album:items}}) : ok({albumList:{album:items.map(directories)}});
    }
    if (command === 'search' || command === 'search2' || command === 'search3') {
      const words = (params.get('query') || params.get('any') || '').slice(0,250).toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
      const matches = (value: string) => words.every(word => value.toLocaleLowerCase().includes(word));
      if (command === 'search') return ok({searchResult:{offset:number('offset',0,100000000),match:page(songs.filter(s => matches(s.title + ' ' + s.artist + ' ' + s.album)), 'count')}});
      const result = {
        artist:page(artists.filter(a => matches(a.name)), 'artistCount', 'artistOffset', 20),
        album:page(albums.filter(a => matches(a.name + ' ' + a.artist)), 'albumCount', 'albumOffset', 20),
        song:page(songs.filter(s => matches(s.title + ' ' + s.artist + ' ' + s.album)), 'songCount', 'songOffset', 20),
      };
      return command === 'search3' ? ok({searchResult3:result}) : ok({searchResult2:{...result, album:result.album.map(directories)}});
    }
    if (command === 'getGenres') {
      const genres = new Map<string, {value:string,songCount:number,albums:Set<string>}>();
      for (const item of songs) {
        const key = item.genre.toLocaleLowerCase();
        const entry = genres.get(key) || {value:item.genre,songCount:0,albums:new Set()};
        entry.songCount++;
        entry.albums.add(item.albumId);
        genres.set(key, entry);
      }
      return ok({genres:{genre:[...genres.values()].sort((a,b) => byName(a.value,b.value))
        .map(g => ({value:g.value,songCount:g.songCount,albumCount:g.albums.size}))}});
    }
    if (command === 'getSongsByGenre') return ok({songsByGenre:{song:page(songs.filter(inGenre), 'count')}});
    if (command === 'getRandomSongs') {
      const min = number('fromYear', 0, 9999), max = number('toYear', 9999, 9999);
      const candidates = songs.filter(s => (!genre || inGenre(s)) && (!s.year ? !min && max === 9999 : s.year >= min && s.year <= max));
      return ok({randomSongs:{song:page(shuffled(candidates))}});
    }
    if (command === 'getStarred' || command === 'getStarred2') {
      const result = {artist:[],album:[],song:starredSongs};
      return command === 'getStarred2' ? ok({starred2:result}) : ok({starred:result});
    }
    if (command === 'getArtistInfo' || command === 'getArtistInfo2') {
      if (!artist) return missing();
      return ok({[command === 'getArtistInfo2' ? 'artistInfo2' : 'artistInfo']:{similarArtist:[]}});
    }
    if (command === 'getAlbumInfo' || command === 'getAlbumInfo2') return album ? ok({albumInfo:{}}) : missing();
    if (command === 'getTopSongs') return ok({topSongs:{song:page(songs.filter(s => byName(s.artist,params.get('artist') || '') === 0), 'count', 'offset', 50)}});
    if (command === 'getSimilarSongs' || command === 'getSimilarSongs2') {
      const sample = song || data.tracksByAlbum.get(id)?.[0];
      const candidates = songs.filter(s => (sample && s.id !== sample.id && s.artistId === sample.artistId) || s.artistId === id);
      return ok({[command === 'getSimilarSongs2' ? 'similarSongs2' : 'similarSongs']:{song:page(candidates, 'count')}});
    }
    if (command === 'getScanStatus') return ok({scanStatus:{scanning:false,count:songs.length}});
    const playlistId = params.get('playlistId') || id;
    const playlistData = (row: Row) => {
      const entries = (JSON.parse(row.tracks) as string[]).flatMap(track => data.songs.get(track) || []);
      return {id:row.id,name:row.name,comment:row.comment,owner:account.username,public:false,
        songCount:entries.length,duration:entries.reduce((total,s) => total + (s.duration || 0), 0),
        created:row.created,changed:row.changed,coverArt:entries.find(s => s.coverArt)?.coverArt,entry:entries};
    };
    if (command === 'getPlaylists') {
      const rows = await all('SELECT * FROM subsonic_playlists WHERE user_id=? ORDER BY name', owner);
      return ok({playlists:{playlist:rows.map(row => {
        const {entry, ...playlist} = playlistData(row);
        return playlist;
      })}});
    }
    const playlist = playlistId ? await one('SELECT * FROM subsonic_playlists WHERE id=? AND user_id=?', playlistId, owner) : null;
    if (command === 'getPlaylist') return playlist ? ok({playlist:playlistData(playlist)}) : missing();
    if (command === 'deletePlaylist') {
      if (!playlist) return missing();
      await run('DELETE FROM subsonic_playlists WHERE id=? AND user_id=?', playlist.id, owner);
      return ok();
    }
    if (playlistId && !playlist) return missing();
    if (command === 'updatePlaylist' && !playlist) return error(10, 'Playlist-ID fehlt.');
    const name = (params.get('name') ?? playlist?.name ?? '').trim().slice(0,200);
    const comment = (params.get('comment') ?? playlist?.comment ?? '').slice(0,1000);
    if (!name) return error(10, 'Playlist-Name fehlt.');
    const now = new Date().toISOString();
    const additions = params.getAll(command === 'createPlaylist' ? 'songId' : 'songIdToAdd');
    if (additions.length > 5000 || additions.some(track => !data.songs.has(track))) return missing();
    let trackIds = additions;
    if (command === 'updatePlaylist') {
      const removed = new Set(params.getAll('songIndexToRemove').filter(n => /^\d+$/.test(n)).map(Number));
      trackIds = (JSON.parse(playlist!.tracks) as string[]).filter((_,i) => !removed.has(i)).concat(additions);
    }
    if (trackIds.length > 5000) return error(10, 'Maximal 5.000 Titel pro Playlist.');
    const tracks = JSON.stringify(trackIds);
    if (playlist) {
      const saved = await run('UPDATE subsonic_playlists SET name=?,comment=?,tracks=?,changed=?,revision=revision+1 WHERE id=? AND user_id=? AND revision=?',
        name,comment,tracks,now,playlist.id,owner,playlist.revision);
      if (!saved.meta.changes) return error(0, 'Playlist wurde gleichzeitig geändert. Bitte neu laden.');
      return command === 'updatePlaylist' ? ok() : ok({playlist:playlistData({...playlist,name,comment,tracks,changed:now})});
    }
    const newPlaylist = {id:newId(),name,comment,tracks,created:now,changed:now};
    const saved = await run(
      'INSERT INTO subsonic_playlists(id,user_id,name,comment,tracks,created,changed) SELECT ?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM subsonic_playlists WHERE user_id=?)<200',
      newPlaylist.id,owner,name,comment,tracks,now,now,owner,
    );
    return saved.meta.changes ? ok({playlist:playlistData(newPlaylist)}) : error(0, 'Maximal 200 Playlists pro Workspace.');
  } catch (cause) {
    if (cause instanceof DriveError) return error(cause.status === 404 ? 70 : cause.status < 500 ? 10 : 0, cause.message);
    // Never log request URLs: Subsonic credentials can be in the query string.
    console.error('AndreDrive Subsonic request failed', cause instanceof Error ? cause.name : 'unknown');
    return error(0, 'Die Audio-Anfrage konnte nicht abgeschlossen werden.');
  }
}
