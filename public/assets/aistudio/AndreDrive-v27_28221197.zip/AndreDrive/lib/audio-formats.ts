const audioTypes: Record<string, string> = {
  mp3:'audio/mpeg', mp2:'audio/mpeg', m4a:'audio/mp4', m4b:'audio/mp4',
  m4p:'audio/mp4', aac:'audio/aac', flac:'audio/flac', wav:'audio/wav', wave:'audio/wav',
  ogg:'audio/ogg', oga:'audio/ogg', opus:'audio/ogg', spx:'audio/ogg', wma:'audio/x-ms-wma',
  aif:'audio/aiff', aiff:'audio/aiff', aifc:'audio/aiff', alac:'audio/mp4',
  amr:'audio/amr', awb:'audio/amr-wb', ac3:'audio/ac3', eac3:'audio/eac3',
  ape:'audio/x-ape', mpc:'audio/x-musepack', mka:'audio/x-matroska', wv:'audio/wavpack',
  dsf:'audio/dsf', dff:'audio/dff', au:'audio/basic', caf:'audio/x-caf',
  mid:'audio/midi', midi:'audio/midi', aa:'audio/audible', aax:'audio/audible',
};
export const audioSuffix = (name: string) => /\.([^./]+)$/.exec(name)?.[1].toLowerCase() || '';
export const audioMime = (file: Record<string,unknown>) => {
  const type = String(file.mime).split(';', 1)[0].trim().toLowerCase();
  const suffix = audioSuffix(String(file.name ?? ''));
  return (Object.hasOwn(audioTypes,suffix) ? audioTypes[suffix] : '') || (/^audio\/[\w.+-]+$/.test(type) ? type : '');
};
export const audioFilter = "(lower(f.mime) LIKE 'audio/%' OR " +
  Object.keys(audioTypes).map(ext => "lower(f.name) GLOB '*." + ext + "'").join(' OR ') + ')';
