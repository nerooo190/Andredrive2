// Read-only Xtream-compatible VOD catalog. Access is scoped to an existing share.
import {objectKey} from './file-operations';
import {mediaType} from './media-stream';
import {fragmentIndex} from './fragmented-mp4';
type Row=Record<string,any>;
export const iptvPath=(path:string)=>/^\/(?:player_api\.php|get\.php|xmltv\.php)$/.test(path)||/^\/(?:movie|series)\/[^/]+\/[^/]+\/\d+\.[a-zA-Z0-9]+$/.test(path);
export function iptvCredentials(url:URL){
 const playback=url.pathname.match(/^\/(movie|series)\/([^/]+)\/([^/]+)\/(\d+)\.([a-zA-Z0-9]+)$/);
 const username=playback?.[2]||url.searchParams.get('username')||'',password=playback?.[3]||url.searchParams.get('password')||'';
 return {username,password,token:/^[a-f0-9]{32}$/.test(username)&&/^[a-f0-9]{32}$/.test(password)?username+password:'',playback};
}
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}});
const seconds=(f:Row)=>Math.round(Number(f.iptv_duration)||Number(f.metadata?.runtime_minutes||0)*60);
const duration=(n:number)=>`${String(Math.floor(n/3600)).padStart(2,'0')}:${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
const added=(f:Row)=>String(Math.floor(new Date(f.created).getTime()/1000)||0);
const seriesName=(f:Row)=>f.series||f.metadata?.title||f.name.replace(/\.[^.]+$/,'');
const seriesKey=(f:Row)=>f.metadata?.tmdb_id?'tmdb:'+f.metadata.tmdb_id:'name:'+seriesName(f).normalize('NFKC').trim().toLocaleLowerCase('de');
const group=(f:Row)=>f.metadata?.group_title||(f.kind==='series'?'Serien':'Filme')+(f.metadata?.genres?' | '+f.metadata.genres.split(',')[0].trim():'');
// Category identifiers depend only on the category name, never its list position.
const category=(f:Row)=>{let h=2166136261;for(const c of f.kind+':'+group(f)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return String((h>>>0)%2147483646+1)};
const cover=(f:Row,origin:string,token:string)=>f.metadata?.poster_source==='upload'?`${origin}/thumb/${token}/${f.id}`:f.metadata?.poster_url||'';
export async function iptvCatalog(db:D1Database,bucket:R2Bucket,rows:Row[],origin:string,token:string){
 const files=rows.filter(f=>mediaType(f.name,f.mime).startsWith('video/')&&(f.kind==='movie'||f.kind==='series')).sort((a,b)=>a.created.localeCompare(b.created)||a.id.localeCompare(b.id));
 // AUTOINCREMENT prevents deleted stream IDs from being reassigned to a different film.
 for(let i=0;i<files.length;i+=40)await db.batch(files.slice(i,i+40).map(f=>db.prepare('INSERT OR IGNORE INTO iptv_streams(file_id) VALUES(?)').bind(f.id)));
 const mapping=new Map<string,Row>();
 for(let i=0;i<files.length;i+=90){const ids=files.slice(i,i+90).map(f=>f.id);for(const row of (await db.prepare(`SELECT * FROM iptv_streams WHERE file_id IN (${ids.map(()=>'?').join(',')})`).bind(...ids).all<Row>()).results)mapping.set(row.file_id,row)}
 for(const f of files){const m=mapping.get(f.id)!;f.iptv_id=m.id;f.iptv_hls=m.hls;f.iptv_duration=m.duration;}
 const series=new Map<string,{id:number,files:Row[]}>();
 for(const f of files.filter(f=>f.kind==='series')){const key=seriesKey(f);if(!series.has(key)){await db.prepare('INSERT OR IGNORE INTO iptv_series(user_id,series_key) VALUES(?,?)').bind(f.user_id,key).run();const row=await db.prepare('SELECT id FROM iptv_series WHERE user_id=? AND series_key=?').bind(f.user_id,key).first<Row>();series.set(key,{id:row!.id,files:[]})}series.get(key)!.files.push(f)}
 const prepare=async(f:Row)=>{
  if(f.iptv_hls==null){const storageKey=objectKey(f),head=/\.mp4$/i.test(f.name)?await bucket.head(storageKey):null,index=head?await fragmentIndex(bucket,storageKey,head):null;f.iptv_hls=index?1:0;f.iptv_duration=index?.duration||0;await db.prepare('UPDATE iptv_streams SET hls=?,duration=? WHERE file_id=?').bind(f.iptv_hls,f.iptv_duration,f.id).run()}
  return f.iptv_hls?'m3u8':f.name.match(/\.([a-zA-Z0-9]+)$/)?.[1].toLowerCase()||'mp4';
 };
 const detail=(f:Row)=>{const m=f.metadata||{},s=seconds(f),image=cover(f,origin,token);return {name:m.title||f.name.replace(/\.[^.]+$/,''),title:m.title||f.name.replace(/\.[^.]+$/,''),o_name:m.original_title||'',movie_image:image,cover_big:image,plot:m.plot||'',description:m.plot||'',cast:m.cast||'',actors:m.cast||'',director:m.director||'',genre:m.genres||'',country:m.country||'',releasedate:m.year?`${m.year}-01-01`:'',releaseDate:m.year?`${m.year}-01-01`:'',year:m.year||'',rating:String(m.rating||0),rating_5based:Number(m.rating||0)/2,tmdb_id:m.tmdb_id||'',imdb_id:m.imdb_id||'',duration_secs:s,duration:duration(s),backdrop_path:m.backdrop_url?[m.backdrop_url]:[],youtube_trailer:''}};
 const movie=async(f:Row,num:number)=>({num,name:f.metadata?.title||f.name.replace(/\.[^.]+$/,''),stream_type:'movie',stream_id:f.iptv_id,stream_icon:cover(f,origin,token),rating:String(f.metadata?.rating||0),rating_5based:Number(f.metadata?.rating||0)/2,tmdb:f.metadata?.tmdb_id||'',added:added(f),category_id:category(f),category_ids:[Number(category(f))],container_extension:await prepare(f),custom_sid:'',direct_source:'',year:f.metadata?.year||''});
 const show=(s:{id:number,files:Row[]},num:number)=>{const f=s.files[0];return {num,series_id:s.id,name:seriesName(f),cover:cover(f,origin,token),plot:f.metadata?.plot||'',cast:f.metadata?.cast||'',director:f.metadata?.director||'',genre:f.metadata?.genres||'',releaseDate:f.metadata?.year?`${f.metadata.year}-01-01`:'',last_modified:added(s.files.at(-1)!),rating:String(f.metadata?.rating||0),rating_5based:Number(f.metadata?.rating||0)/2,backdrop_path:f.metadata?.backdrop_url?[f.metadata.backdrop_url]:[],youtube_trailer:'',episode_run_time:String(f.metadata?.runtime_minutes||0),category_id:category(f),category_ids:[Number(category(f))]}};
 return {files,prepare,async api(url:URL){
  const action=url.searchParams.get('action'),filter=url.searchParams.get('category_id');
  const selected=(kind:string)=>files.filter(f=>f.kind===kind&&(!filter||filter==='0'||category(f)===filter));
  if(action==='get_vod_categories'||action==='get_series_categories'){const groups=new Map<string,Row>();for(const f of files.filter(f=>f.kind===(action==='get_vod_categories'?'movie':'series')))groups.set(category(f),{category_id:category(f),category_name:group(f),parent_id:0});return json([...groups.values()])}
  if(action==='get_vod_streams'){const results=[];for(const [i,f] of selected('movie').entries())results.push(await movie(f,i+1));return json(results)}
  if(action==='get_vod_info'){const f=files.find(f=>f.kind==='movie'&&String(f.iptv_id)===url.searchParams.get('vod_id'));if(!f)return json({error:'Film nicht gefunden.'},404);return json({info:detail(Object.assign(f,{container_extension:await prepare(f)})),movie_data:await movie(f,1)})}
  if(action==='get_series')return json([...series.values()].filter(s=>!filter||filter==='0'||category(s.files[0])===filter).map((s,i)=>show(s,i+1)));
  if(action==='get_series_info'){const s=[...series.values()].find(s=>String(s.id)===url.searchParams.get('series_id'));if(!s)return json({error:'Serie nicht gefunden.'},404);const episodes:Record<string,Row[]>={},seasons:Row[]=[];for(const f of [...s.files].sort((a,b)=>a.season-b.season||a.episode-b.episode||a.id.localeCompare(b.id))){const season=String(f.season);if(!episodes[season]){episodes[season]=[];seasons.push({id:f.season,season_number:f.season,name:'Staffel '+f.season,episode_count:0,cover:cover(f,origin,token),cover_big:cover(f,origin,token),overview:'',air_date:''})}episodes[season].push({id:String(f.iptv_id),episode_num:f.episode,title:f.metadata?.episode_title||`${seriesName(f)} S${String(f.season).padStart(2,'0')}E${String(f.episode).padStart(2,'0')}`,container_extension:await prepare(f),info:{...detail(f),...(f.metadata?.episode_image_url?{movie_image:f.metadata.episode_image_url,cover_big:f.metadata.episode_image_url}:{})},custom_sid:'',added:added(f),season:f.season,direct_source:''})}for(const season of seasons)season.episode_count=episodes[String(season.season_number)].length;return json({info:show(s,1),seasons,episodes})}
  return json({error:'Unbekannte Katalogaktion.'},400);
 }};
}
export function iptvLogin(url:URL,link:Row,username:string,password:string){return json({user_info:{username,password,message:'AndreDrive · Filme & Serien',auth:1,status:'Active',exp_date:null,is_trial:'0',active_cons:'0',created_at:added(link),max_connections:'10',allowed_output_formats:['m3u8','mp4']},server_info:{url:url.hostname,port:url.port||'80',https_port:url.port||'443',server_protocol:url.protocol.slice(0,-1),rtmp_port:'0',timezone:'UTC',timestamp_now:Math.floor(Date.now()/1000),time_now:new Date().toISOString().slice(0,19).replace('T',' '),process:true}})}
