// Return a length-aware stream. Workers ignores manually supplied Content-Length
// on ordinary ReadableStreams; media clients need a known length for seeking.
export type RequestLifetime={waitUntil(promise:Promise<unknown>):void};
export function fixedLengthBody(body:ReadableStream<Uint8Array>,length:number,lifetime?:RequestLifetime):ReadableStream<Uint8Array>{
 if(typeof FixedLengthStream==='undefined')return body;
 const stream=new FixedLengthStream(length);
 const transfer=body.pipeTo(stream.writable).catch(()=>{}); // Client cancellation also cancels the R2 source.
 lifetime?.waitUntil(transfer);
 return stream.readable;
}
export function singleRange(header:string|null,size:number):{offset:number,length:number}|null{
 if(header===null)return null;
 const m=/^bytes=(\d*)-(\d*)$/.exec(header.trim());
 if(!m||(!m[1]&&!m[2])||size===0)throw new RangeError('Unsatisfiable range');
 let offset:number,end:number;
 if(!m[1]){const suffix=Number(m[2]);if(!Number.isSafeInteger(suffix)||suffix<=0)throw new RangeError('Invalid suffix');offset=Math.max(0,size-suffix);end=size-1}
 else{offset=Number(m[1]);end=m[2]?Math.min(Number(m[2]),size-1):size-1}
 const length=end-offset+1;
 if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(end)||!Number.isSafeInteger(length)||offset<0||offset>=size||length<=0)throw new RangeError('Unsatisfiable range');
 return {offset,length};
}
export function mediaType(name:string,stored:string):string{
 if(stored&&stored!=='application/octet-stream')return stored;
 const ext=name.split('.').pop()?.toLowerCase();
 return ({mp4:'video/mp4',m4v:'video/mp4',mov:'video/quicktime',webm:'video/webm',mkv:'video/x-matroska',mp3:'audio/mpeg',m4a:'audio/mp4',m4b:'audio/mp4',flac:'audio/flac',ogg:'audio/ogg',opus:'audio/ogg',wav:'audio/wav',aac:'audio/aac',pdf:'application/pdf',epub:'application/epub+zip',cbz:'application/vnd.comicbook+zip',cbr:'application/vnd.comicbook-rar'} as Record<string,string>)[ext||'']||stored||'application/octet-stream';
}
// A bounded structural probe: skip mdat by its declared size, never download a film.
export async function inspectMp4(bucket:R2Bucket,key:string,size:number){
 const boxes:{type:string,offset:number,size:number}[]=[];
 let offset=0;
 for(let n=0;n<32&&offset+8<=size;n++){
  const object=await bucket.get(key,{range:{offset,length:Math.min(16,size-offset)}});if(!object)break;
  const bytes=new Uint8Array(await object.arrayBuffer());if(bytes.length<8)break;
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  let length=view.getUint32(0),header=8;
  const type=String.fromCharCode(...bytes.slice(4,8));
  if(length===1){if(bytes.length<16)break;length=Number(view.getBigUint64(8));header=16}else if(length===0)length=size-offset;
  if(!Number.isSafeInteger(length)||length<header||offset+length>size||!/^[-a-zA-Z0-9 ]{4}$/.test(type))break;
  boxes.push({type,offset,size:length});offset+=length;if(boxes.some(b=>b.type==='moov')&&boxes.some(b=>b.type==='mdat'))break;
 }
 const moov=boxes.find(b=>b.type==='moov'),mdat=boxes.find(b=>b.type==='mdat');
 let duration:number|null=null;const codecs:string[]=[];
 if(moov&&moov.size<=8*1024**2){
  const object=await bucket.get(key,{range:{offset:moov.offset,length:moov.size}});
  if(object){const bytes=new Uint8Array(await object.arrayBuffer());const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
   function walk(start:number,end:number,depth=0){if(depth>10)return;for(let at=start;at+8<=end;){let length=view.getUint32(at),header=8;const type=String.fromCharCode(...bytes.slice(at+4,at+8));if(length===1){if(at+16>end)return;length=Number(view.getBigUint64(at+8));header=16}if(length===0)length=end-at;if(length<header||at+length>end||!Number.isSafeInteger(length))return;const data=at+header,limit=at+length;
    if(type==='mvhd'&&data+20<=limit){const version=bytes[data];const timescaleAt=data+(version===1?20:12),durationAt=timescaleAt+4;if(durationAt+(version===1?8:4)<=limit){const scale=view.getUint32(timescaleAt),ticks=version===1?Number(view.getBigUint64(durationAt)):view.getUint32(durationAt);if(scale&&Number.isFinite(ticks))duration=ticks/scale}}
    if(type==='stsd'&&data+8<=limit){let pos=data+8;const count=Math.min(view.getUint32(data+4),100);for(let i=0;i<count&&pos+8<=limit;i++){const entrySize=view.getUint32(pos),codec=String.fromCharCode(...bytes.slice(pos+4,pos+8));if(entrySize<8||pos+entrySize>limit)break;if(!codecs.includes(codec))codecs.push(codec);pos+=entrySize}}
    if(['moov','trak','mdia','minf','stbl','edts','dinf','mvex'].includes(type))walk(data,limit,depth+1);
    at+=length;
   }}walk(0,bytes.length);
  }
 }
 return {container:boxes.some(b=>b.type==='ftyp')?'mp4':'unknown',size,boxes,duration,codecs,fastStart:!!moov&&!!mdat&&moov.offset<mdat.offset,fragmented:boxes.some(b=>b.type==='moof')};
}
