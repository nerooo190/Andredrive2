import {cloudTransfers} from './cloud-transfers';
import {sealToken,openToken} from './catalog-metadata';
import {DriveError,newId} from './file-operations';
import {BUILTIN_CATEGORIES,inferCategory} from './categories';
import {mediaType} from './media-stream';
type Row=Record<string,any>;
const GRAPH='https://graph.microsoft.com/v1.0';
const LOGIN='https://login.microsoftonline.com/common/oauth2/v2.0';
const GOOGLE='https://www.googleapis.com/drive/v3';
const GOOGLE_TOKEN='https://oauth2.googleapis.com/token';
const GOOGLE_SCOPE='https://www.googleapis.com/auth/drive.readonly';
const GOOGLE_CALLBACK='/api/cloud/google-drive/callback';
const GOOGLE_FIELDS='id,name,mimeType,size,modifiedTime,version,headRevisionId,trashed,capabilities(canDownload)';
const GOOGLE_FOLDER='application/vnd.google-apps.folder';
const googleId=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,200}$/.test(value);
const TOR='https://api.torbox.app/v1/api';
const SCOPES='https://graph.microsoft.com/Files.Read offline_access';
const WRITE_SCOPES='https://graph.microsoft.com/Files.ReadWrite offline_access';
const enc=encodeURIComponent;
const clean=(v:unknown,n=255)=>String(v??'').replace(/[\x00-\x1f]/g,'').trim().slice(0,n);
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'}});
const torTypes=['torrents','webdl','usenet'];
// TorBox's published CDN domains, including Hyperdrive and fallback CDNs:
// https://support.torbox.app/en/articles/13181686-accessing-torbox-with-nextdns
const TOR_DOWNLOAD_DOMAINS=['torbox.app','tb-cdn.cx','tb-cdn.io','tb-cdn.pw','tb-cdn.sh','tb-cdn.st','tb-cdn.to','tb-cdn.earth'];
// Only provider-issued HTTPS download destinations are accepted. Credentials are
// never forwarded to CDNs, redirects or public playlist URLs.
export function cloudDownloadUrl(value:unknown,provider:string){
 try{const u=new URL(String(value)),h=u.hostname.toLowerCase();
  const allowed=provider==='torbox'?TOR_DOWNLOAD_DOMAINS.some(domain=>h===domain||h.endsWith('.'+domain)):h==='onedrive.live.com'||h.endsWith('.onedrive.live.com')||h.endsWith('.1drv.com')||h.endsWith('.files.1drv.com')||h.endsWith('.sharepoint.com')||h.endsWith('.sharepointonline.com');
  if(u.protocol!=='https:'||u.port&&u.port!=='443'||u.username||u.password||!allowed)throw Error();return u.href;
 }catch{throw new DriveError(502,'Die Cloud hat keine gültige Download-Adresse geliefert.')}
}
async function providerJson(url:string,options:RequestInit={}){
 let response:Response;try{response=await fetch(url,{...options,redirect:'manual',signal:AbortSignal.timeout(20000)})}catch{throw new DriveError(502,'Cloud-Dienst momentan nicht erreichbar.')}
 let data:Row;try{const reader=response.body?.getReader();if(!reader)throw Error();const chunks:Uint8Array[]=[];let size=0;for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>8*1024**2){await reader.cancel();throw Error()}chunks.push(part.value)}const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length}data=JSON.parse(new TextDecoder().decode(bytes))}catch{throw new DriveError(502,'Ungültige oder zu große Antwort des Cloud-Dienstes.')}
 if(!response.ok||data.success===false){const status=response.status===429?429:[401,403].includes(response.status)?401:response.status===404?404:502;throw new DriveError(status,status===401?'Cloud-Zugang abgelaufen oder nicht berechtigt. Bitte erneut verbinden.':status===429?'Cloud-Anfragelimit erreicht. Bitte kurz warten.':status===404?'Die Datei wurde in der Cloud nicht gefunden.':'Die Cloud-Anfrage ist fehlgeschlagen.')}
 return data;
}
export function cloudSources(db:D1Database,key:string|undefined,siteClientId?:string,storage?:R2Bucket){
 const one=async(sql:string,...args:any[])=>db.prepare(sql).bind(...args).first<Row>();
 const all=async(sql:string,...args:any[])=>(await db.prepare(sql).bind(...args).all<Row>()).results;
 const run=(sql:string,...args:any[])=>db.prepare(sql).bind(...args).run();
 const secretKey=()=>{if(!key)throw new DriveError(503,'Geschützte Cloud-Verbindungen sind noch nicht verfügbar.');return key};
 const seal=(data:Row,owner:string,id:string)=>sealToken(JSON.stringify(data),secretKey(),owner+':cloud:'+id);
 const open=async(value:string,owner:string,id:string)=>{try{return JSON.parse(await openToken(value,secretKey(),owner+':cloud:'+id)) as Row}catch{throw new DriveError(401,'Cloud-Verbindung bitte erneut einrichten.')}};
 const connection=async(id:string,owner:string)=>await one('SELECT * FROM cloud_connections WHERE id=? AND user_id=?',id,owner)??Promise.reject(new DriveError(424,'Cloud-Verbindung wurde getrennt. Bitte neu verbinden.'));
 const saveCredentials=async(c:Row,credentials:Row)=>{c.credentials=await seal(credentials,c.user_id,c.id);await run('UPDATE cloud_connections SET credentials=? WHERE id=? AND user_id=?',c.credentials,c.id,c.user_id)};
 const graphToken=async(c:Row,force=false)=>{const a=await open(c.credentials,c.user_id,c.id);if(!force&&a.expires>Date.now()+60000)return a.access_token;
  const data=await providerJson(LOGIN+'/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:a.client_id,grant_type:'refresh_token',refresh_token:a.refresh_token,scope:a.canMove?WRITE_SCOPES:SCOPES})});
  if(!data.access_token)throw new DriveError(401,'Microsoft-Anmeldung bitte erneuern.');await saveCredentials(c,{...a,access_token:data.access_token,refresh_token:data.refresh_token||a.refresh_token,expires:Date.now()+Number(data.expires_in||3600)*1000});return data.access_token;
 };
 const graph=async(c:Row,path:string)=>{const url=path.startsWith('https:')?new URL(path):new URL(GRAPH+path);if(url.origin!=='https://graph.microsoft.com'||!url.pathname.startsWith('/v1.0/'))throw new DriveError(400,'Ungültige OneDrive-Seite.');
  for(let attempt=0;;attempt++){try{return await providerJson(url.href,{headers:{Authorization:'Bearer '+await graphToken(c,attempt>0)}})}catch(e){if(attempt||!(e instanceof DriveError)||e.status!==401)throw e}}
 };
 const googleExchange=(parameters:Record<string,string>)=>providerJson(GOOGLE_TOKEN,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(parameters)});
 const googleTokens=(data:Row)=>({access_token:data.access_token,expires:Date.now()+Number(data.expires_in||3600)*1000});
 const googleToken=async(c:Row,force=false)=>{
  const a=await open(c.credentials,c.user_id,c.id);
  if(!force&&a.expires>Date.now()+60000)return a.access_token;
  let data:Row;
  try{data=await googleExchange({client_id:a.client_id,client_secret:a.client_secret,grant_type:'refresh_token',refresh_token:a.refresh_token})}
  catch(e){if(e instanceof DriveError&&e.status===502)throw new DriveError(401,'Google Drive konnte den Zugang nicht erneuern. Bitte erneut verbinden.');throw e}
  if(!data.access_token)throw new DriveError(401,'Google Drive bitte erneut verbinden.');
  await saveCredentials(c,{...a,...googleTokens(data),refresh_token:data.refresh_token||a.refresh_token});
  return data.access_token;
 };
 const googleGet=async(c:Row,path:string,params:Record<string,string>)=>{
  const url=GOOGLE+path+'?'+new URLSearchParams(params);
  try{return await providerJson(url,{headers:{Authorization:'Bearer '+await googleToken(c)}})}
  catch(e){if(!(e instanceof DriveError)||e.status!==401)throw e;return providerJson(url,{headers:{Authorization:'Bearer '+await googleToken(c,true)}})}
 };
 const mapGoogle=(i:Row)=>{
  const folder=i.mimeType===GOOGLE_FOLDER,ref={itemId:i.id},size=Number(i.size);
  const ready=folder||(!i.trashed&&i.capabilities?.canDownload===true&&typeof i.mimeType==='string'&&!i.mimeType.startsWith('application/vnd.google-apps.')&&Number.isSafeInteger(size)&&size>=0&&!!(i.headRevisionId||i.version));
  return {key:JSON.stringify(ref),ref,id:i.id,name:clean(i.name)||'Google-Drive-Datei',folder,ready,size:ready&&!folder?size:0,mime:mediaType(i.name,i.mimeType||'application/octet-stream'),modified:i.modifiedTime||'',version:i.headRevisionId||i.version||''};
 };
 const googleItem=(c:Row,id:string)=>googleGet(c,'/files/'+enc(id),{fields:GOOGLE_FIELDS,supportsAllDrives:'true'});
 async function googleMedia(c:Row,data:Row,range:string){
  const current=mapGoogle(await googleItem(c,data.ref.itemId));
  if(!current.ready||current.folder||current.size!==data.size||current.version!==data.version)throw new DriveError(409,'Die Google-Drive-Datei hat sich geändert oder ist nicht mehr verfügbar. Bitte neu hinzufügen.');
  const url=GOOGLE+'/files/'+enc(data.ref.itemId)+'?alt=media&supportsAllDrives=true';
  for(let attempt=0;;attempt++){
   const token=await googleToken(c,attempt>0);
   const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),30000);
   let response:Response;
   try{response=await fetch(url,{redirect:'manual',headers:{Authorization:'Bearer '+token,...(range?{Range:range}:{}),'Accept-Encoding':'identity'},signal:controller.signal})}
   catch{throw new DriveError(502,'Google Drive ist momentan nicht erreichbar.')}finally{clearTimeout(timeout)}
   if(response.status!==401||attempt)return response;
   await response.body?.cancel();
  }
 }
 const tor=async(c:Row,type:string,action:string,params:Row={})=>{if(!torTypes.includes(type)&&type!=='user')throw new DriveError(400,'Ungültiger TorBox-Bereich.');const a=await open(c.credentials,c.user_id,c.id),url=new URL(TOR+'/'+type+'/'+action);for(const [k,v] of Object.entries(params))url.searchParams.set(k,String(v));const headers:Record<string,string>={Accept:'application/json'};if(action==='requestdl')url.searchParams.set('token',a.token);else headers.Authorization='Bearer '+a.token;return providerJson(url.href,{headers})};
 const mapOne=(i:Row)=>({key:JSON.stringify({driveId:i.parentReference?.driveId,itemId:i.id}),id:i.id,name:clean(i.name),folder:!!i.folder,size:Number(i.size)||0,mime:mediaType(i.name,i.file?.mimeType||'application/octet-stream'),ref:{driveId:i.parentReference?.driveId,itemId:i.id},modified:i.lastModifiedDateTime||'',version:i.cTag||i.eTag||''});
 const torList=async(c:Row,type:string,id?:string,offset=0)=>{const data=await tor(c,type,'mylist',id?{id}:{offset,limit:25});return Array.isArray(data.data)?data.data:data.data?[data.data]:[]};
 const torFiles=(row:Row,type:string)=>(row.files||[]).map((f:Row)=>({key:JSON.stringify({type,parent:String(row.id),file:String(f.id)}),id:String(f.id),name:clean(f.short_name||String(f.name||'').split('/').at(-1)),folder:false,size:Number(f.size)||0,mime:mediaType(f.name||'',f.mimetype||'application/octet-stream'),ref:{type,parent:String(row.id),file:String(f.id)},modified:row.updated_at||row.created_at||'',version:row.hash||'',ready:row.download_present!==false&&(row.download_finished===true||['completed','uploading','cached'].includes(row.download_state))}));
 const resolveItem=async(c:Row,ref:Row)=>{
  if(c.provider==='google-drive'){
   if(!googleId(ref?.itemId)||ref.itemId==='root')throw new DriveError(400,'Ungültige Google-Drive-Datei.');
   const item=mapGoogle(await googleItem(c,ref.itemId));
   if(item.folder||!item.ready)throw new DriveError(400,'Diese Google-Drive-Datei lässt sich nicht direkt herunterladen.');
   return item;
  }
  if(c.provider==='onedrive'){if(!ref.driveId||!ref.itemId||typeof ref.driveId!=='string'||typeof ref.itemId!=='string')throw new DriveError(400,'Ungültige OneDrive-Datei.');const i=await graph(c,'/drives/'+enc(ref.driveId)+'/items/'+enc(ref.itemId));if(i.folder||!i.file)throw new DriveError(400,'Bitte Dateien auswählen.');return mapOne(i)}
  if(!torTypes.includes(ref.type)||!/^\d+$/.test(ref.parent)||!/^\d+$/.test(ref.file))throw new DriveError(400,'Ungültige TorBox-Datei.');const rows=await torList(c,ref.type,ref.parent),item=rows.filter(r=>String(r.id)===ref.parent).flatMap(r=>torFiles(r,ref.type)).find(f=>f.id===ref.file);if(!item)throw new DriveError(404,'TorBox-Datei nicht gefunden.');if(!item.ready)throw new DriveError(409,'Die Datei ist bei TorBox noch nicht vollständig verfügbar.');return item;
 };
 const canMove=async(c:Row)=>c.provider==='torbox'||c.provider==='onedrive'&&!!(await open(c.credentials,c.user_id,c.id)).canMove;
 async function handle(request:Request,owner:string){
  const url=new URL(request.url),path=url.pathname,method=request.method;
  const body=async()=>{if(Number(request.headers.get('Content-Length')||0)>262144)throw new DriveError(413,'Anfrage zu groß.');try{return await request.json() as Row}catch{throw new DriveError(400,'Ungültige Anfrage.')}};
  if(path==='/api/cloud/transfers'||/^\/api\/cloud\/transfers\//.test(path)||/^\/api\/cloud\/connections\/[^/]+\/transfers$/.test(path))return transfers.handle(request,owner);
  if(path==='/api/cloud/connections'&&method==='GET'){const rows=await all('SELECT * FROM cloud_connections WHERE user_id=? ORDER BY created',owner);return json({connections:await Promise.all(rows.map(async c=>({id:c.id,provider:c.provider,label:c.label,created:c.created,canMove:await canMove(c)}))),oneDriveClientConfigured:!!siteClientId})}
  if(path==='/api/cloud/torbox'&&method==='POST'){const b=await body(),token=clean(b.token,512);if(!/^[\w.-]{16,512}$/.test(token))throw new DriveError(400,'Bitte einen TorBox-API-Schlüssel eingeben.');const c={id:newId(),user_id:owner,provider:'torbox',label:clean(b.label,80)||'TorBox',credentials:'',created:new Date().toISOString()};c.credentials=await seal({token},owner,c.id);await tor(c,'user','me',{settings:false});await run('INSERT INTO cloud_connections VALUES(?,?,?,?,?,?)',c.id,owner,c.provider,c.label,c.credentials,c.created);return json({id:c.id,provider:c.provider,label:c.label},201)}
  if(path==='/api/cloud/google-drive/start'&&method==='POST'){
   const b=await body(),previous=b.connectionId?await connection(String(b.connectionId),owner):null;
   if(previous&&previous.provider!=='google-drive')throw new DriveError(400,'Keine Google-Drive-Verbindung.');
   const prior=previous?await open(previous.credentials,owner,previous.id):null;
   const clientId=String(b.clientId||prior?.client_id||'').trim(),clientSecret=String(b.clientSecret||prior?.client_secret||'').trim();
   if(!/^[A-Za-z0-9_-]{1,170}\.apps\.googleusercontent\.com$/.test(clientId)||!/^[A-Za-z0-9_-]{8,256}$/.test(clientSecret))throw new DriveError(400,'Bitte Client-ID und Client-Geheimnis des Google-OAuth-Webclients eingeben.');
   const state=newId(),verifier=newId()+newId(),redirectUri=url.origin+GOOGLE_CALLBACK,expires=Date.now()+10*60000;
   const challenge=btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier))))).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
   const authorization='https://accounts.google.com/o/oauth2/v2/auth?'+new URLSearchParams({
    client_id:clientId,redirect_uri:redirectUri,response_type:'code',scope:GOOGLE_SCOPE,access_type:'offline',prompt:'consent',state,code_challenge:challenge,code_challenge_method:'S256',
   });
   const credentials=await seal({clientId,clientSecret,verifier,redirectUri,connectionId:previous?.id||null,account:prior?.account||null},owner,state);
   await db.batch([db.prepare('DELETE FROM cloud_auth WHERE user_id=? AND expires<?').bind(owner,Date.now()),db.prepare('INSERT INTO cloud_auth VALUES(?,?,?,?,?,?)').bind(state,owner,credentials,expires,0,0)]);
   return json({authorization});
  }
  if(path===GOOGLE_CALLBACK&&method==='GET'){
   const redirect=(status:string)=>new Response(null,{status:303,headers:{Location:'/?google-drive='+status,'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
   const state=url.searchParams.get('state')||'';
   if(!/^[a-f0-9]{32}$/.test(state))return redirect('expired');
   const pending=await one('DELETE FROM cloud_auth WHERE id=? AND user_id=? AND interval=0 AND expires>? RETURNING credentials',state,owner,Date.now());
   if(!pending)return redirect('expired');
   const code=url.searchParams.get('code');
   if(url.searchParams.has('error')||!code||code.length>4096)return redirect('cancelled');
   try{
    const flow=await open(pending.credentials,owner,state);
    if(flow.redirectUri!==url.origin+GOOGLE_CALLBACK)return redirect('expired');
    const result=await googleExchange({client_id:flow.clientId,client_secret:flow.clientSecret,redirect_uri:flow.redirectUri,code_verifier:flow.verifier,code,grant_type:'authorization_code'});
    if(!result.access_token||!result.refresh_token||!String(result.scope||'').split(/\s+/).includes(GOOGLE_SCOPE))return redirect('permissions');
    const {user}=await providerJson(GOOGLE+'/about?fields=user(permissionId,displayName)',{headers:{Authorization:'Bearer '+result.access_token}});
    if(!user?.permissionId||flow.account&&flow.account!==user.permissionId)return redirect('account');
    const id=flow.connectionId||newId(),label=clean(user.displayName,60);
    const credentials=await seal({client_id:flow.clientId,client_secret:flow.clientSecret,...googleTokens(result),refresh_token:result.refresh_token,account:user.permissionId},owner,id);
    if(flow.connectionId){
     const saved=await run("UPDATE cloud_connections SET credentials=? WHERE id=? AND user_id=? AND provider='google-drive'",credentials,id,owner);
     if(!saved.meta.changes)return redirect('expired');
    }else await run('INSERT INTO cloud_connections VALUES(?,?,?,?,?,?)',id,owner,'google-drive',label?'Google Drive · '+label:'Google Drive',credentials,new Date().toISOString());
    return redirect('connected');
   }catch{return redirect('failed')}
  }
  if(path==='/api/cloud/onedrive/start'&&method==='POST'){const b=await body(),previous=b.connectionId?await connection(String(b.connectionId),owner):null;if(previous&&previous.provider!=='onedrive')throw new DriveError(400,'Keine OneDrive-Verbindung.');const prior=previous?await open(previous.credentials,owner,previous.id):null,clientId=clean(b.clientId||prior?.client_id||siteClientId,100),write=!!b.allowMove;if(!/^[a-f0-9-]{36}$/i.test(clientId))throw new DriveError(400,'Bitte die Microsoft-App-ID (Client-ID) eingeben.');
   const data=await providerJson(LOGIN+'/devicecode',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:clientId,scope:write?WRITE_SCOPES:SCOPES})});
   const verification=new URL(String(data.verification_uri));if(verification.protocol!=='https:'||!['microsoft.com','www.microsoft.com','login.microsoftonline.com'].includes(verification.hostname))throw new DriveError(502,'Ungültige Microsoft-Anmeldeadresse.');
   const id=newId(),interval=Math.max(5,Number(data.interval)||5),expires=Date.now()+Math.min(900,Number(data.expires_in)||900)*1000;
   await run('DELETE FROM cloud_auth WHERE user_id=? AND expires<?',owner,Date.now());await run('INSERT INTO cloud_auth VALUES(?,?,?,?,?,?)',id,owner,await seal({clientId,deviceCode:data.device_code,label:previous?.label||clean(b.label,80)||'OneDrive',connectionId:previous?.id||null},owner,id),expires,Date.now()+interval*1000,interval);
   return json({id,code:data.user_code,verificationUrl:verification.href,expires,interval});
  }
  let m=/^\/api\/cloud\/onedrive\/poll\/([a-f0-9]{32})$/.exec(path);
  if(m&&method==='POST'){const a=await one('SELECT * FROM cloud_auth WHERE id=? AND user_id=? AND interval>0',m[1],owner);if(!a||a.expires<Date.now())throw new DriveError(410,'Die Microsoft-Anmeldung ist abgelaufen. Bitte neu starten.');if(a.next_poll>Date.now())return json({pending:true,interval:a.interval});
   const data=await open(a.credentials,owner,a.id);await run('UPDATE cloud_auth SET next_poll=? WHERE id=? AND user_id=?',Date.now()+a.interval*1000,a.id,owner);
   let response:Response;try{response=await fetch(LOGIN+'/token',{method:'POST',redirect:'manual',signal:AbortSignal.timeout(20000),headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:data.clientId,grant_type:'urn:ietf:params:oauth:grant-type:device_code',device_code:data.deviceCode})})}catch{throw new DriveError(502,'Microsoft momentan nicht erreichbar.')}
   const result=await response.json() as Row;
   if(['authorization_pending','slow_down'].includes(result.error)){const interval=a.interval+(result.error==='slow_down'?5:0);await run('UPDATE cloud_auth SET interval=?,next_poll=? WHERE id=? AND user_id=?',interval,Date.now()+interval*1000,a.id,owner);return json({pending:true,interval})}
   if(!response.ok||!result.access_token||!result.refresh_token){await run('DELETE FROM cloud_auth WHERE id=? AND user_id=?',a.id,owner);throw new DriveError(401,'Microsoft-Anmeldung wurde nicht abgeschlossen. Bitte erneut starten.')}
   const previous=data.connectionId?await connection(data.connectionId,owner):null,c={id:previous?.id||newId(),user_id:owner,provider:'onedrive',label:data.label,created:previous?.created||new Date().toISOString()},credentials=await seal({client_id:data.clientId,access_token:result.access_token,refresh_token:result.refresh_token,canMove:/(?:^|\s)(?:https:\/\/graph\.microsoft\.com\/)?Files\.ReadWrite(?:\.All)?(?:\s|$)/i.test(String(result.scope||'')),expires:Date.now()+Number(result.expires_in||3600)*1000},owner,c.id);
   await db.batch([db.prepare('INSERT INTO cloud_connections VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET credentials=excluded.credentials WHERE cloud_connections.user_id=excluded.user_id').bind(c.id,owner,c.provider,c.label,credentials,c.created),db.prepare('DELETE FROM cloud_auth WHERE id=? AND user_id=?').bind(a.id,owner)]);return json({connected:true,connection:{id:c.id,provider:c.provider,label:c.label}});
  }
  m=/^\/api\/cloud\/connections\/([a-f0-9]{32})(?:\/(browse|import))?$/.exec(path);
  if(m){const c=await connection(m[1],owner);
   if(!m[2]&&method==='DELETE'){if(await one("SELECT id FROM cloud_transfers WHERE connection_id=? AND user_id=? AND status NOT IN ('done','kept','cancelled') LIMIT 1",c.id,owner))throw new DriveError(409,'Bitte laufende Übertragungen abschließen oder verwerfen, bevor du die Quelle trennst.');await db.batch([db.prepare('DELETE FROM cloud_connections WHERE id=? AND user_id=?').bind(c.id,owner),db.prepare('UPDATE cloud_files SET download_cache=NULL,cache_expires=0 WHERE connection_id=? AND user_id=?').bind(c.id,owner)]);return json({ok:true})}
   if(m[2]==='browse'&&method==='GET'){
    if(c.provider==='google-drive'){
     const parent=url.searchParams.get('parent')||'root',cursor=url.searchParams.get('cursor');
     if(!googleId(parent)||cursor&&cursor.length>4096)throw new DriveError(400,'Ungültiger Google-Drive-Ordner oder Seitenzeiger.');
     const data=await googleGet(c,'/files',{q:"'"+parent+"' in parents and trashed = false",fields:'nextPageToken,files('+GOOGLE_FIELDS+')',pageSize:'100',orderBy:'folder,name_natural',...(cursor?{pageToken:cursor}:{})});
     return json({items:(data.files||[]).map(mapGoogle),next:data.nextPageToken||null});
    }
    if(c.provider==='onedrive'){const parent=url.searchParams.get('parent')||'root',cursor=url.searchParams.get('cursor');if(cursor){const next=new URL(cursor);if(next.origin!=='https://graph.microsoft.com'||!/^\/v1\.0\/(?:me\/drive|drives\/[^/]+)\/(?:root|items\/[^/]+)\/children$/.test(next.pathname))throw new DriveError(400,'Ungültige OneDrive-Seite.')}
     const data=await graph(c,cursor||(parent==='root'?'/me/drive/root/children':'/me/drive/items/'+enc(parent)+'/children')+'?$top=100');return json({items:(data.value||[]).map(mapOne),next:data['@odata.nextLink']||null});
    }
    const type=url.searchParams.get('type')||'torrents';if(!torTypes.includes(type))throw new DriveError(400,'Ungültiger TorBox-Bereich.');const parent=url.searchParams.get('parent');if(parent&&!/^\d+$/.test(parent))throw new DriveError(400,'Ungültiger TorBox-Ordner.');const offset=Math.max(0,Math.min(100000,Number(url.searchParams.get('offset'))||0)),rows=await torList(c,type,parent||undefined,offset);
    const children=parent?rows.filter(r=>String(r.id)===parent).flatMap(r=>torFiles(r,type)):[];return json({items:parent?children.slice(offset,offset+100):rows.map(r=>({id:String(r.id),key:String(r.id),name:clean(r.name),folder:true,ready:r.download_finished===true||r.download_present===true,size:Number(r.size)||0})),next:parent?(children.length>offset+100?String(offset+100):null):rows.length===25?String(offset+25):null});
   }
   if(m[2]==='import'&&method==='POST'){const b=await body();if(!Array.isArray(b.keys)||!b.keys.length||b.keys.length>100)throw new DriveError(400,'Bitte 1 bis 100 Dateien auswählen.');const folder=b.folder||null;if(folder&&!await one('SELECT id FROM folders WHERE id=? AND user_id=?',folder,owner))throw new DriveError(404,'Zielordner nicht gefunden.');const created:string[]=[],existing:string[]=[];
    for(const remoteKey of [...new Set<string>(b.keys.map(String))]){let ref:Row;try{ref=JSON.parse(remoteKey)}catch{throw new DriveError(400,'Ungültige Cloud-Datei.')}const item=await resolveItem(c,ref);if(!Number.isSafeInteger(item.size)||item.size<0)throw new DriveError(502,'Ungültige Dateigröße der Cloud.');
     const previous=await one('SELECT f.id FROM files f JOIN cloud_files cf ON cf.object_id=COALESCE(f.object_id,f.id) AND cf.user_id=f.user_id WHERE f.user_id=? AND cf.connection_id=? AND cf.remote_key=? LIMIT 1',owner,c.id,item.key);if(previous){existing.push(previous.id);continue}
     let kind=clean(b.kind,80);if(!kind||kind==='auto')kind=inferCategory(item.name,item.mime);if(!BUILTIN_CATEGORIES.some(x=>x.id===kind)&&!await one('SELECT id FROM categories WHERE id=? AND user_id=?',kind,owner))throw new DriveError(400,'Kategorie nicht gefunden.');
     const id=newId(),now=new Date().toISOString(),episode=/S(\d+)E(\d+)/i.exec(item.name),series=clean(b.series,200),metadata={title:item.name.replace(/\.[^.]+$/,''),source:'manual'};
     await db.batch([db.prepare('INSERT INTO files(id,user_id,folder,name,mime,size,created,kind,series,season,episode) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(id,owner,folder,item.name,item.mime,item.size,now,kind,series,episode?Number(episode[1]):1,episode?Number(episode[2]):Math.max(1,Number(b.episode)||1)+created.length),db.prepare('INSERT INTO cloud_files(object_id,user_id,connection_id,remote_key,data) VALUES(?,?,?,?,?)').bind(id,owner,c.id,item.key,JSON.stringify(item)),db.prepare('INSERT INTO file_metadata(file_id,user_id,data,updated) VALUES(?,?,?,?)').bind(id,owner,JSON.stringify(metadata),now)]);created.push(id);
    }return json({created,existing},201);
   }
  }
  throw new DriveError(404,'Cloud-Funktion nicht gefunden.');
 }
 const refs=new Map<string,Promise<Row|null>>(),links=new Map<string,Promise<string>>();
 const remote=async(key:string)=>{const m=/^files\/([^/]+)\/([a-f0-9]{32})$/.exec(key);if(!m)return null;if(!refs.has(key))refs.set(key,one('SELECT * FROM cloud_files WHERE object_id=? AND user_id=?',m[2],m[1]));return refs.get(key)!};
 const download=async(f:Row,refresh=false):Promise<string>=>{
  const c=await connection(f.connection_id,f.user_id);if(!refresh&&f.download_cache&&f.cache_expires>Date.now()){const cached=await open(f.download_cache,f.user_id,'download:'+f.object_id);return cloudDownloadUrl(cached.url,c.provider)}
  const data=JSON.parse(f.data);let value:string;
  if(c.provider==='onedrive'){const item=await graph(c,'/drives/'+enc(data.ref.driveId)+'/items/'+enc(data.ref.itemId));if(Number(item.size)!==data.size||data.version&&(item.cTag||item.eTag)!==data.version)throw new DriveError(409,'Die Cloud-Datei hat sich geändert. Bitte die Verknüpfung entfernen und neu hinzufügen.');value=item['@microsoft.graph.downloadUrl']}
  else{const ref=data.ref,idName=ref.type==='torrents'?'torrent_id':ref.type==='webdl'?'web_id':'usenet_id',result=await tor(c,ref.type,'requestdl',{[idName]:ref.parent,file_id:ref.file,redirect:false});value=result.data}
  value=cloudDownloadUrl(value,c.provider);f.download_cache=await seal({url:value},f.user_id,'download:'+f.object_id);f.cache_expires=Date.now()+5*60000;await run('UPDATE cloud_files SET download_cache=?,cache_expires=? WHERE object_id=? AND user_id=?',f.download_cache,f.cache_expires,f.object_id,f.user_id);return value;
 };
 function wrapBucket(bucket:R2Bucket):R2Bucket{
  return new Proxy(bucket,{get(target,property){if(property!=='head'&&property!=='get'){const v=Reflect.get(target,property,target);return typeof v==='function'?v.bind(target):v}
   return async(key:string,options?:Row)=>{const f=await remote(key);if(!f)return property==='head'?target.head(key):target.get(key,options);const c=await connection(f.connection_id,f.user_id),data=JSON.parse(f.data),size=data.size,etag='cloud-'+f.object_id+'-'+size;
    const modified=new Date(data.modified||'2026-01-01T00:00:00Z');const head={key,size,etag,httpEtag:'"'+etag+'"',uploaded:Number.isFinite(modified.getTime())?modified:new Date('2026-01-01T00:00:00Z'),httpMetadata:{contentType:data.mime},customMetadata:{},checksums:{},version:etag,writeHttpMetadata(h:Headers){h.set('Content-Type',data.mime)}};
    if(property==='head')return head;
    let range='';const r=options?.range;if(r){if(r.suffix!==undefined)range='bytes=-'+r.suffix;else range='bytes='+Number(r.offset||0)+'-'+(r.length!==undefined?Number(r.offset||0)+r.length-1:'')}
    let response:Response;
    if(c.provider==='google-drive')response=await googleMedia(c,data,range);
    else{
     let address:string;
     if(!links.has(key))links.set(key,download(f));address=await links.get(key)!;
     for(let attempt=0;;attempt++){
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),30000);
      try{response=await fetch(address,{redirect:'manual',headers:{...(range?{Range:range}:{}),'Accept-Encoding':'identity'},signal:controller.signal})}catch{throw new DriveError(502,'Cloud-Stream momentan nicht erreichbar.')}finally{clearTimeout(timeout)}
      if([401,403,404].includes(response.status)&&attempt===0){await response.body?.cancel();address=await download(f,true);links.set(key,Promise.resolve(address));continue}
      if([301,302,303,307,308].includes(response.status)&&attempt<3){const location=response.headers.get('Location');await response.body?.cancel();address=cloudDownloadUrl(new URL(location||'',address).href,c.provider);continue}break;
     }
    }
    if(!response.ok||!response.body){await response.body?.cancel();throw new DriveError(response.status===429?429:502,'Die Cloud-Datei konnte nicht geladen werden.')}
    const expected=r? r.suffix!==undefined?Math.min(size,r.suffix):Math.min(r.length??size-(r.offset||0),size-(r.offset||0)):size;
    if(range&&response.status!==206||response.headers.has('Content-Length')&&Number(response.headers.get('Content-Length'))!==expected){await response.body.cancel();throw new DriveError(502,'Die Cloud unterstützt diesen Dateibereich nicht oder die Dateigröße hat sich geändert.')}
    if(range){const cr=/^bytes (\d+)-(\d+)\/(\d+)$/.exec(response.headers.get('Content-Range')||'');const start=r.suffix!==undefined?size-expected:r.offset||0;if(!cr||Number(cr[1])!==start||Number(cr[2])!==start+expected-1||Number(cr[3])!==size){await response.body.cancel();throw new DriveError(502,'Ungültiger Cloud-Dateibereich.')}}
    return {...head,body:response.body,bodyUsed:false,range:r,text:()=>response.text(),json:()=>response.json(),arrayBuffer:()=>response.arrayBuffer(),blob:()=>response.blob()};
   };
  }}) as R2Bucket;
 }
 const transfers=cloudTransfers(db,storage!,{
  connection,resolveItem,canMove,sourceBucket:()=>wrapBucket(storage!),
  allTorFiles:async(c,ref)=>{let rows:Row[];try{const result=await tor(c,ref.type,'mylist',{id:ref.parent,bypass_cache:true});rows=Array.isArray(result.data)?result.data:result.data?[result.data]:[]}catch(e){if(e instanceof DriveError&&e.status===404)return [];throw e}return rows.filter(r=>String(r.id)===ref.parent).flatMap(r=>torFiles(r,ref.type))},
  deleteSource:async(c,item)=>{
   if(c.provider==='google-drive')throw new DriveError(403,'Google Drive ist mit Lesezugriff verbunden.');
   if(c.provider==='onedrive'){
    let current:Row;try{current=await graph(c,'/drives/'+enc(item.ref.driveId)+'/items/'+enc(item.ref.itemId))}catch(e){if(e instanceof DriveError&&e.status===404)return;throw e}
    if(Number(current.size)!==item.size||item.version&&(current.cTag||current.eTag)!==item.version)throw new DriveError(409,'Die Quelldatei wurde verändert. Sie bleibt erhalten.');
    if(!current.eTag)throw new DriveError(409,'Die Quelle kann nicht sicher gegen Änderungen geprüft werden.');
    const response=await fetch(GRAPH+'/drives/'+enc(item.ref.driveId)+'/items/'+enc(item.ref.itemId),{method:'DELETE',redirect:'manual',signal:AbortSignal.timeout(20000),headers:{Authorization:'Bearer '+await graphToken(c),'If-Match':current.eTag}});await response.body?.cancel();
    if(![204,404].includes(response.status))throw new DriveError(response.status===412?409:response.status===401||response.status===403?403:502,'Die OneDrive-Quelle konnte nicht entfernt werden. Die Kopie bleibt in AndreDrive.');return;
   }
   const ref=item.ref,a=await open(c.credentials,c.user_id,c.id),action=ref.type==='torrents'?'controltorrent':ref.type==='webdl'?'controlwebdownload':'controlusenetdownload',idName=ref.type==='torrents'?'torrent_id':ref.type==='webdl'?'webdl_id':'usenet_id';
   await providerJson(TOR+'/'+ref.type+'/'+action,{method:'POST',headers:{Authorization:'Bearer '+a.token,'Content-Type':'application/json'},body:JSON.stringify({operation:'delete',[idName]:Number(ref.parent),all:false})});
  }
 });
 return {handle,wrapBucket};
}
