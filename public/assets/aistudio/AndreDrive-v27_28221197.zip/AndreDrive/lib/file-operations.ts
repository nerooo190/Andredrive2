type Row=Record<string,any>;
export class DriveError extends Error{constructor(public status:number,message:string){super(message)}}
export const objectKey=(f:Row)=>`files/${f.user_id}/${f.object_id||f.id}`;
export const posterKey=(f:Row)=>`posters/${f.user_id}/${f.poster_id||f.id}`;
export const newId=()=>crypto.randomUUID().replaceAll('-','');
export function driveStorage(db:D1Database,bucket:R2Bucket,user:string){
 const one=(sql:string,...args:any[])=>db.prepare(sql).bind(...args).first<Row>();
 const all=async(sql:string,...args:any[])=>(await db.prepare(sql).bind(...args).all<Row>()).results;
 const file=async(id:string)=>await one('SELECT * FROM files WHERE id=? AND user_id=?',id,user)??Promise.reject(new DriveError(404,'Datei nicht gefunden.'));
 const folder=async(id:string|null)=>id?await one('SELECT * FROM folders WHERE id=? AND user_id=?',id,user)??Promise.reject(new DriveError(404,'Ordner nicht gefunden.')):null;
 const freeName=async(name:string,parent:string|null)=>{const occupied=new Set((await all('SELECT name FROM files WHERE user_id=? AND folder IS ? UNION ALL SELECT name FROM folders WHERE user_id=? AND parent IS ?',user,parent,user,parent)).map(f=>f.name));if(!occupied.has(name))return name;const match=/^(.*?)(\.[^.]+)?$/.exec(name)!,base=match[1],ext=match[2]||'';for(let n=2;n<=10000;n++){const next=`${base} (${n})${ext}`;if(!occupied.has(next))return next}throw new DriveError(409,'Zu viele gleichnamige Dateien.');};
 const transfer=async(id:string,parent:string|null,copy:boolean,name?:string)=>{
  const f=await file(id);await folder(parent);if(!copy&&f.folder===parent&&(name==null||name===f.name))return f;
  const targetName=name??await freeName(f.name,parent);
  if(!copy){await db.prepare('UPDATE files SET folder=?,name=? WHERE id=? AND user_id=?').bind(parent,targetName,id,user).run();return {...f,folder:parent,name:targetName}}
  const next=newId(),created=new Date().toISOString();
  const result=await db.batch([
   db.prepare('INSERT INTO files(id,user_id,folder,name,mime,size,created,kind,series,season,episode,starred,hls,object_id,poster_id) SELECT ?,user_id,?,?,mime,size,?,kind,series,season,episode,starred,hls,COALESCE(object_id,id),COALESCE(poster_id,id) FROM files WHERE id=? AND user_id=?').bind(next,parent,targetName,created,id,user),
   db.prepare('INSERT INTO file_metadata(file_id,user_id,data,updated) SELECT ?,user_id,data,? FROM file_metadata WHERE file_id=? AND user_id=? AND EXISTS(SELECT 1 FROM files WHERE id=? AND user_id=?)').bind(next,created,id,user,next,user)
  ]);if(!result[0].meta.changes)throw new DriveError(404,'Die Quelldatei existiert nicht mehr.');
  return {...f,id:next,folder:parent,name:targetName,created,object_id:f.object_id||f.id,poster_id:f.poster_id||f.id};
 };
 const cleanup=async(f:Row)=>{
  const content=f.object_id||f.id,poster=f.poster_id||f.id;
  if(!await one('SELECT id FROM files WHERE user_id=? AND COALESCE(object_id,id)=? UNION ALL SELECT id FROM trash_files WHERE user_id=? AND object_id=? LIMIT 1',user,content,user,content)){await bucket.delete(objectKey(f));await db.prepare('DELETE FROM cloud_files WHERE object_id=? AND user_id=?').bind(content,user).run()}
  if(!await one(`SELECT id FROM files WHERE user_id=? AND COALESCE(poster_id,id)=? UNION ALL SELECT id FROM trash_files WHERE user_id=? AND poster_id=? UNION ALL SELECT id FROM cloud_transfers WHERE user_id=? AND json_extract(data,'$.file.poster_id')=? AND status IN ('copying','verifying','source_pending') LIMIT 1`,user,poster,user,poster,user,poster))await bucket.delete(posterKey(f));
 };
 const removeFile=async(id:string)=>{const f=await file(id);await db.batch([db.prepare('DELETE FROM files WHERE id=? AND user_id=?').bind(id,user),db.prepare('DELETE FROM file_metadata WHERE file_id=? AND user_id=?').bind(id,user),db.prepare('DELETE FROM iptv_streams WHERE file_id=?').bind(id),db.prepare("DELETE FROM links WHERE user_id=? AND type='file' AND target=?").bind(user,id)]);await cleanup(f)};
 const trashFile=async(id:string)=>{const f=await file(id),deleted=new Date().toISOString();await db.batch([
  db.prepare("INSERT INTO trash_files(id,user_id,object_id,poster_id,data,metadata,deleted) SELECT id,user_id,COALESCE(object_id,id),COALESCE(poster_id,id),?,COALESCE((SELECT data FROM file_metadata WHERE file_id=files.id AND user_id=files.user_id),'{}'),? FROM files WHERE id=? AND user_id=?").bind(JSON.stringify(f),deleted,id,user),
  db.prepare('DELETE FROM file_metadata WHERE file_id=? AND user_id=?').bind(id,user),db.prepare('DELETE FROM files WHERE id=? AND user_id=?').bind(id,user),db.prepare('DELETE FROM iptv_streams WHERE file_id=?').bind(id),
  db.prepare("DELETE FROM links WHERE user_id=? AND ((type='file' AND target=?) OR (type IN ('playlist','collection') AND EXISTS(SELECT 1 FROM json_each(links.target) WHERE value=?)))").bind(user,id,id)
 ]);return {id,deleted}};
 const restoreFile=async(id:string)=>{const t=await one('SELECT * FROM trash_files WHERE id=? AND user_id=?',id,user);if(!t)throw new DriveError(404,'Datei im Papierkorb nicht gefunden.');const f=JSON.parse(t.data);if(f.kind.startsWith('custom_')&&!await one('SELECT id FROM categories WHERE id=? AND user_id=?',f.kind,user))f.kind='other';if(f.folder&&!await one('SELECT id FROM folders WHERE id=? AND user_id=?',f.folder,user))f.folder=null;f.name=await freeName(f.name,f.folder);await db.batch([
  db.prepare('INSERT INTO files(id,user_id,folder,name,mime,size,created,kind,series,season,episode,starred,hls,object_id,poster_id) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM trash_files WHERE id=? AND user_id=?)').bind(f.id,user,f.folder,f.name,f.mime,f.size,f.created,f.kind,f.series,f.season,f.episode,f.starred,f.hls,f.object_id||null,f.poster_id||null,id,user),
  db.prepare('INSERT INTO file_metadata(file_id,user_id,data,updated) VALUES(?,?,?,?)').bind(id,user,t.metadata,new Date().toISOString()),db.prepare('DELETE FROM trash_files WHERE id=? AND user_id=?').bind(id,user)
 ]);return f};
 const purgeFile=async(id:string)=>{const t=await one('SELECT * FROM trash_files WHERE id=? AND user_id=?',id,user);if(!t)throw new DriveError(404,'Datei im Papierkorb nicht gefunden.');await db.prepare('DELETE FROM trash_files WHERE id=? AND user_id=?').bind(id,user).run();await cleanup(JSON.parse(t.data))};
 return {file,folder,freeName,transfer,cleanup,removeFile,trashFile,restoreFile,purgeFile,one,all};
}
