import {inferCategory} from './categories';
import {driveStorage,DriveError,objectKey,newId} from './file-operations';
import {fixedLengthBody,singleRange,mediaType,type RequestLifetime} from './media-stream';
type Row=Record<string,any>;
type Node={row:Row|null,folder:boolean,name:string,path:string};
const rommDavPath=(path:string)=>path==='/romm-library'||path.startsWith('/romm-library/');
export const webdavPath=(path:string)=>path==='/webdav'||path.startsWith('/webdav/')||rommDavPath(path);
export const MAX_DAV_PUT=64*1024**2;
export async function webdavHash(password:string){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(password)))].map(b=>b.toString(16).padStart(2,'0')).join('')}
const xml=(s:unknown)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));
const nameSafe=(s:string)=>s.replace(/[\x00-\x1f\x7f/\\]/g,'_').replace(/^\.{1,2}$/,'_')||'_';
const etag=(f:Row)=>`"${f.object_id||f.id}-${f.size}"`;
const methodList='OPTIONS, PROPFIND, GET, HEAD, PUT, MKCOL, COPY, MOVE, DELETE';
function response(body:BodyInit|null=null,status=200,extra:HeadersInit={}){const headers=new Headers(extra);headers.set('Cache-Control','private, no-store, no-transform');headers.set('Referrer-Policy','no-referrer');headers.set('X-Content-Type-Options','nosniff');return new Response(body,{status,headers})}
const multi=(body:string)=>response(`<?xml version="1.0" encoding="UTF-8"?><d:multistatus xmlns:d="DAV:">${body}</d:multistatus>`,207,{'Content-Type':'application/xml; charset=utf-8'});
export async function handleWebDav(request:Request,db:D1Database,bucket:R2Bucket,lifetime?:RequestLifetime):Promise<Response>{
 const url=new URL(request.url),method=request.method,romm=rommDavPath(url.pathname);
 const prefix=romm?'/romm-library':'/webdav',allowed=romm?'OPTIONS, PROPFIND, GET, HEAD':methodList;
 try{
  if(method==='OPTIONS')return response(null,204,{'DAV':'1','Allow':allowed,'MS-Author-Via':'DAV'});
  if(url.protocol!=='https:'&&url.hostname!=='localhost'&&url.hostname!=='127.0.0.1'&&url.hostname!=='drive.test')throw new DriveError(400,'WebDAV erfordert HTTPS.');
  let username='',password='';const auth=request.headers.get('Authorization')||'';
  try{if(/^Basic /i.test(auth)){const value=atob(auth.slice(6).trim()),at=value.indexOf(':');if(at>0){username=value.slice(0,at);password=value.slice(at+1)}}}catch{}
  const validUser=(romm?/^romm_[a-f0-9]{32}$/:/^ad_[a-f0-9]{32}$/).test(username);
  const accountSql=romm
   ? 'SELECT user_id,password_hash,folder_id,0 AS can_write FROM romm_settings WHERE username=?'
   : 'SELECT user_id,password_hash,can_write FROM webdav_accounts WHERE username=?';
  const account=validUser&&/^[a-f0-9]{64}$/.test(password)?await db.prepare(accountSql).bind(username).first<Row>():null;
  if(!account||account.password_hash!==await webdavHash(password))return response('WebDAV-Zugangsdaten erforderlich.',401,{'WWW-Authenticate':`Basic realm="${romm?'AndreDrive RomM':'AndreDrive WebDAV'}", charset="UTF-8"`});
  const storage=driveStorage(db,bucket,account.user_id);
  if(!['GET','HEAD','PROPFIND'].includes(method)&&!account.can_write)throw new DriveError(403,'Dieser Gerätezugang hat nur Leserechte.');
  if(!methodList.split(', ').includes(method))return response(null,405,{Allow:methodList});
  const segments=(pathname:string)=>{
   if(pathname!==prefix&&!pathname.startsWith(prefix+'/'))throw new DriveError(403,'Ziel außerhalb des WebDAV-Zugangs.');
   try{return pathname.slice(prefix.length).replace(/\/$/,'').split('/').filter(Boolean).map(p=>{const part=decodeURIComponent(p);if(!part||part==='.'||part==='..'||/[\x00-\x1f\x7f/\\]/.test(part)||part.length>255)throw Error();return part})}catch{throw new DriveError(400,'Ungültiger WebDAV-Pfad.');}
  };
  const root:Node={row:null,folder:true,name:romm?'AndreDrive RomM':'AndreDrive',path:prefix+'/'};
  const children=async(node:Node):Promise<Node[]>=>{
   if(romm&&node===root){
    const source=await db.prepare('SELECT * FROM folders WHERE id=? AND user_id=?').bind(account.folder_id,account.user_id).first<Row>();
    return source?[{row:source,folder:true,name:'roms',path:root.path+'roms/'}]:[];
   }
   const parent=node.row?.id||null;
   const [dirs,files]=await Promise.all([
    storage.all('SELECT * FROM folders WHERE user_id=? AND parent IS ? ORDER BY id',account.user_id,parent),
    romm&&parent===account.folder_id?[]:storage.all('SELECT * FROM files WHERE user_id=? AND folder IS ? ORDER BY id',account.user_id,parent),
   ]);
   const rows=[...dirs.map(row=>({row,folder:true})),...files.map(row=>({row,folder:false}))],counts=new Map<string,number>(),used=new Set<string>();
   for(const {row} of rows){const name=nameSafe(row.name);counts.set(name,(counts.get(name)||0)+1);used.add(name)}
   return rows.map(({row,folder})=>{let name=nameSafe(row.name);if(counts.get(name)!>1){const dot=!folder?name.lastIndexOf('.'):-1,base=dot>0?name.slice(0,dot):name,ext=dot>0?name.slice(dot):'';let n=0;do{name=`${base} [${row.id}${n?'-'+n:''}]${ext}`;n++}while(used.has(name));used.add(name)}return {row,folder,name,path:node.path+encodeURIComponent(name)+(folder?'/':'')}});
  };
  const resolve=async(parts:string[]):Promise<Node|null>=>{let node=root;for(const part of parts){if(!node.folder)return null;const found=(await children(node)).find(n=>n.name===part);if(!found)return null;node=found}return node};
  const parts=segments(url.pathname),node=await resolve(parts);
  const preconditions=(entry:Node|null)=>{const tag=entry&&!entry.folder?etag(entry.row!):null,match=request.headers.get('If-Match'),none=request.headers.get('If-None-Match');if(match&&(!entry||(match!=='*'&&!match.split(/,\s*/).includes(tag||''))))throw new DriveError(412,'Die Datei wurde zwischenzeitlich geändert.');if(none&&(none==='*'?!!entry:!!tag&&none.split(/,\s*/).includes(tag))){if(method==='GET'||method==='HEAD')return false;throw new DriveError(412,'Das Ziel existiert bereits.');}if(request.headers.has('If'))throw new DriveError(412,'WebDAV-Sperren werden nicht unterstützt.');return true};
  if(!preconditions(node))return response(null,304,node&&!node.folder?{ETag:etag(node.row!)}:{});
  const parent=async(p:string[])=>{if(!p.length)throw new DriveError(403,'Die WebDAV-Wurzel kann nicht verändert werden.');const dir=await resolve(p.slice(0,-1));if(!dir?.folder)throw new DriveError(409,'Zielordner nicht gefunden.');return dir};
  const tree=async(start:Node)=>{const list:Node[]=[start];for(let i=0;i<list.length;i++){if(list[i].folder)list.push(...await children(list[i]));if(list.length>2000)throw new DriveError(507,'Bitte große Ordner in kleineren Gruppen bearbeiten.');}return list};
  const remove=async(entry:Node)=>{if(!entry.row)throw new DriveError(403,'Die WebDAV-Wurzel kann nicht gelöscht werden.');const entries=entry.folder?await tree(entry):[entry];for(const n of entries.filter(n=>!n.folder))await storage.removeFile(n.row!.id);const dirs=entries.filter(n=>n.folder).reverse();for(let i=0;i<dirs.length;i+=40)await db.batch(dirs.slice(i,i+40).flatMap(n=>[db.prepare('DELETE FROM folders WHERE id=? AND user_id=?').bind(n.row!.id,account.user_id),db.prepare("DELETE FROM links WHERE user_id=? AND type='folder' AND target=?").bind(account.user_id,n.row!.id)]))};
  if(method==='PROPFIND'){
   if(!node)throw new DriveError(404,'Pfad nicht gefunden.');
   const depth=request.headers.get('Depth')||'infinity';if(depth==='infinity')return response('<?xml version="1.0"?><d:error xmlns:d="DAV:"><d:propfind-finite-depth/></d:error>',403,{'Content-Type':'application/xml'});if(!['0','1'].includes(depth))throw new DriveError(400,'Depth muss 0 oder 1 sein.');
   const declared=Number(request.headers.get('Content-Length')||0);if(declared>65536)throw new DriveError(413,'PROPFIND zu groß.');
   const chunks:Uint8Array[]=[];let size=0;if(request.body){const reader=request.body.getReader();for(;;){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>65536){await reader.cancel();throw new DriveError(413,'PROPFIND zu groß.')}chunks.push(r.value)}}
   const data=new Uint8Array(size);let offset=0;for(const c of chunks){data.set(c,offset);offset+=c.length}const body=new TextDecoder().decode(data);
   if(/<!DOCTYPE|<!ENTITY/i.test(body))throw new DriveError(400,'XML-Entitäten werden nicht unterstützt.');
   const propBlock=/<(?:[\w-]+:)?prop(?:\s[^>]*)?>([\s\S]*?)<\/(?:[\w-]+:)?prop>/.exec(body),propname=/<(?:[\w-]+:)?propname[\s/>]/.test(body);
   const namespaces=new Map<string,string>();for(const m of body.matchAll(/xmlns(?::([\w-]+))?=["']([^"']*)["']/g))namespaces.set(m[1]||'',m[2]);
   const wanted=propBlock?[...propBlock[1].matchAll(/<((?:[\w-]+:)?[\w-]+)(?:\s[^>]*)?\s*\/?\s*>/g)].map(m=>{const [prefix,local]=m[1].includes(':')?m[1].split(':'):['',m[1]];return {name:local,namespace:namespaces.get(prefix)||''}}):null;
   const entries=depth==='1'&&node.folder?[node,...await children(node)]:[node];
   return multi(entries.map(n=>{
    const f=n.row,modified=f?.created||'2026-01-01T00:00:00Z',values:Record<string,string>={displayname:xml(n.name),resourcetype:n.folder?'<d:collection/>':'',getcontentlength:String(n.folder?0:f!.size),getcontenttype:n.folder?'httpd/unix-directory':xml(mediaType(f!.name,f!.mime)),getlastmodified:xml(new Date(modified).toUTCString()),creationdate:xml(modified),getetag:n.folder?'':xml(etag(f!)),supportedlock:'',lockdiscovery:''};
    const requested=wanted||Object.keys(values).map(name=>({name,namespace:'DAV:'})),ok:string[]=[],missing:string[]=[];
    for(const p of requested){const tag=p.namespace==='DAV:'?'d:'+p.name:'x:'+p.name,attr=p.namespace==='DAV:'?'':` xmlns:x="${xml(p.namespace)}"`;if(p.namespace==='DAV:'&&p.name in values)ok.push(propname?`<${tag}/>`:`<${tag}>${values[p.name]}</${tag}>`);else missing.push(`<${tag}${attr}/>`)}
    return `<d:response><d:href>${xml(n.path)}</d:href>${ok.length?`<d:propstat><d:prop>${ok.join('')}</d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat>`:''}${missing.length?`<d:propstat><d:prop>${missing.join('')}</d:prop><d:status>HTTP/1.1 404 Not Found</d:status></d:propstat>`:''}</d:response>`;
   }).join(''));
  }
  if(method==='GET'||method==='HEAD'){
   if(!node)throw new DriveError(404,'Pfad nicht gefunden.');
   if(node.folder){const list=await children(node);return response(method==='HEAD'?null:`<!doctype html><meta charset="utf-8"><title>AndreDrive WebDAV</title><h1>${xml(node.name)}</h1><ul>${list.map(n=>`<li><a href="${xml(n.path)}">${xml(n.name)}${n.folder?'/':''}</a></li>`).join('')}</ul>`,200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"sandbox; default-src 'none'; base-uri 'none'"})}
   const f=node.row!,head=await bucket.head(objectKey(f));if(!head)throw new DriveError(404,'Datei nicht gefunden.');
   const headers=new Headers({'Content-Type':mediaType(f.name,f.mime),'Accept-Ranges':'bytes','Content-Encoding':'identity',ETag:etag(f),'Last-Modified':new Date(f.created).toUTCString(),'Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(f.name).replace(/['()*]/g,c=>'%'+c.charCodeAt(0).toString(16))}`});
   const type=mediaType(f.name,f.mime);if(!type.startsWith('video/')&&!type.startsWith('audio/')&&!['image/jpeg','image/png','image/webp','image/gif'].includes(type))headers.set('Content-Security-Policy',"sandbox; default-src 'none'");
   const ifRange=request.headers.get('If-Range');let range:null|{offset:number,length:number};try{range=singleRange(method==='GET'&&(!ifRange||ifRange===etag(f)||ifRange===headers.get('Last-Modified'))?request.headers.get('Range'):null,head.size)}catch{headers.set('Content-Range',`bytes */${head.size}`);headers.set('Content-Length','0');return response(null,416,headers)}const length=range?.length??head.size;headers.set('Content-Length',String(length));if(range)headers.set('Content-Range',`bytes ${range.offset}-${range.offset+length-1}/${head.size}`);
   if(method==='HEAD'||!length)return response(null,range?206:200,headers);
   const object=await bucket.get(objectKey(f),range?{range}:{});if(!object)throw new DriveError(404,'Datei nicht gefunden.');
   return response(fixedLengthBody(object.body,length,lifetime),range?206:200,headers);
  }
  if(method==='MKCOL'){if(node)throw new DriveError(405,'Der Pfad existiert bereits.');const dir=await parent(parts);if(request.body){const reader=request.body.getReader(),first=await reader.read();await reader.cancel();if(!first.done)throw new DriveError(415,'MKCOL mit Inhalt wird nicht unterstützt.')}await db.prepare('INSERT INTO folders(id,user_id,name,parent,created) VALUES(?,?,?,?,?)').bind(newId(),account.user_id,parts.at(-1),dir.row?.id||null,new Date().toISOString()).run();return response(null,201)}
  if(method==='DELETE'){if(!node)throw new DriveError(404,'Pfad nicht gefunden.');await remove(node);return response(null,204)}
  if(method==='COPY'||method==='MOVE'){
   if(!node?.row)throw new DriveError(403,'Die WebDAV-Wurzel kann nicht kopiert oder verschoben werden.');
   let destination:URL;try{destination=new URL(request.headers.get('Destination')||'',url)}catch{throw new DriveError(400,'Destination fehlt.');}if(!request.headers.get('Destination')||destination.origin!==url.origin||destination.search||destination.hash)throw new DriveError(403,'Ungültiges WebDAV-Ziel.');
   const to=segments(destination.pathname),dir=await parent(to),existing=await resolve(to),name=to.at(-1)!;
   if(existing&&existing.row?.id===node.row.id&&existing.folder===node.folder)throw new DriveError(403,'Quelle und Ziel sind identisch.');
   if(node.folder&&existing?.folder){let ancestor:Row|null=node.row;while(ancestor?.parent){ancestor=await storage.folder(ancestor.parent);if(ancestor?.id===existing.row?.id)throw new DriveError(409,'Ein übergeordneter Ordner kann nicht überschrieben werden.');}}
   if(node.folder){let at=dir.row;while(at){if(at.id===node.row.id)throw new DriveError(409,'Ein Ordner kann nicht in sich selbst verschoben oder kopiert werden.');at=at.parent?await storage.folder(at.parent):null}if(existing?.folder){const sourceTree=await tree(node);if(sourceTree.some(n=>n.folder&&n.row?.id===existing.row?.id))throw new DriveError(409,'Das Ziel überschneidet sich mit dem Quellordner.');}}
   const overwrite=request.headers.get('Overwrite')||'T';if(!['T','F'].includes(overwrite))throw new DriveError(400,'Overwrite muss T oder F sein.');if(existing&&overwrite==='F')throw new DriveError(412,'Das Ziel existiert bereits.');if(existing&&existing.folder!==node.folder)throw new DriveError(409,'Datei und Ordner können einander nicht überschreiben.');
   if(method==='MOVE'&&node.folder&&request.headers.has('Depth')&&request.headers.get('Depth')!=='infinity')throw new DriveError(400,'MOVE benötigt Depth infinity.');
   const depth=request.headers.get('Depth')||'infinity';if(method==='COPY'&&!['0','infinity'].includes(depth))throw new DriveError(400,'COPY benötigt Depth 0 oder infinity.');
   const entries=method==='COPY'&&node.folder&&depth!=='0'?await tree(node):[node];
   if(existing)await remove(existing);
   if(!node.folder)await storage.transfer(node.row.id,dir.row?.id||null,method==='COPY',name);
   else if(method==='MOVE')await db.prepare('UPDATE folders SET parent=?,name=? WHERE id=? AND user_id=?').bind(dir.row?.id||null,name,node.row.id,account.user_id).run();
   else{const mapped=new Map<string,string>();for(const n of entries){if(n.folder){const id=newId(),isRoot=n.row!.id===node.row.id;await db.prepare('INSERT INTO folders(id,user_id,name,parent,created) VALUES(?,?,?,?,?)').bind(id,account.user_id,isRoot?name:n.row!.name,isRoot?dir.row?.id||null:mapped.get(n.row!.parent),new Date().toISOString()).run();mapped.set(n.row!.id,id)}else await storage.transfer(n.row!.id,mapped.get(n.row!.folder)||null,true)}}
   return response(null,existing?204:201);
  }
  if(method==='PUT'){
   if(node?.folder)throw new DriveError(405,'Eine Datei kann keinen Ordner überschreiben.');const dir=await parent(parts),declared=request.headers.get('Content-Length'),length=declared===null?null:Number(declared);if(length!==null&&(!Number.isSafeInteger(length)||length<0||length>MAX_DAV_PUT))throw new DriveError(413,'WebDAV-Uploads sind bis 64 MiB möglich. Für große Dateien bitte den fortsetzbaren Upload in AndreDrive nutzen.');
   if(request.headers.has('Content-Range'))throw new DriveError(400,'Teil-Uploads per PUT werden nicht unterstützt.');
   const id=node?.row?.id||newId(),blob=newId(),key=`files/${account.user_id}/${blob}`,name=parts.at(-1)!,mime=mediaType(name,request.headers.get('Content-Type')||'application/octet-stream'),upload=await bucket.createMultipartUpload(key,{httpMetadata:{contentType:mime}});let size=0,part=1,buffer=new Uint8Array(8*1024**2),used=0;const uploaded:R2UploadedPart[]=[];
   try{if(request.body){const reader=request.body.getReader();for(;;){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>MAX_DAV_PUT){await reader.cancel();throw new DriveError(413,'WebDAV-Uploads sind auf 64 MiB begrenzt.')}let at=0;while(at<r.value.length){const take=Math.min(buffer.length-used,r.value.length-at);buffer.set(r.value.subarray(at,at+take),used);used+=take;at+=take;if(used===buffer.length){uploaded.push(await upload.uploadPart(part++,buffer));used=0;buffer=new Uint8Array(8*1024**2)}}}}if(length!==null&&size!==length)throw new DriveError(400,'Die übertragene Größe stimmt nicht.');if(used)uploaded.push(await upload.uploadPart(part,buffer.subarray(0,used)));if(size)await upload.complete(uploaded);else{await upload.abort();await bucket.put(key,new Uint8Array(),{httpMetadata:{contentType:mime}})}}catch(e){await upload.abort().catch(()=>{});throw e}
   const created=new Date().toISOString();let result:D1Result;
   if(node?.row)result=await db.prepare("UPDATE files SET object_id=?,mime=?,size=?,created=?,hls='none' WHERE id=? AND user_id=? AND object_id IS ?").bind(blob,mime,size,created,id,account.user_id,node.row.object_id).run();
   else result=await db.prepare("INSERT INTO files(id,user_id,folder,name,mime,size,created,kind,object_id) SELECT ?,?,?,?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM files WHERE user_id=? AND folder IS ? AND name=?) AND NOT EXISTS(SELECT 1 FROM folders WHERE user_id=? AND parent IS ? AND name=?)").bind(id,account.user_id,dir.row?.id||null,name,mime,size,created,inferCategory(name,mime),blob,account.user_id,dir.row?.id||null,name,account.user_id,dir.row?.id||null,name).run();
   if(!result.meta.changes){await bucket.delete(key);throw new DriveError(412,'Das Ziel wurde zwischenzeitlich geändert.');}
   if(node?.row){await db.prepare('UPDATE iptv_streams SET hls=NULL,duration=0 WHERE file_id=?').bind(id).run();await storage.cleanup(node.row)}
   return response(null,node?204:201,{ETag:etag({id,object_id:blob,size})});
  }
  return response(null,405,{Allow:methodList});
 }catch(e){if(e instanceof DriveError)return response(request.method==='HEAD'?null:e.message,e.status,{'Content-Type':'text/plain; charset=utf-8'});throw e}
}
