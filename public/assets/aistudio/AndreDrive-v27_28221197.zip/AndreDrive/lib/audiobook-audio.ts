import {inspectMp4} from './media-stream';

const tag = (data: Uint8Array, at: number, length: number) =>
  String.fromCharCode(...data.subarray(at,at+length));

export async function probeAudioDuration(bucket: R2Bucket, key: string, size: number, mime: string) {
  if (size < 12) return 0;
  if (mime === 'audio/mp4') return (await inspectMp4(bucket,key,size)).duration || 0;
  if (!['audio/mpeg','audio/flac','audio/wav','audio/x-wav'].includes(mime)) return 0;
  const read = async (offset: number) => {
    const object = await bucket.get(key,{range:{offset,length:Math.min(65536,size-offset)}});
    return object ? new Uint8Array(await object.arrayBuffer()) : new Uint8Array();
  };
  let offset = 0, bytes = await read(0);
  if (bytes.length < 12) return 0;
  if (tag(bytes,0,3) === 'ID3') {
    offset = 10 + bytes[6]*2097152 + bytes[7]*16384 + bytes[8]*128 + bytes[9] + (bytes[5]&16 ? 10 : 0);
    if (offset >= size) return 0;
    bytes = offset < bytes.length - 1024 ? bytes.subarray(offset) : await read(offset);
  }
  const view = new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if (tag(bytes,0,4) === 'fLaC' && bytes.length >= 42 && (bytes[4]&127) === 0) {
    const high = view.getUint32(18);
    const rate = high >>> 12, samples = (high & 15) * 2**32 + view.getUint32(22);
    return rate ? samples/rate : 0;
  }
  if (tag(bytes,0,4) === 'RIFF' && tag(bytes,8,4) === 'WAVE') {
    let byteRate = 0;
    for (let p=12; p+8<=bytes.length;) {
      const chunk = tag(bytes,p,4), length = view.getUint32(p+4,true);
      if (chunk === 'fmt ' && length >= 16 && p+24 <= bytes.length) byteRate = view.getUint32(p+16,true);
      if (chunk === 'data') return byteRate ? Math.min(length,size-offset-p-8)/byteRate : 0;
      p += 8 + length + (length&1);
    }
  }
  if (mime !== 'audio/mpeg') return 0;
  const frame = (p: number) => {
    if (p+4 > bytes.length || bytes[p]!==255 || (bytes[p+1]&224)!==224) return null;
    const version = (bytes[p+1]>>3)&3, layer = (bytes[p+1]>>1)&3;
    const bitrateIndex = bytes[p+2]>>4, rateIndex = (bytes[p+2]>>2)&3;
    if (version===1 || layer!==1 || !bitrateIndex || bitrateIndex===15 || rateIndex===3) return null;
    const rates = version===3 ? [0,32,40,48,56,64,80,96,112,128,160,192,224,256,320] :
      [0,8,16,24,32,40,48,56,64,80,96,112,128,144,160];
    const bitrate = rates[bitrateIndex], rate = [44100,48000,32000][rateIndex]/(version===3?1:version===2?2:4);
    const samples = version===3 ? 1152 : 576;
    return {bitrate,rate,samples,length:Math.floor(samples/8*bitrate*1000/rate)+((bytes[p+2]>>1)&1),version};
  };
  for (let p=0; p+4<=bytes.length; p++) {
    const info=frame(p), next=info && frame(p+info.length);
    if (!info || !next || next.rate!==info.rate) continue;
    const mono=(bytes[p+3]>>6)===3;
    const xing=p+4+((bytes[p+1]&1) ? 0 : 2)+(info.version===3 ? (mono?17:32) : (mono?9:17));
    if (xing+12<=bytes.length && ['Xing','Info'].includes(tag(bytes,xing,4)) && (view.getUint32(xing+4)&1)) {
      return view.getUint32(xing+8)*info.samples/info.rate;
    }
    const vbri=p+36;
    if (vbri+18<=bytes.length && tag(bytes,vbri,4)==='VBRI') return view.getUint32(vbri+14)*info.samples/info.rate;
    return (size-offset-p)*8/(info.bitrate*1000);
  }
  return 0;
}
