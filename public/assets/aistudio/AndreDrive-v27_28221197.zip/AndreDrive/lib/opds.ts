import {timingSafeEqual} from 'node:crypto';
import {DriveError, newId} from './file-operations';
import {webdavHash} from './webdav';

type Row = Record<string, any>;
type Link = {href: string; rel: string; type: string; title?: string; templated?: boolean; length?: number};
type Navigation = {title: string; link: Link};
type Publication = {
  id: string; title: string; author: string; description: string; language: string;
  kind: string; updated: string; download: Link; cover?: Link;
};
type Feed = {
  title: string; links: Link[]; navigation?: Navigation[]; publications?: Publication[];
  total?: number; page: number;
};
type Services = {
  content(file: Row, options: {mime: string; download: boolean}): Promise<Response>;
  poster(file: Row): Promise<Response>;
};
type Format = 'book' | 'document' | 'comic';
const categories: Record<Format, string> = {book:'Bücher', document:'Dokumente', comic:'Comics & Mangas'};
const types: Record<Format, Record<string,string>> = {
  book: {
    epub:'application/epub+zip', mobi:'application/x-mobipocket-ebook', prc:'application/x-mobipocket-ebook',
    azw:'application/vnd.amazon.ebook', azw3:'application/vnd.amazon.ebook', kfx:'application/vnd.amazon.ebook',
    fb2:'application/x-fictionbook+xml', djvu:'image/vnd.djvu', djv:'image/vnd.djvu',
    lit:'application/x-ms-reader', lrf:'application/x-sony-bbeb', pdb:'application/vnd.palm',
  },
  comic: {
    cbz:'application/vnd.comicbook+zip', cbr:'application/vnd.comicbook-rar',
    cb7:'application/x-cb7', cbt:'application/x-cbt', cba:'application/x-cba',
  },
  document: {
    pdf:'application/pdf', txt:'text/plain', log:'text/plain', md:'text/markdown', markdown:'text/markdown',
    rtf:'application/rtf', csv:'text/csv', tsv:'text/tab-separated-values', json:'application/json',
    xml:'application/xml', html:'text/html', htm:'text/html', xhtml:'application/xhtml+xml',
    tex:'application/x-tex', yaml:'application/yaml', yml:'application/yaml',
    doc:'application/msword', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls:'application/vnd.ms-excel', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt:'application/vnd.ms-powerpoint', pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    odt:'application/vnd.oasis.opendocument.text', ods:'application/vnd.oasis.opendocument.spreadsheet',
    odp:'application/vnd.oasis.opendocument.presentation', pages:'application/vnd.apple.pages',
    numbers:'application/vnd.apple.numbers', key:'application/vnd.apple.keynote',
  },
};
const byExtension = Object.assign({}, types.book, types.comic, types.document);
const idPattern = /^[a-f0-9]{32}$/;
export const opdsPath = (path: string) => /^\/(opds|opdshelf)(\/|$)/.test(path);
const accountPath = /^\/api\/opds\/accounts(?:\/([a-f0-9]{32}))?$/;
export const opdsAccountPath = (path: string) => accountPath.test(path);
const sharedHeaders = {
  'Cache-Control':'private, no-store',
  'Referrer-Policy':'no-referrer',
  'X-Content-Type-Options':'nosniff',
};
const atomType = (kind: 'navigation' | 'acquisition') => 'application/atom+xml;profile=opds-catalog;kind=' + kind;
const jsonType = 'application/opds+json';
const openSearchType = 'application/opensearchdescription+xml';
const acquisition = 'http://opds-spec.org/acquisition/open-access';
const pageSize = 50;
const fallbackDate = '1970-01-01T00:00:00Z';
const esc = (value: unknown) => String(value ?? '')
  .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '')
  .replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&apos;'}[ch]!));

const dbQueries = (db: D1Database) => ({
  one: (sql: string, ...args: any[]) => db.prepare(sql).bind(...args).first<Row>(),
  all: async (sql: string, ...args: any[]) => (await db.prepare(sql).bind(...args).all<Row>()).results,
  run: (sql: string, ...args: any[]) => db.prepare(sql).bind(...args).run(),
});

export async function manageOpdsAccounts(request: Request, db: D1Database, owner: string, body: () => Promise<Row>) {
  const url = new URL(request.url);
  const id = accountPath.exec(url.pathname)?.[1];
  const {all, run} = dbQueries(db);
  const urls = {opds:url.origin + '/opds', opds2:url.origin + '/opds/v2', opdshelf:url.origin + '/opdshelf'};
  if (request.method === 'GET' && !id) {
    const accounts = await all('SELECT id,username,label,created FROM opds_accounts WHERE user_id=? ORDER BY created DESC', owner);
    return Response.json({accounts, urls}, {headers:sharedHeaders});
  }
  if (request.method === 'POST' && !id) {
    const input = await body();
    if (!input || typeof input.label !== 'string') throw new DriveError(400, 'Bitte einen Gerätenamen eingeben.');
    const account = {id:newId(), username:'opds_' + newId(), label:input.label.trim().slice(0,80) || 'Lesegerät', created:new Date().toISOString()};
    const password = newId() + newId();
    const result = await run(
      'INSERT INTO opds_accounts(id,user_id,username,label,password_hash,created) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM opds_accounts WHERE user_id=?)<50',
      account.id, owner, account.username, account.label, await webdavHash(password), account.created, owner,
    );
    if (!result.meta.changes) throw new DriveError(429, 'Maximal 50 OPDS-Zugänge pro Workspace.');
    return Response.json({...account, password, urls}, {status:201, headers:sharedHeaders});
  }
  if (request.method === 'DELETE' && id) {
    const result = await run('DELETE FROM opds_accounts WHERE id=? AND user_id=?', id, owner);
    if (!result.meta.changes) throw new DriveError(404, 'Zugang nicht gefunden.');
    return Response.json({ok:true}, {headers:sharedHeaders});
  }
  throw new DriveError(405, 'Methode nicht unterstützt.');
}

async function authenticate(request: Request, db: D1Database) {
  const basic = /^Basic ([a-zA-Z0-9+/=]{1,256})$/i.exec(request.headers.get('Authorization') || '');
  if (!basic) return null;
  let credentials: string;
  try { credentials = atob(basic[1]); } catch { return null; }
  const match = /^(opds_[a-f0-9]{32}):([a-f0-9]{64})$/.exec(credentials);
  if (!match) return null;
  const row = await dbQueries(db).one('SELECT user_id,password_hash FROM opds_accounts WHERE username=?', match[1]);
  if (!row || !/^[a-f0-9]{64}$/.test(row.password_hash)) return null;
  const encoder = new TextEncoder();
  const candidate = await webdavHash(match[2]);
  return timingSafeEqual(encoder.encode(candidate), encoder.encode(row.password_hash)) ? row.user_id as string : null;
}

function documentType(file: Row) {
  const ext = /\.([^.]+)$/.exec(file.name)?.[1].toLowerCase() || '';
  const stored = String(file.mime).split(';', 1)[0].trim().toLowerCase();
  if (ext === 'zip' && file.kind === 'comic') return types.comic.cbz;
  if (ext === 'rar' && file.kind === 'comic') return types.comic.cbr;
  if (Object.hasOwn(byExtension, ext)) return byExtension[ext];
  return /^[\w.+-]+\/[\w.+-]+$/.test(stored) ? stored : 'application/octet-stream';
}

// Recognize existing uploads with generic MIME types or older categories.
const classified = "CASE WHEN f.kind IN ('book','document','comic') THEN f.kind " +
  (Object.keys(types) as Format[]).map(kind => {
    const extensions = Object.keys(types[kind]).map(ext => "lower(f.name) GLOB '*." + ext + "'");
    const mimes = [...new Set(Object.values(types[kind]))].map(mime => "'" + mime + "'");
    return "WHEN lower(trim(substr(f.mime,1,instr(f.mime||';',';')-1))) IN (" + mimes.join(',') + ') OR ' +
      extensions.join(' OR ') + " THEN '" + kind + "' ";
  }).join('') + 'END';
const title = "COALESCE(NULLIF(json_extract(m.data,'$.title'),''),f.name)";
const author = "COALESCE(NULLIF(json_extract(m.data,'$.author'),''),NULLIF(json_extract(m.data,'$.authors[0].name'),''),CASE WHEN json_type(m.data,'$.authors[0]')='text' THEN json_extract(m.data,'$.authors[0]') END,'')";
const description = "COALESCE(NULLIF(json_extract(m.data,'$.description'),''),json_extract(m.data,'$.plot'),'')";
const publications = `WITH publications AS (
  SELECT f.*, ${classified} AS shelf_kind,${title} AS title,${author} AS author,${description} AS description,
    json_extract(m.data,'$.language') AS language, json_extract(m.data,'$.poster_source') AS poster_source,
    COALESCE(m.updated,f.created) AS modified, COALESCE(d.name,'') AS folder_name
  FROM files f LEFT JOIN file_metadata m ON m.file_id=f.id AND m.user_id=f.user_id
  LEFT JOIN folders d ON d.id=f.folder AND d.user_id=f.user_id
  WHERE f.user_id=?
)`;

function atomLink(link: Link) {
  return '<link rel="' + esc(link.rel) + '" href="' + esc(link.href) + '" type="' + esc(link.type) + '"' +
    (link.title ? ' title="' + esc(link.title) + '"' : '') +
    (link.length === undefined ? '' : ' length="' + link.length + '"') + '/>';
}

function atom(feed: Feed, self: string) {
  const updated = feed.publications?.reduce((max, item) => item.updated > max ? item.updated : max, fallbackDate) || fallbackDate;
  const navigation = feed.navigation?.map(item =>
    '<entry><id>' + esc(item.link.href) + '</id><title>' + esc(item.title) + '</title><updated>' +
    esc(updated) + '</updated>' + atomLink(item.link) + '</entry>') || [];
  const items = feed.publications?.map(item => {
    const authors = item.author ? '<author><name>' + esc(item.author) + '</name></author>' : '';
    const cover = item.cover ? atomLink(item.cover) + atomLink({...item.cover,rel:'http://opds-spec.org/image/thumbnail'}) : '';
    return '<entry><id>urn:andredrive:publication:' + esc(item.id) + '</id><title>' + esc(item.title) +
      '</title><updated>' + esc(item.updated) + '</updated>' + authors +
      (item.language ? '<dc:language>' + esc(item.language) + '</dc:language>' : '') +
      '<category term="' + esc(item.kind) + '" label="' + esc(categories[item.kind as Format]) + '"/>' +
      (item.description ? '<summary type="text">' + esc(item.description) + '</summary>' : '') +
      cover + atomLink(item.download) + '</entry>';
  }) || [];
  return '<?xml version="1.0" encoding="UTF-8"?>' +
    '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/terms/">' +
    '<id>' + esc(self) + '</id><title>' + esc(feed.title) + '</title><updated>' + updated +
    '</updated><author><name>AndreDrive</name></author>' + feed.links.map(atomLink).join('') +
    navigation.join('') + items.join('') + '</feed>';
}

function opdsJson(feed: Feed) {
  return {
    metadata:{title:feed.title, ...(feed.total === undefined ? {} : {
      numberOfItems:feed.total, itemsPerPage:pageSize, currentPage:feed.page,
    })},
    links:feed.links,
    ...(feed.navigation ? {navigation:feed.navigation.map(item => ({...item.link, title:item.title}))} : {}),
    ...(feed.publications ? {publications:feed.publications.map(item => ({
      metadata:{
        '@type':'http://schema.org/Book', title:item.title, identifier:'urn:andredrive:publication:' + item.id,
        modified:item.updated, ...(item.author ? {author:[{name:item.author}]} : {}),
        ...(item.description ? {description:item.description} : {}),
        ...(item.language ? {language:[item.language]} : {}),
        subject:[{name:categories[item.kind as Format],code:item.kind}],
      },
      links:[{href:item.download.href, type:item.download.type, rel:item.download.rel}],
      ...(item.cover ? {images:[{href:item.cover.href, type:item.cover.type}]} : {}),
    }))} : {}),
  };
}

const sorts: Record<string,string> = {
  'date-desc':'created DESC,id ASC', 'date-asc':'created ASC,id ASC',
  'name-asc':'title COLLATE NOCASE ASC,id ASC', 'name-desc':'title COLLATE NOCASE DESC,id ASC',
};
const pageNumber = (value: string | null) => value && /^[1-9]\d{0,5}$/.test(value) ? Number(value) : 1;

export async function handleOpds(request: Request, db: D1Database, services: Services) {
  if (!['GET','HEAD'].includes(request.method)) {
    return new Response(null, {status:405, headers:{...sharedHeaders, Allow:'GET, HEAD, OPTIONS'}});
  }
  const owner = await authenticate(request, db);
  if (!owner) {
    return new Response('OPDS-Zugangsdaten erforderlich.', {status:401, headers:{
      ...sharedHeaders, 'Content-Type':'text/plain; charset=utf-8',
      'WWW-Authenticate':'Basic realm="AndreDrive OPDS", charset="UTF-8"',
    }});
  }
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, '');
  const shelf = path === '/opdshelf' || path.startsWith('/opdshelf/');
  const explicitJson = path === '/opds/v2' || path.startsWith('/opds/v2/');
  const json = explicitJson || request.headers.get('Accept')?.includes(jsonType);
  const base = explicitJson ? '/opds/v2' : shelf ? '/opdshelf' : '/opds';
  const endpoint = path.slice(base.length);
  const {one, all} = dbQueries(db);
  const notFound = () => new Response(null, {status:404, headers:sharedHeaders});
  const media = /^\/(download|cover)\/([a-f0-9]{32})(?:\/[^/]+)?$/.exec(endpoint);
  if (media) {
    const file = await one(`SELECT f.* FROM files f WHERE f.user_id=? AND f.id=? AND (${classified}) IS NOT NULL`, owner, media[2]);
    if (!file) return notFound();
    if (media[1] === 'cover') return services.poster(file);
    return services.content(file, {mime:documentType(file), download:true});
  }
  const href = (suffix = '', query: Record<string,string> = {}) => {
    const target = new URL((json ? '/opds/v2' : base) + suffix, url.origin);
    for (const [key,value] of Object.entries(query)) target.searchParams.set(key,value);
    return target.href;
  };
  const mediaType = (kind: 'navigation' | 'acquisition') => json ? jsonType : atomType(kind);
  const nav = (title: string, suffix: string, kind: 'navigation' | 'acquisition', query?: Record<string,string>): Navigation =>
    ({title, link:{href:href(suffix, query), rel:'subsection', type:mediaType(kind)}});
  if (endpoint === '/opensearch.xml') {
    const template = esc(href('/search') + '?q={searchTerms}');
    const body = '<?xml version="1.0" encoding="UTF-8"?>' +
      '<OpenSearchDescription xmlns="http://a9.com/-/spec/opensearch/1.1/">' +
      '<ShortName>AndreDrive</ShortName><Description>AndreDrive durchsuchen</Description>' +
      '<Url type="' + esc(mediaType('acquisition')) + '" template="' + template + '"/>' +
      '</OpenSearchDescription>';
    return new Response(body, {headers:{...sharedHeaders, 'Content-Type':openSearchType + '; charset=utf-8'}});
  }
  const page = pageNumber(url.searchParams.get('page'));
  const offset = (page-1) * pageSize;
  const feed: Feed = {title:'AndreDrive · Lesebibliothek', links:[], page};
  let kind: 'navigation' | 'acquisition' = 'navigation';
  let hasNext = false;
  const params: Record<string,string> = {};
  let canonicalEndpoint = endpoint;

  if (!endpoint && !url.searchParams.has('sort')) {
    feed.navigation = [
      nav('Alle Dateien', '/books', 'acquisition'),
      nav('Nach Titel', '/books', 'acquisition', {sort:'name-asc'}),
      ...Object.entries(categories).map(([key,label]) => nav(label, '/category/' + key, 'acquisition')),
      nav('Ordner', '/folders', 'navigation'),
      nav('Autoren', '/authors', 'navigation'),
    ];
  } else if (endpoint === '/folders' || endpoint.startsWith('/folders/')) {
    const folderId = endpoint.slice('/folders/'.length) || null;
    if (folderId && !idPattern.test(folderId)) return notFound();
    const folder = folderId && await one('SELECT name FROM folders WHERE id=? AND user_id=?', folderId, owner);
    if (folderId && !folder) return notFound();
    feed.title = folder ? folder.name : 'Ordner';
    // Ancestors of eligible files only. UNION also prevents a cyclic tree from looping.
    const folders = await all(`WITH RECURSIVE reading_folders(id) AS (
      SELECT DISTINCT f.folder FROM files f WHERE f.user_id=? AND f.folder IS NOT NULL AND (${classified}) IS NOT NULL
      UNION
      SELECT d.parent FROM folders d JOIN reading_folders r ON d.id=r.id WHERE d.user_id=? AND d.parent IS NOT NULL
    ) SELECT d.id,d.name FROM folders d JOIN reading_folders r ON r.id=d.id
      WHERE d.user_id=? AND d.parent IS ? ORDER BY d.name COLLATE NOCASE,d.id LIMIT ? OFFSET ?`,
    owner,owner,owner,folderId,pageSize+1,offset);
    hasNext = folders.length > pageSize;
    feed.navigation = folders.slice(0,pageSize).map(item => nav(item.name, '/folders/' + item.id, 'navigation'));
    if (page === 1) {
      const direct = await one(`SELECT 1 FROM files f WHERE f.user_id=? AND f.folder IS ? AND (${classified}) IS NOT NULL LIMIT 1`, owner, folderId);
      if (direct) feed.navigation.unshift(nav('Dateien in diesem Ordner', '/books', 'acquisition', {folder:folderId || 'root'}));
    }
  } else if (endpoint === '/authors') {
    feed.title = 'Autoren';
    const rows = await all(publications + " SELECT DISTINCT author FROM publications WHERE shelf_kind IS NOT NULL AND author<>'' ORDER BY author COLLATE NOCASE,author LIMIT ? OFFSET ?",
      owner,pageSize+1,offset);
    hasNext = rows.length > pageSize;
    feed.navigation = rows.slice(0,pageSize).map(row => nav(row.author, '/author', 'acquisition', {name:row.author}));
  } else {
    const category = /^\/category\/(book|document|comic)$/.exec(endpoint)?.[1] as Format | undefined;
    if (endpoint && !['/books','/search','/author'].includes(endpoint) && !category) return notFound();
    canonicalEndpoint ||= '/books';
    kind = 'acquisition';
    const conditions = ['shelf_kind IS NOT NULL'];
    const values: (string | null)[] = [];
    if (category) {
      conditions.push('shelf_kind=?');
      values.push(category);
      feed.title = categories[category];
    }
    const folder = url.searchParams.get('folder');
    if (folder !== null) {
      if (folder !== 'root' && !idPattern.test(folder)) return notFound();
      const row = folder === 'root' ? null : await one('SELECT name FROM folders WHERE id=? AND user_id=?', folder, owner);
      if (folder !== 'root' && !row) return notFound();
      conditions.push('folder IS ?');
      values.push(folder === 'root' ? null : folder);
      params.folder = folder;
      feed.title = row?.name || 'Dateien im Hauptordner';
    }
    if (endpoint === '/author') {
      const name = (url.searchParams.get('name') || '').trim().slice(0,200);
      if (!name) return notFound();
      conditions.push('author=?');
      values.push(name);
      params.name = name;
      feed.title = name;
    }
    if (endpoint === '/search') {
      const q = (url.searchParams.get('q') || url.searchParams.get('query') || '').trim().slice(0,240);
      params[json ? 'query' : 'q'] = q;
      feed.title = q ? 'Suche · ' + q : 'Suche';
      for (const word of q.split(/\s+/).filter(Boolean).slice(0,12)) {
        conditions.push("instr(lower(title||' '||name||' '||author||' '||description||' '||folder_name),lower(?))>0");
        values.push(word);
      }
    }
    const sort = url.searchParams.get('sort') || 'date-desc';
    const order = Object.hasOwn(sorts, sort) ? sorts[sort] : sorts['date-desc'];
    if (sort !== 'date-desc' && Object.hasOwn(sorts, sort)) params.sort = sort;
    const where = ' FROM publications WHERE ' + conditions.join(' AND ');
    const [rows, total] = await Promise.all([
      all(publications + ' SELECT *' + where + ' ORDER BY ' + order + ' LIMIT ? OFFSET ?',owner,...values,pageSize,offset),
      one(publications + ' SELECT COUNT(*) AS n' + where, owner,...values),
    ]);
    feed.total = Number(total?.n || 0);
    hasNext = offset + pageSize < feed.total;
    feed.publications = rows.map(file => ({
      id:file.id, title:file.title, author:file.author, description:file.description, language:file.language || '',
      updated:file.modified || fallbackDate, kind:file.shelf_kind,
      download:{href:href('/download/' + file.id + '/' + encodeURIComponent(file.name)), rel:acquisition, type:documentType(file), length:file.size},
      ...(file.poster_source === 'upload' ? {cover:{href:href('/cover/' + file.id),rel:'http://opds-spec.org/image',type:'image/*'}} : {}),
    }));
  }

  const paginated = (p: number) => href(canonicalEndpoint, p > 1 ? {...params,page:String(p)} : params);
  const self = paginated(page);
  feed.links = [
    {rel:'self',href:self,type:mediaType(kind)},
    {rel:'start',href:href(),type:mediaType('navigation')},
    json ? {rel:'search',href:href('/search') + '{?query}',type:jsonType,templated:true} :
      {rel:'search',href:href('/opensearch.xml'),type:openSearchType},
  ];
  if (hasNext) feed.links.push({rel:'next',href:paginated(page+1),type:mediaType(kind)});
  if (page > 1) feed.links.push({rel:json ? 'previous' : 'prev',href:paginated(page-1),type:mediaType(kind)});
  return new Response(json ? JSON.stringify(opdsJson(feed)) : atom(feed,self), {headers:{
    ...sharedHeaders, 'Content-Type':mediaType(kind) + '; charset=utf-8', Vary:'Accept',
  }});
}
