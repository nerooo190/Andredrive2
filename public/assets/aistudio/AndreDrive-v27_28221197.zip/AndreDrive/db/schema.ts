import { real, uniqueIndex, integer, sqliteTable, text, primaryKey, index } from "drizzle-orm/sqlite-core";
export const folders = sqliteTable("folders",{id:text("id").primaryKey(),user_id:text("user_id").notNull(),name:text("name").notNull(),parent:text("parent"),created:text("created").notNull()},t=>[index('folders_owner').on(t.user_id)]);
export const files = sqliteTable("files",{id:text("id").primaryKey(),user_id:text("user_id").notNull(),folder:text("folder"),name:text("name").notNull(),mime:text("mime").notNull(),size:integer("size").notNull(),created:text("created").notNull(),kind:text("kind").notNull().default('movie'),series:text("series").notNull().default(''),season:integer("season").notNull().default(1),episode:integer("episode").notNull().default(1),starred:integer("starred").notNull().default(0),hls:text("hls").notNull().default('none'),object_id:text('object_id'),poster_id:text('poster_id')},t=>[index('files_owner').on(t.user_id)]);
export const links=sqliteTable("links",{token:text("token").primaryKey(),user_id:text("user_id").notNull(),type:text("type").notNull(),target:text("target").notNull(),created:text("created").notNull()},t=>[index('links_owner').on(t.user_id)]);
export const uploads=sqliteTable("uploads",{id:text("id").primaryKey(),user_id:text("user_id").notNull(),upload_id:text("upload_id").notNull(),metadata:text("metadata").notNull(),created:integer("created").notNull()},t=>[index('uploads_owner').on(t.user_id)]);
export const parts=sqliteTable("upload_parts",{upload:text("upload").notNull(),part:integer("part").notNull(),etag:text("etag").notNull(),size:integer("size").notNull()},t=>[primaryKey({columns:[t.upload,t.part]})]);
export const fileMetadata=sqliteTable('file_metadata',{file_id:text('file_id').primaryKey(),user_id:text('user_id').notNull(),data:text('data').notNull().default('{}'),updated:text('updated').notNull()},t=>[index('metadata_owner').on(t.user_id)]);
export const metadataSettings=sqliteTable('metadata_settings',{user_id:text('user_id').primaryKey(),tmdb_token:text('tmdb_token').notNull(),updated:text('updated').notNull()});

export const iptvStreams=sqliteTable("iptv_streams",{id:integer("id").primaryKey({autoIncrement:true}),file_id:text("file_id").notNull().unique(),hls:integer("hls"),duration:real("duration").notNull().default(0)});
export const iptvSeries=sqliteTable("iptv_series",{id:integer("id").primaryKey({autoIncrement:true}),user_id:text("user_id").notNull(),series_key:text("series_key").notNull()},t=>[uniqueIndex("iptv_series_owner_key").on(t.user_id,t.series_key)]);

export const webdavAccounts=sqliteTable("webdav_accounts",{id:text("id").primaryKey(),user_id:text("user_id").notNull(),label:text("label").notNull(),username:text("username").notNull().unique(),password_hash:text("password_hash").notNull(),can_write:integer("can_write").notNull().default(0),created:text("created").notNull()},t=>[index("webdav_owner").on(t.user_id)]);

export const categories=sqliteTable("categories",{id:text("id").primaryKey(),user_id:text("user_id").notNull(),name:text("name").notNull(),name_key:text("name_key").notNull(),created:text("created").notNull()},t=>[uniqueIndex("categories_owner_name").on(t.user_id,t.name_key)]);
export const trashFiles=sqliteTable('trash_files',{id:text('id').primaryKey(),user_id:text('user_id').notNull(),object_id:text('object_id').notNull(),poster_id:text('poster_id').notNull(),data:text('data').notNull(),metadata:text('metadata').notNull(),deleted:text('deleted').notNull()},t=>[index('trash_owner').on(t.user_id)]);
export const jellyAccounts=sqliteTable('jelly_accounts',{id:text('id').primaryKey(),user_id:text('user_id').notNull(),label:text('label').notNull(),username:text('username').notNull().unique(),password_hash:text('password_hash').notNull(),created:text('created').notNull()},t=>[index('jelly_owner').on(t.user_id)]);
export const jellySessions=sqliteTable('jelly_sessions',{token_hash:text('token_hash').primaryKey(),account_id:text('account_id').notNull(),created:text('created').notNull()},t=>[index('jelly_session_account').on(t.account_id)]);
export const jellyState=sqliteTable('jelly_state',{user_id:text('user_id').notNull(),item_id:text('item_id').notNull(),position:real('position').notNull().default(0),played:integer('played').notNull().default(0),play_count:integer('play_count').notNull().default(0),favorite:integer('favorite').notNull().default(0),updated:text('updated').notNull()},t=>[primaryKey({columns:[t.user_id,t.item_id]})]);

export const cloudConnections=sqliteTable('cloud_connections',{id:text('id').primaryKey(),user_id:text('user_id').notNull(),provider:text('provider').notNull(),label:text('label').notNull(),credentials:text('credentials').notNull(),created:text('created').notNull()},t=>[index('cloud_connection_owner').on(t.user_id)]);
export const cloudAuth=sqliteTable('cloud_auth',{id:text('id').primaryKey(),user_id:text('user_id').notNull(),credentials:text('credentials').notNull(),expires:integer('expires').notNull(),next_poll:integer('next_poll').notNull(),interval:integer('interval').notNull()},t=>[index('cloud_auth_owner').on(t.user_id)]);
export const cloudFiles=sqliteTable('cloud_files',{object_id:text('object_id').primaryKey(),user_id:text('user_id').notNull(),connection_id:text('connection_id').notNull(),remote_key:text('remote_key').notNull(),data:text('data').notNull(),download_cache:text('download_cache'),cache_expires:integer('cache_expires').notNull().default(0)},t=>[index('cloud_file_owner').on(t.user_id),index('cloud_file_connection').on(t.connection_id)]);
export const cloudTransfers=sqliteTable('cloud_transfers',{id:text('id').primaryKey(),user_id:text('user_id').notNull(),connection_id:text('connection_id').notNull(),operation:text('operation').notNull(),status:text('status').notNull(),data:text('data').notNull(),upload_id:text('upload_id').notNull(),chunk_bytes:integer('chunk_bytes').notNull(),created:text('created').notNull(),updated:text('updated').notNull(),lease_until:integer('lease_until').notNull().default(0),lease_token:text('lease_token').notNull().default(''),error:text('error').notNull().default('')},t=>[index('cloud_transfer_owner').on(t.user_id)]);
export const cloudTransferParts=sqliteTable('cloud_transfer_parts',{transfer_id:text('transfer_id').notNull(),part:integer('part').notNull(),etag:text('etag').notNull(),size:integer('size').notNull(),sha256:text('sha256').notNull(),verified:integer('verified').notNull().default(0)},t=>[primaryKey({columns:[t.transfer_id,t.part]})]);

export const subsonicAccounts = sqliteTable('subsonic_accounts', {
  id: text('id').primaryKey(),
  user_id: text('user_id').notNull(),
  username: text('username').notNull().unique(),
  label: text('label').notNull(),
  secret: text('secret').notNull(),
  created: text('created').notNull(),
}, t => [index('subsonic_account_owner').on(t.user_id)]);

export const subsonicPlaylists = sqliteTable('subsonic_playlists', {
  id: text('id').primaryKey(),
  user_id: text('user_id').notNull(),
  name: text('name').notNull(),
  comment: text('comment').notNull().default(''),
  tracks: text('tracks').notNull(),
  created: text('created').notNull(),
  changed: text('changed').notNull(),
  revision: integer('revision').notNull().default(0),
}, t => [index('subsonic_playlist_owner').on(t.user_id)]);

export const opdsAccounts = sqliteTable('opds_accounts', {
  id: text('id').primaryKey(),
  user_id: text('user_id').notNull(),
  username: text('username').notNull().unique(),
  label: text('label').notNull(),
  password_hash: text('password_hash').notNull(),
  created: text('created').notNull(),
}, t => [index('opds_account_owner').on(t.user_id)]);

export const absAccounts = sqliteTable('abs_accounts', {
  id: text('id').primaryKey(),
  user_id: text('user_id').notNull(),
  username: text('username').notNull().unique(),
  label: text('label').notNull(),
  password_hash: text('password_hash').notNull(),
  created: integer('created').notNull(),
}, t => [index('abs_account_owner').on(t.user_id)]);

export const absSessions = sqliteTable('abs_sessions', {
  id: text('id').primaryKey(),
  account_id: text('account_id').notNull(),
  access_hash: text('access_hash').notNull().unique(),
  refresh_hash: text('refresh_hash').notNull().unique(),
  expires: integer('expires').notNull(),
  refresh_expires: integer('refresh_expires').notNull(),
}, t => [index('abs_session_account').on(t.account_id)]);

export const absProgress = sqliteTable('abs_progress', {
  user_id: text('user_id').notNull(),
  item_id: text('item_id').notNull(),
  current_time: real('current_time').notNull(),
  duration: real('duration').notNull(),
  finished: integer('finished').notNull(),
  started: integer('started').notNull(),
  updated: integer('updated').notNull(),
}, t => [primaryKey({columns:[t.user_id,t.item_id]})]);

export const absPlayback = sqliteTable('abs_playback', {
  id: text('id').primaryKey(),
  account_id: text('account_id').notNull(),
  item_id: text('item_id').notNull(),
  duration: real('duration').notNull(),
  expires: integer('expires').notNull(),
}, t => [index('abs_playback_account').on(t.account_id)]);

export const absAudio = sqliteTable('abs_audio', {
  user_id: text('user_id').notNull(),
  object_id: text('object_id').notNull(),
  size: integer('size').notNull(),
  duration: real('duration').notNull(),
}, t => [primaryKey({columns:[t.user_id,t.object_id]})]);

export const rommSettings=sqliteTable('romm_settings',{
 user_id:text('user_id').primaryKey(),
 server_url:text('server_url').notNull(),
 folder_id:text('folder_id').notNull(),
 username:text('username').unique(),
 password_hash:text('password_hash'),
});
