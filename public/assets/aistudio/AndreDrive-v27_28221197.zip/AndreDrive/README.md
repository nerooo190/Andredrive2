# AndreDrive on ChatGPT Sites

The original AndreDrive interface is hosted together with its backend. No external backend URL, server account, Supabase, Render, or local disk is required.

- Same-origin backend: `/api`; status: `/api/health`.
- Sites-managed D1 stores folders, file metadata, upload state, and revocable link records.
- Sites-managed R2 stores uploaded originals durably across sessions and deployments.
- ChatGPT sign-in supplies the stable owner ID; every data operation checks ownership.
- The Site is public. Library browsing, uploads, metadata changes and link administration require ChatGPT sign-in and check record ownership. Explicitly created token links expose only their selected files, recursive folder contents or playlist to anonymous GET/HEAD requests. Revocation immediately invalidates the link. Media supports CORS for browser-based external players.
- Files upload sequentially in 16 MiB chunks, up to 100 GB (100,000,000,000 bytes) per file. No browser-local file persistence or external server is used. Hosting capacity remains subject to platform availability and limits.
- Original videos support byte ranges for seeking. Compatible fragmented MP4s receive a persistent HLS index, a separate init segment and rebased media fragments; playlists contain an actual duration and select these streams automatically. Browser playback depends on the file's codecs. FFmpeg conversion is unavailable in this runtime. Fragmented MP4s with an embedded random-access footer are packaged as seekable HLS without transcoding.
- ZIP downloads stream without loading the whole selection into memory; at most 100 files and 1 GiB per selection. Larger files can be downloaded individually.
- M3U playlists preserve series, season, and episode metadata. Link records have no automatic expiration and can be revoked; this does not guarantee permanent platform hosting.
- Unfinished uploads can be canceled. Abandoned multipart uploads inactive for more than 24 hours are cleaned up when a new upload starts.

`db/schema.ts` owns the schema; generated SQL and metadata under `drizzle/` ship with deployments. Do not create tables during requests.

Verification: `node scripts/storage.test.mjs` tests real local D1 and R2 through Miniflare, including ownership isolation, multi-chunk files, ranges, ZIP archives, playlists, revocation, zero-byte files and cancellation. `node node_modules/typescript/bin/tsc --noEmit` checks TypeScript. Use the Sites build and publishing helpers for deployment.

Media responses now bypass the UI framework in the production Worker. R2 streams pass through Workers FixedLengthStream so the runtime retains Content-Length for full and partial responses. Content-Range, HEAD, If-Range, MIME fallback and filenames are preserved for browser and M3U clients. The player detects indexed fragmented MP4s and plays them through native HLS or hls.js, with buffering state and ten-second seek controls. The authenticated or token-authorized media URL with `?info=1` returns a bounded MP4 structural probe (top-level atoms, codecs and duration); it never buffers the whole uploaded movie.

The storage regression suite runs the backend inside the actual workerd/Miniflare runtime, including FixedLengthStream response-header behavior, rather than only calling handlers in Node.


## Catalog metadata and large uploads

New uploads support 100 GB decimal per file, using 16 MiB parts (at most 5,961 parts at this limit). Existing 8 MiB upload sessions remain resumable. The client retries transient errors and remembers multipart progress identifiers locally; D1 stores the authoritative completed part list. Pause and resume by selecting the same unchanged file again. Uploaded bytes are not stored in browser storage.

The metadata editor supports movies, series, season zero specials, episode titles, JSON and Kodi-style NFO imports, custom raster covers up to 10 MiB, manual fields and TMDB search/details. Metadata is persisted separately in file_metadata and merged only into authorized file listings and shares. Public poster routes authorize against the original revocable share token. M3U entries include tvg-name, tvg-logo, group-title, TVG/TMDB/IMDb IDs, year, genre, plot, rating, cast, director, language and episode information; individual player support for extended fields varies.

Each user can configure a personal TMDB API Read Access Token or v3 API key under Settings. Tokens are validated with TMDB and encrypted with AES-GCM and user-specific additional authenticated data before being saved. METADATA_SETTINGS_KEY is a server-only Sites secret. An optional site-wide TMDB_API_READ_ACCESS_TOKEN environment secret is also supported. Neither secret is embedded in browser bundles or playlist files. TMDB has not been live-tested without a user credential; provider integration is covered by deterministic workerd fixtures. TMDB attribution and the approved logo are included in the settings/editor.

Regression commands: node scripts/storage.test.mjs and node scripts/upload-client.test.mjs. A 100 GB transfer has not been physically uploaded in QA; tests verify boundary acceptance, chunk sizing, legacy sessions, resumability and the real multipart protocol with smaller binary fixtures.


### OneDrive and TorBox sources

Cloud-Quellen connects existing provider files as references without copying their bytes to R2. TorBox supports existing completed torrents, Usenet and web downloads through the official API. OneDrive uses Microsoft Graph with a public-client device authorization flow and delegated Files.Read/offline_access. Configure an optional ONEDRIVE_CLIENT_ID server variable, or enter a public-client app ID in the UI. The app registration must allow public client flows and the intended personal/work account types; no client secret is used. Microsoft consent and provider account policies still apply.

Credentials, device codes and short-lived download URL caches use the existing METADATA_SETTINGS_KEY with AES-GCM and owner/source-specific authenticated data. The server refreshes OneDrive tokens and provider download URLs, validates provider CDN hosts, forwards byte ranges without forwarding credentials, and streams the file through the existing media/WebDAV/Jellyfin handlers. Only small MP4 index metadata is cached in R2. Removing, copying or moving a reference changes AndreDrive only. Disconnecting invalidates its playback while leaving source files intact. Existing source references may need to be removed and re-added if the provider file changes or credentials must be replaced.

Integration coverage uses real workerd/D1/R2 and deterministic provider fixtures, including byte ranges, remote fragmented MP4/HLS, WebDAV, M3U, Jellyfin, encrypted storage, token/link refresh, ownership, copying and trash restoration. Live personal OneDrive/TorBox account access has not been tested without user credentials.


### Physical cloud copies and moves

Cloud-Quellen now defaults to copying into AndreDrive, with a separate move option and the original reference option. Durable cloud_transfers/cloud_transfer_parts jobs copy 16 MiB ranges directly from the provider into an R2 multipart upload. crypto.DigestStream calculates SHA-256 with backpressure, without buffering a video or whole part. Every completed part is read back and checked before the destination is published. Jobs retain multipart progress across pauses; keep the browser tab open to drive progress, or resume from Cloud-Quellen. Two files are processed concurrently. The existing 100 GB per-file limit applies.

Moving requires explicit source-removal consent in the UI. OneDrive connections can be upgraded in place to Files.ReadWrite with a new Microsoft device-code consent flow. Deletion uses a fresh source version and If-Match and sends files to OneDrive's recycle bin. TorBox only supports whole-download removal, so all files from a download must be selected, copied and verified; only that exact download is deleted. Incomplete groups, changed sources, checksum failures, missing local destinations and failed provider deletion leave the source intact. Source removal uses a separate phase and a shared group lease. Users can keep a verified copy and preserve its source. Local copies remain playable after disconnecting the provider.
