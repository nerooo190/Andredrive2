'use client';
import {useEffect,useRef,useState} from 'react';
import {Search} from 'lucide-react';
import {tmdbScrapeInput} from '../lib/catalog-metadata';
import {api} from './api-client';

const batchSize=48;
const groupKey=({file,input})=>JSON.stringify([file.kind,input.id||input.key,input.id?'':input.year]);

export default function TmdbScraper({files,configured,refresh}){
 const [progress,setProgress]=useState(null),[running,setRunning]=useState(false);
 const [message,setMessage]=useState(''),[issues,setIssues]=useState([]);
 const stop=useRef(false);
 useEffect(()=>{stop.current=false;return()=>{stop.current=true}},[]);
 const eligible=files.filter(file=>file.kind==='movie'||file.kind==='series');

 async function scan(){
  const files=eligible.map(file=>({file,input:tmdbScrapeInput(file)}));
  files.sort((a,b)=>groupKey(a).localeCompare(groupKey(b))||a.input.season-b.input.season);
  const totals={checked:0,updated:0,skipped:0,error:0,unchanged:0,total:files.length};
  const notes=[];
  stop.current=false;
  setRunning(true);
  setProgress(totals);
  setMessage('');
  setIssues([]);
  try{
   for(let start=0;start<files.length&&!stop.current;){
    let end=Math.min(start+batchSize,files.length);
    if(end<files.length){
     const nextGroup=groupKey(files[end]);
     let boundary=end;
     while(boundary>start&&groupKey(files[boundary-1])===nextGroup)boundary--;
     if(boundary>start)end=boundary;
    }
    const batch=files.slice(start,end).map(({file})=>file);
    start=end;
    const names=new Map(batch.map(file=>[file.id,file.name]));
    const result=await api('/api/tmdb/scrape',{method:'POST',body:JSON.stringify({ids:batch.map(file=>file.id)})});
    for(const item of result.results){
     totals.checked++;
     totals[item.status]++;
     if(item.message&&notes.length<30)notes.push({id:item.id,name:names.get(item.id),message:item.message});
    }
    setProgress({...totals});
    setIssues([...notes]);
    if(result.stopStatus){
     setMessage(result.stopStatus===429?'TMDB hat den Abruf begrenzt. Versuche es später erneut.':'Prüfe deinen TMDB-Schlüssel und starte den Abruf erneut.');
     break;
    }
   }
   if(stop.current)setMessage('Sammelabruf nach dem letzten Stapel gestoppt.');
  }catch(e){setMessage(e.message)}
  finally{
   setRunning(false);
   if(totals.checked)await refresh?.().catch(()=>{});
  }
 }

 return <section className="metadata-tmdb">
  <h3>TMDB-Sammelabruf</h3>
  <p>Ergänzt fehlende Metadaten für {eligible.length} Filme und Serienepisoden, einschließlich TMDB-Episodenbildern. Vorhandene Angaben und eigene Cover bleiben erhalten.</p>
  <button type="button" className="secondary full" disabled={!configured||!eligible.length||running} onClick={scan}><Search size={16}/>Alle Filme und Serien abrufen</button>
  {running&&<button type="button" className="text-button" onClick={()=>{stop.current=true;setMessage('Der aktuelle Stapel wird noch abgeschlossen.')}}>Nach diesem Stapel stoppen</button>}
  {progress&&<div role="status">
   <progress max={progress.total} value={progress.checked} aria-label="TMDB-Abruffortschritt"/>
   <p>{progress.checked} / {progress.total} geprüft · {progress.updated} ergänzt · {progress.unchanged} bereits vorhanden · {progress.skipped} übersprungen · {progress.error} Fehler</p>
  </div>}
  {message&&<p className="hint" role="status">{message}</p>}
  {issues.length>0&&<details>
   <summary>Übersprungene Dateien und Fehler anzeigen</summary>
   <ul className="tmdb-scrape-issues">{issues.map(item=><li key={item.id}><b>{item.name}</b> · {item.message}</li>)}</ul>
  </details>}
 </section>;
}
