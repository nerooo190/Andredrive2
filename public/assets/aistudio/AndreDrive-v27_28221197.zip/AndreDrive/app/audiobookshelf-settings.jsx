'use client';

import {useEffect, useState} from 'react';
import {Copy, Eye, EyeOff, Headphones, LoaderCircle} from 'lucide-react';
import {api} from './api-client';

const endpoint = '/api/audiobookshelf/accounts';

export default function AudiobookshelfSettings({notify}) {
  const [accounts, setAccounts] = useState([]);
  const [serverUrl, setServerUrl] = useState('');
  const [created, setCreated] = useState(null);
  const [visible, setVisible] = useState(false);
  const [label, setLabel] = useState('Mein Hörbuchplayer');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function load() {
    const data = await api(endpoint);
    setServerUrl(data.serverUrl);
    setAccounts(data.accounts);
  }

  useEffect(() => { load().catch(e => setError(e.message)); }, []);

  async function action(task) {
    setBusy(true);
    setError('');
    try { await task(); } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  const fields = [
    {name:'Audiobookshelf-Server-URL', value:serverUrl},
    ...(created ? [
      {name:'Audiobookshelf-Benutzername', value:created.username},
      {name:'Audiobookshelf-Passwort', value:created.password, secret:true},
    ] : []),
  ];

  return <section className="webdav-settings">
    <div className="vod-access-heading"><Headphones size={20}/><h3>Audiobookshelf</h3></div>
    <p>Hörbücher aus AndreDrive in der Audiobookshelf-App hören. Deine Hörposition wird über die Geräte deines Workspace hinweg gespeichert.</p>
    {fields.map(({name,value,secret}) => <label key={name}>
      {name}
      <div className="copy-field">
        <input aria-label={name} type={secret && !visible ? 'password' : 'text'} readOnly value={value} onFocus={e => e.target.select()}/>
        {secret && <button type="button" aria-label="Audiobookshelf-Passwort anzeigen oder verbergen" aria-pressed={visible} onClick={() => setVisible(!visible)}>
          {visible ? <EyeOff size={16}/> : <Eye size={16}/>}
        </button>}
        <button type="button" aria-label={name + ' kopieren'} disabled={!value} onClick={async () => {
          try { await navigator.clipboard.writeText(value); notify(name + ' kopiert.'); }
          catch { setError('Bitte den Wert markieren und kopieren.'); }
        }}><Copy size={16}/></button>
      </div>
    </label>)}
    {created && <p className="hint">Speichere das Passwort vor dem Schließen. Es wird einmalig angezeigt.</p>}
    <label>Gerätename<input value={label} maxLength={80} onChange={e => setLabel(e.target.value)}/></label>
    <button type="button" className="secondary full" disabled={busy} onClick={() => action(async () => {
      const fresh = await api(endpoint, {method:'POST', body:JSON.stringify({label})});
      setCreated(fresh);
      setVisible(false);
      await load();
      notify('Audiobookshelf-Gerätezugang erstellt.');
    })}>{busy ? <LoaderCircle className="spin" size={16}/> : <Headphones size={16}/>}Audiobookshelf-Gerätezugang erstellen</button>
    {accounts.map(account => <div className="webdav-account" key={account.id}>
      <div><b>{account.label}</b><small>AndreDrive Hörbücher</small><code>{account.username}</code></div>
      <button type="button" className="text-button danger" disabled={busy} onClick={() => action(async () => {
        await api(endpoint + '/' + account.id, {method:'DELETE'});
        if (created?.id === account.id) setCreated(null);
        await load();
        notify('Audiobookshelf-Gerätezugang widerrufen.');
      })}>Widerrufen</button>
    </div>)}
    <details className="webdav-guide">
      <summary>Mit einer App verbinden</summary>
      <p>In der Audiobookshelf-App einen Server hinzufügen und die vollständige Server-URL, den Benutzernamen und das Gerätepasswort von oben eintragen.</p>
      <p>Die Bibliothek enthält Audiodateien der Kategorie Hörbücher sowie M4B-Dateien. Nummerierte Audio-Tracks im selben Ordner erscheinen gemeinsam. Die App spielt das Originalformat ab.</p>
    </details>
    {error && <p className="error" role="alert">{error}</p>}
  </section>;
}
