'use client';

import {useEffect, useState} from 'react';
import {BookOpen, Copy, Eye, EyeOff, LoaderCircle} from 'lucide-react';
import {api} from './api-client';

const endpoint = '/api/opds/accounts';

export default function OpdsSettings({notify}) {
  const [data, setData] = useState(null);
  const [fresh, setFresh] = useState(null);
  const [visible, setVisible] = useState(false);
  const [label, setLabel] = useState('Mein Lesegerät');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function reload() { setData(await api(endpoint)); }
  useEffect(() => { reload().catch(cause => setError(cause.message)); }, []);

  async function action(task) {
    setBusy(true);
    setError('');
    try { await task(); }
    catch (cause) { setError(cause.message); }
    finally { setBusy(false); }
  }

  const fields = [
    {name:'OPDS 1.2 · Katalog-URL', value:data?.urls.opds || ''},
    {name:'OPDS 2.0 · Katalog-URL', value:data?.urls.opds2 || ''},
    {name:'OPDShelf-kompatible URL', value:data?.urls.opdshelf || ''},
    ...(fresh ? [
      {name:'OPDS-Benutzername', value:fresh.username},
      {name:'OPDS-Passwort', value:fresh.password, secret:true},
    ] : []),
  ];

  return <section className="webdav-settings">
    <div className="vod-access-heading"><BookOpen size={20}/><h3>OPDS / OPDShelf</h3></div>
    <p>Bücher, Dokumente und Comics auf einem Lesegerät durchsuchen und herunterladen. Für die meisten Reader genügt die OPDS-1.2-Adresse.</p>
    {fields.map(({name,value,secret}) => <label key={name}>
      {name}
      <div className="copy-field">
        <input aria-label={name} type={secret && !visible ? 'password' : 'text'} readOnly value={value} onFocus={e => e.target.select()}/>
        {secret && <button type="button" aria-label="OPDS-Passwort anzeigen oder verbergen" aria-pressed={visible} onClick={() => setVisible(!visible)}>
          {visible ? <EyeOff size={16}/> : <Eye size={16}/>}
        </button>}
        <button type="button" aria-label={name + ' kopieren'} disabled={!value} onClick={async () => {
          try { await navigator.clipboard.writeText(value); notify(name + ' kopiert.'); }
          catch { setError('Bitte den Wert markieren und kopieren.'); }
        }}><Copy size={16}/></button>
      </div>
    </label>)}
    {fresh && <p className="hint">Das Passwort wird einmalig angezeigt. Speichere es vor dem Schließen.</p>}
    <label>Gerätename<input maxLength={80} value={label} onChange={e => setLabel(e.target.value)}/></label>
    <button type="button" className="secondary full" disabled={busy || !data} onClick={() => action(async () => {
      const account = await api(endpoint, {method:'POST', body:JSON.stringify({label})});
      setFresh(account);
      setVisible(false);
      await reload();
      notify('OPDS-Gerätezugang erstellt.');
    })}>{busy ? <LoaderCircle className="spin" size={16}/> : <BookOpen size={16}/>}OPDS-Gerätezugang erstellen</button>
    {data?.accounts.map(account => <div className="webdav-account" key={account.id}>
      <div><b>{account.label}</b><small>Lesebibliothek · Download</small><code>{account.username}</code></div>
      <button type="button" className="text-button danger" disabled={busy} onClick={() => action(async () => {
        await api(endpoint + '/' + account.id, {method:'DELETE'});
        if (fresh?.id === account.id) setFresh(null);
        await reload();
        notify('OPDS-Zugang widerrufen.');
      })}>Widerrufen</button>
    </div>)}
    <details className="webdav-guide">
      <summary>Reader, Calibre und OPDShelf verbinden</summary>
      <p>In deinem Reader „OPDS-Katalog hinzufügen“ wählen. Katalog-URL und Gerätezugang eintragen. Die App entscheidet, welche Originalformate sie öffnen kann.</p>
      <p>Calibre Desktop kann externe Kataloge mit dem OPDS-Reader-Plugin abrufen. Für Calibre-Web fügst du die heruntergeladenen Dateien der zugehörigen Calibre-Bibliothek hinzu.</p>
      <p>Für eine eigene OPDShelf-Installation kannst du die Dateien über den separaten WebDAV-Zugang auf den Server kopieren und den Zielordner als <code>BOOKS_DIR</code> verwenden.</p>
    </details>
    {error && <p className="error" role="alert">{error}</p>}
  </section>;
}
