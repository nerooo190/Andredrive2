import {api} from './api-client.js';
import {createUploadPool,DEFAULT_UPLOAD_TRANSFERS} from './upload-scheduler.js';
const abort=()=>new DOMException('Upload pausiert','AbortError');
async function retry(fn,signal){for(let attempt=0;;attempt++){if(signal.aborted)throw abort();try{return await fn()}catch(e){if(signal.aborted)throw abort();if(attempt>=3||e.status&&e.status<500&&![408,429].includes(e.status))throw e;await new Promise((resolve,reject)=>{const cancel=()=>{clearTimeout(timer);reject(abort())};const timer=setTimeout(()=>{signal.removeEventListener('abort',cancel);resolve()},500*3**attempt);signal.addEventListener('abort',cancel,{once:true})})}}}
async function fingerprint(file,metadata){const raw=new TextEncoder().encode(file.name+'|'+file.size+'|'+file.lastModified+'|'+JSON.stringify(metadata));if(crypto.subtle){const first=new Uint8Array(await file.slice(0,1024**2).arrayBuffer()),last=new Uint8Array(await file.slice(Math.max(0,file.size-1024**2)).arrayBuffer()),data=new Uint8Array(raw.length+first.length+last.length);data.set(raw);data.set(first,raw.length);data.set(last,raw.length+first.length);return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),n=>n.toString(16).padStart(2,'0')).join('')}return encodeURIComponent(file.name)+'-'+file.size+'-'+file.lastModified}
function stored(key){try{return localStorage.getItem(key)}catch{return null}}
function remember(key,value){try{value?localStorage.setItem(key,value):localStorage.removeItem(key)}catch{}}
function putPart(url,blob,signal,progress){
 if(typeof XMLHttpRequest==='undefined')return api(url,{method:'PUT',body:blob,headers:{'Content-Type':'application/octet-stream'},signal});
 return new Promise((resolve,reject)=>{
  if(signal.aborted){reject(abort());return}const xhr=new XMLHttpRequest();const cancel=()=>xhr.abort(),cleanup=()=>signal.removeEventListener('abort',cancel);
  xhr.open('PUT',url);xhr.setRequestHeader('Content-Type','application/octet-stream');
  xhr.upload.onprogress=e=>progress(Math.min(blob.size,e.loaded));
  xhr.onload=()=>{cleanup();let data;try{data=JSON.parse(xhr.responseText)}catch{}if(xhr.status>=200&&xhr.status<300&&data){resolve(data);return}const error=new Error(data?.error||'Upload fehlgeschlagen (HTTP '+xhr.status+').');error.status=xhr.status;reject(error)};
  xhr.onerror=()=>{cleanup();reject(new Error('Die Upload-Verbindung wurde unterbrochen.'))};xhr.onabort=()=>{cleanup();reject(abort())};
  signal.addEventListener('abort',cancel,{once:true});xhr.send(blob);
 });
}
export async function uploadFile(file,metadata,{signal,onProgress=()=>{},concurrency=DEFAULT_UPLOAD_TRANSFERS,pool=createUploadPool(concurrency)}){
 if(signal.aborted)throw abort();
 const cacheKey='andredrive-upload-v2:'+await fingerprint(file,metadata);let id=stored(cacheKey),session;
 if(id){try{session=await api('/api/uploads/'+id,{signal});if(session.completed){remember(cacheKey,null);onProgress(file.size);return session.file}}catch(e){if(signal.aborted)throw abort();if(e.status!==404)throw e;remember(cacheKey,null);id=null}}
 if(!session){session=await retry(()=>api('/api/uploads',{method:'POST',body:JSON.stringify({...metadata,name:file.name,mime:file.type||'application/octet-stream',size:file.size}),signal}),signal);id=session.id;remember(cacheKey,id)}
 const chunk=session.chunkBytes;if(!Number.isSafeInteger(chunk)||chunk<1)throw Error('Ungültige Upload-Abschnittsgröße.');
 const count=Math.ceil(file.size/chunk),done=new Set(session.parts||[]),inflight=new Map();let confirmed=0,reported=0,next=1,error;
 const sizeOf=n=>Math.min(chunk,file.size-(n-1)*chunk);
 for(const n of done)if(n>=1&&n<=count)confirmed+=sizeOf(n);
 // Resumed bytes belong in progress, but are excluded from the speed display in the form.
 const report=()=>{reported=Math.max(reported,Math.min(file.size,confirmed+[...inflight.values()].reduce((a,b)=>a+b,0)));onProgress(reported)};report();
 const controller=new AbortController(),cancel=()=>controller.abort();signal.addEventListener('abort',cancel,{once:true});if(signal.aborted)controller.abort();
 async function worker(){for(;;){if(controller.signal.aborted)return;let part=next++;while(part<=count&&done.has(part))part=next++;if(part>count)return;const blob=file.slice((part-1)*chunk,part*chunk);try{await retry(()=>{inflight.set(part,0);return pool.run(blob.size,controller.signal,()=>putPart('/api/uploads/'+id+'/parts/'+part,blob,controller.signal,n=>{inflight.set(part,n);report()}))},controller.signal);inflight.delete(part);done.add(part);confirmed+=blob.size;report()}catch(e){if(!error)error=e;controller.abort();return}}}
 try{const workers=Math.max(1,Math.min(pool.target,count||1));await Promise.all(Array.from({length:workers},worker));if(signal.aborted)throw abort();if(error)throw error;
  const result=await retry(()=>api('/api/uploads/'+id+(file.size?'/complete':'/empty'),{method:'POST',signal}),signal);remember(cacheKey,null);onProgress(file.size);return result;
 }finally{signal.removeEventListener('abort',cancel);controller.abort()}
}
