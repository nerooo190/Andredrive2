'use client';
import {useEffect,useRef,useState} from 'react';
import {checkRomm,connectRomm,copyRom,rommHome} from './romm-client';

export default function RommDirect({serverUrl,files,folders,folderId,notify}){
 const [connection,setConnection]=useState(null),[useToken,setUseToken]=useState(false);
 const [platform,setPlatform]=useState(''),[selected,setSelected]=useState(new Set()),[query,setQuery]=useState('');
 const [error,setError]=useState(''),[status,setStatus]=useState(''),[progress,setProgress]=useState(null),[busy,setBusy]=useState(false);
 const operation=useRef(null);
 const setup=useRef(null);
 const home=rommHome(serverUrl);
 const origin=globalThis.location?.origin||'https://andredrive-cloud.andreee1410.chatgpt.site';
 const usernameInput=useRef(null),secretInput=useRef(null);
 useEffect(()=>()=>operation.current?.abort(),[]);

 const gameFolders=new Set(folderId?[folderId]:[]);
 const children=new Map();
 for(const folder of folders){
  if(!children.has(folder.parent))children.set(folder.parent,[]);
  children.get(folder.parent).push(folder.id);
 }
 for(const parent of gameFolders)for(const child of children.get(parent)||[])gameFolders.add(child);
 const candidates=files.filter(f=>f.size>0&&(f.kind==='game'||gameFolders.has(f.folder)));
 const search=query.trim().toLocaleLowerCase('de');
 const visible=candidates.filter(f=>f.name.toLocaleLowerCase('de').includes(search));
 const queue=candidates.filter(f=>selected.has(f.id));

 async function run(work){
  if(operation.current)return;
  const controller=new AbortController();
  operation.current=controller;
  setBusy(true);
  setError('');
  setStatus('Verbindung wird vorbereitet …');
  try{await work(controller.signal)}
  catch(e){
   if(controller.signal.aborted)setStatus('Vorgang abgebrochen. Prüfe in RomM, ob die letzte Datei bereits angekommen ist.');
   else{setError(e.message);setStatus('');if(setup.current)setup.current.open=true}
  }finally{
   operation.current=null;
   setBusy(false);
   setProgress(null);
  }
 }
 function changeSelection(ids,checked){
  setSelected(previous=>{
   const next=new Set(previous);
   for(const id of ids){if(checked)next.add(id);else next.delete(id)}
   return next;
  });
 }

 return <div className="webdav-guide">
  <h4>Direkt mit RomM verbinden</h4>
  <p>Wähle ROMs in AndreDrive aus und kopiere sie über die RomM-API in eine Plattform deiner RomM-Bibliothek. Für diesen Weg braucht RomM einen beschreibbaren Bibliotheksordner.</p>
  {!connection&&<p>
   {home&&<a href={home} target="_blank" rel="noopener noreferrer">RomM im Browser öffnen</a>}
   {' '}<button className="text-button" type="button" disabled={busy} onClick={()=>run(async signal=>setStatus(await checkRomm(serverUrl,signal)))}>Verbindung prüfen</button>
  </p>}
  {!connection?<form onSubmit={e=>{
   e.preventDefault();
   const secret=secretInput.current.value;
   const credentials=useToken?{token:secret.trim()}:{
    username:usernameInput.current.value.trim(),password:secret,
   };
   secretInput.current.value='';
   run(async signal=>{
    const next=await connectRomm(serverUrl,credentials,signal);
    setConnection(next);
    setStatus('');
    notify('Mit RomM verbunden.');
   });
  }}>
   <label>Anmeldemethode
    <select value={useToken?'token':'password'} disabled={busy} onChange={e=>setUseToken(e.target.value==='token')}>
     <option value="password">RomM-Benutzername und Passwort</option>
     <option value="token">RomM-Client-API-Token</option>
    </select>
   </label>
   {useToken?<label>RomM-API-Token<input ref={secretInput} type="password" autoComplete="off" required maxLength={256} disabled={busy}/></label>:<>
    <label>RomM-Benutzername<input ref={usernameInput} required autoComplete="off" maxLength={256} disabled={busy}/></label>
    <label>RomM-Passwort<input ref={secretInput} type="password" required autoComplete="off" maxLength={1024} disabled={busy}/></label>
   </>}
   <p className="hint">Die Anmeldung läuft direkt im Browser. Zugangsdaten gelten bis zum Trennen der Verbindung oder Schließen dieses Dialogs.</p>
   <button className="secondary full" type="submit" disabled={busy}>Bei RomM anmelden</button>
  </form>:<>
   <p>Verbunden als <b>{connection.username}</b> · <button type="button" className="text-button" disabled={busy} onClick={()=>{
    setConnection(null);setSelected(new Set());setPlatform('');setError('');setStatus('');
   }}>Verbindung trennen</button></p>
   <label>Zielplattform in RomM
    <select value={platform} onChange={e=>setPlatform(e.target.value)} disabled={busy}>
     <option value="">Plattform auswählen</option>
     {connection.platforms.map(p=><option value={p.id} key={p.id}>{p.name}</option>)}
    </select>
   </label>
   {!connection.platforms.length&&<p className="hint">Lege zuerst eine Plattform in RomM an und verbinde dich erneut.</p>}
   <label>ROMs in AndreDrive suchen
    <input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Dateiname" disabled={busy}/>
   </label>
   <p className="hint">Hier erscheinen Dateien aus der Kategorie Spiele und aus deinem gewählten Spieleordner. Spiele mit mehreren zusammengehörigen Dateien kannst du über WebDAV als Ordner einbinden.</p>
   {!!visible.length&&<button className="text-button" type="button" disabled={busy} onClick={()=>changeSelection(visible.map(f=>f.id),!visible.every(f=>selected.has(f.id)))}>
    {visible.every(f=>selected.has(f.id))?'Sichtbare Auswahl aufheben':'Alle sichtbaren ROMs auswählen'}
   </button>}
   <div className="transfer-files">
    {visible.length?visible.map(f=><label key={f.id} className="webdav-write">
     <input type="checkbox" checked={selected.has(f.id)} disabled={busy} onChange={e=>changeSelection([f.id],e.target.checked)}/>
     <span>{f.name}</span>
    </label>):<span>Keine passenden Dateien gefunden.</span>}
   </div>
   <button className="secondary full" type="button" disabled={!platform||!queue.length||busy} onClick={()=>{
    run(async signal=>{
     const names=new Set();
     for(const file of queue){
      const name=file.name.toLowerCase();
      if(names.has(name))throw new Error('Wähle je Dateiname nur eine ROM für diese Zielplattform aus.');
      names.add(name);
     }
     for(const [index,file] of queue.entries()){
      setProgress(0);
      setStatus('ROM '+(index+1)+' von '+queue.length+' · '+file.name);
      try{await copyRom(connection.request,file,Number(platform),{
       signal,onProgress:(sent,total)=>{
        setProgress(sent/total);
        if(sent===total)setStatus('RomM verarbeitet '+file.name+' …');
       },
      })}catch(e){throw new Error(file.name+' – '+e.message)}
      changeSelection([file.id],false);
     }
     setStatus(queue.length===1?'ROM nach RomM kopiert.':queue.length+' ROMs nach RomM kopiert.');
     notify('RomM-Import abgeschlossen.');
    });
   }}>Nach RomM kopieren ({queue.length})</button>
   <p className="hint">Lass diesen Dialog während der Übertragung geöffnet.</p>
  </>}
  {status&&<p role="status">{status}</p>}
  {progress!==null&&<progress value={progress} max={1} aria-label="RomM-Übertragungsfortschritt"/>}
  {busy&&<button type="button" className="text-button danger" onClick={()=>operation.current?.abort()}>Abbrechen</button>}
  {error&&<p className="error" role="alert">{error}</p>}
  <details ref={setup}>
   <summary>Verbindung zu RomM einrichten</summary>
   <ol>
    <li>Öffne RomM zuerst auf demselben Handy. Nutze die WLAN-IP und den veröffentlichten Port des Rechners, z. B. <code>http://192.168.1.42:8080</code>. Verbinde beide Geräte mit demselben WLAN oder Hotspot.</li>
    <li>Öffne AndreDrive in Chrome. Erlaube den lokalen Netzwerkzugriff, wenn Chrome fragt. Eine frühere Ablehnung kannst du in den Website-Einstellungen von AndreDrive ändern.</li>
    <li>Ergänze die Umgebungsvariable im Abschnitt <code>environment</code> des RomM-Dienstes in deiner Docker-Compose-Datei. Wenn die Variable bereits existiert, ergänze den Wert mit Komma.</li>
   </ol>
   <pre>{'ROMM_CORS_ALLOWED_ORIGINS: "'+origin+'"'}</pre>
   <p>Wende die Änderung im Ordner der Compose-Datei mit <code>docker compose up -d</code> an. Tippe danach auf <b>Verbindung prüfen</b>. Ein Client-API-Token braucht <code>me.read</code>, <code>platforms.read</code> und <code>roms.write</code>.</p>
  </details>
 </div>;
}
