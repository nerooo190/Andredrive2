const CHUNK_BYTES=10*1024*1024;

function rommAddress(value){
 let url;
 try{url=new URL(value)}catch{throw new Error('Bitte eine vollständige RomM-Server-URL eingeben.')}
 if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.search||url.hash){
  throw new Error('Bitte die RomM-Server-URL ohne Zugangsdaten, Abfrage oder Anker verwenden.');
 }
 const host=url.hostname;
 const [first,second]=host.split('.').map(Number);
 let targetAddressSpace;
 if(host==='localhost'||host==='[::1]'||/^127\.\d+\.\d+\.\d+$/.test(host))targetAddressSpace='loopback';
 else if(host.endsWith('.local')||/^\d+\.\d+\.\d+\.\d+$/.test(host)&&
   (first===10||first===192&&second===168||first===172&&second>=16&&second<=31||first===169&&second===254)||
   /^\[(?:f[cd][\da-f]{2}|fe[89ab][\da-f]):/i.test(host))targetAddressSpace='local';
 if(url.protocol==='http:'&&!targetAddressSpace)throw new Error('Verwende HTTPS oder die private IP-Adresse deines RomM-Servers im Heimnetz.');
 const path=url.pathname.replace(/\/+$/,'').replace(/\/api(?:\/(?:docs|redoc))?$/i,'');
 return {base:url.origin+path,targetAddressSpace};
}

export function rommHome(value){
 try{return rommAddress(value).base}catch{return null}
}

async function networkError(address,signal){
 const permission=address.targetAddressSpace==='loopback'?'loopback-network':'local-network';
 if(address.targetAddressSpace&&globalThis.navigator?.permissions){
  const state=await navigator.permissions.query({name:permission}).catch(()=>null);
  if(state?.state==='denied')return 'Chrome blockiert den Zugriff auf das lokale Netzwerk. Erlaube ihn in den Website-Einstellungen für AndreDrive und versuche es erneut.';
 }
 const timeout=AbortSignal.timeout(4500);
 try{
  // An opaque response proves only that the host responded, not that its API is accessible.
  await fetch(address.base+'/api/heartbeat',{
   mode:'no-cors',credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',
   signal:signal?AbortSignal.any([signal,timeout]):timeout,
   ...(address.targetAddressSpace?{targetAddressSpace:address.targetAddressSpace}:{}),
  });
  return 'Der Server antwortet, aber die API-Anfrage wird blockiert. Erlaube die AndreDrive-Adresse in ROMM_CORS_ALLOWED_ORIGINS und erstelle den RomM-Container mit der aktualisierten Konfiguration neu.';
 }catch{
  if(signal?.aborted)throw signal.reason;
  if(address.targetAddressSpace==='loopback')return 'localhost bezeichnet dieses Gerät. Wenn RomM auf einem anderen Gerät läuft, trage dessen WLAN-IP und Port ein.';
  return 'Dein Browser erreicht die RomM-Adresse nicht. Öffne RomM auf diesem Gerät im gleichen WLAN. Verwende die WLAN-IP und den freigegebenen Port des RomM-Rechners und erlaube Chrome den Heimnetz-Zugriff.';
 }
}

export async function checkRomm(serverUrl,signal){
 const address=rommAddress(serverUrl);
 const timeout=AbortSignal.timeout(4500);
 try{
  const response=await fetch(address.base+'/api/heartbeat',{
   credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',cache:'no-store',
   signal:signal?AbortSignal.any([signal,timeout]):timeout,
   ...(address.targetAddressSpace?{targetAddressSpace:address.targetAddressSpace}:{}),
  });
  if(response.ok&&response.headers.get('Content-Type')?.includes('application/json')){
   return 'RomM antwortet im Browser. Melde dich jetzt an.';
  }
  if(response.status===401||response.status===403)return 'Der Server ist erreichbar und verlangt eine Anmeldung. Melde dich mit deinem RomM-Konto oder Token an.';
  throw new Error('Unter dieser Adresse antwortet keine RomM-API. Prüfe IP, Port und den Pfad deiner RomM-Installation.');
 }catch(error){
  if(signal?.aborted)throw signal.reason;
  if(error.name==='TypeError'||timeout.aborted)throw new Error(await networkError(address,signal));
  throw error;
 }
}

export async function connectRomm(serverUrl,{username,password,token},signal){
 const address=rommAddress(serverUrl);
 const {base,targetAddressSpace}=address;
 if(!token&&(!username||username.includes(':')||!password))throw new Error('Bitte RomM-Benutzername und Passwort eingeben.');
 const auth=token?'Bearer '+token.replace(/^Bearer\s+/i,''):'Basic '+btoa(String.fromCharCode(...new TextEncoder().encode(username+':'+password)));
 async function request(path,options={}){
  const readLogin=path==='/users/me'||path==='/platforms';
  const timeout=readLogin?AbortSignal.timeout(8500):null;
  const requestSignal=timeout&&options.signal?AbortSignal.any([timeout,options.signal]):timeout||options.signal;
  const fetchApi=route=>fetch(base+'/api'+route,{
   ...options,signal:requestSignal,credentials:'omit',redirect:'error',cache:'no-store',referrerPolicy:'no-referrer',
   ...(targetAddressSpace?{targetAddressSpace}:{}),
   headers:{...options.headers,Authorization:auth,Accept:'application/json'},
  });
  let response;
  try{
   if(!readLogin)response=await fetchApi(path);
   else{
    // Some RomM installations redirect the path ending in the wrong slash.
    // Try the two known routes on the same origin without forwarding credentials to redirects.
    try{response=await fetchApi(path)}catch(error){
     if(error.name!=='TypeError'||requestSignal.aborted)throw error;
    }
    if(!response||response.status===404){
     const retry=await fetchApi(path+'/').catch(error=>{
      if(response&&!requestSignal.aborted)return response;
      throw error;
     });
     response=retry;
    }
   }
  }catch(error){
   if(options.signal?.aborted)throw error;
   throw new Error(await networkError(address,options.signal));
  }
  if(response.ok)return response;
  const detail=(await response.json().catch(()=>null))?.detail;
  const messages={
   401:'RomM hat die Zugangsdaten abgelehnt.',
   403:'Dein RomM-Konto oder API-Token hat für diese Aktion keine Berechtigung.',
   404:'RomM bietet diesen API-Endpunkt unter der angegebenen URL nicht an.',
   413:'RomM oder sein Proxy lehnt die Größe des Upload-Abschnitts ab.',
  };
  const message=messages[response.status]||(typeof detail==='string'&&detail.slice(0,300))||'RomM meldet einen Fehler.';
  throw new Error(message+' (HTTP '+response.status+')');
 }
 const user=await (await request('/users/me',{signal})).json().catch(()=>null);
 if(!user||typeof user.username!=='string'||!user.username)throw new Error('Die Antwort enthält kein angemeldetes RomM-Konto.');
 const data=await (await request('/platforms',{signal})).json().catch(()=>null);
 if(!Array.isArray(data))throw new Error('RomM hat keine gültige Plattformliste geliefert.');
 const platforms=data.filter(p=>Number.isSafeInteger(p?.id)&&p.id>0&&typeof p.name==='string')
  .map(p=>({id:p.id,name:typeof p.display_name==='string'&&p.display_name||p.name})).sort((a,b)=>a.name.localeCompare(b.name,'de'));
 return {username:user.username,platforms,request};
}

export async function copyRom(request,file,platformId,{signal,onProgress}){
 if(!file.name||/[/\\\x00-\x1f\x7f]/.test(file.name)||['.','..'].includes(file.name)||new TextEncoder().encode(file.name).length>255){
  throw new Error('Der Dateiname ist für RomM ungültig.');
 }
 const source='/api/files/'+encodeURIComponent(file.id)+'/content';
 const head=await fetch(source,{method:'HEAD',signal,redirect:'error',cache:'no-store'});
 const size=Number(head.headers.get('Content-Length')),etag=head.headers.get('ETag');
 if(!head.ok||!Number.isSafeInteger(size)||size<=0||size!==file.size||!etag){
  throw new Error('Die Quelldatei ist nicht verfügbar, leer oder wurde geändert. Lade die Dateiliste neu.');
 }
 const chunks=Math.ceil(size/CHUNK_BYTES);
 const started=await request('/roms/upload/start',{
  method:'POST',signal,
  headers:{
   'Content-Type':'application/json','X-Upload-Platform':String(platformId),'X-Upload-Filename':encodeURIComponent(file.name),
   'X-Upload-Total-Size':String(size),'X-Upload-Total-Chunks':String(chunks),
  },
  body:JSON.stringify({filename:file.name,overwrite:false}),
 });
 const {upload_id:id}=await started.json().catch(()=>({}));
 if(typeof id!=='string'||!/^[-_a-zA-Z0-9]{1,256}$/.test(id))throw new Error('RomM hat keine gültige Upload-ID geliefert.');
 const path='/roms/upload/'+encodeURIComponent(id);
 try{
  for(let index=0;index<chunks;index++){
   const start=index*CHUNK_BYTES,end=Math.min(size,start+CHUNK_BYTES)-1;
   const part=await fetch(source,{
    signal,redirect:'error',cache:'no-store',
    headers:{Range:'bytes='+start+'-'+end,'If-Range':etag},
   });
   const length=end-start+1;
   if(part.status!==206||part.headers.get('Content-Range')!=='bytes '+start+'-'+end+'/'+size||
     part.headers.get('ETag')!==etag||Number(part.headers.get('Content-Length'))!==length){
    await part.body?.cancel();
    throw new Error('AndreDrive konnte den erwarteten Dateiabschnitt nicht lesen.');
   }
   const bytes=await part.arrayBuffer();
   if(bytes.byteLength!==length)throw new Error('Der Dateiabschnitt wurde nicht vollständig geladen.');
   await request(path,{
    method:'PUT',signal,headers:{'Content-Type':'application/octet-stream','X-Chunk-Index':String(index)},body:bytes,
   });
   onProgress(end+1,size);
  }
  await request(path+'/complete',{method:'POST',signal});
 }catch(error){
  await request(path+'/cancel',{method:'POST',signal:AbortSignal.timeout(5000)}).catch(()=>{});
  throw error;
 }
}
