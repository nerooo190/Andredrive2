'use client';
import {useState} from 'react';
import {Download} from 'lucide-react';
import {strToU8,zipSync} from 'fflate';
import {buildRommHost,streamingPlatforms} from './romm-host-config';

export default function RommHost({onUseUrl,notify}){
 const [ip,setIp]=useState(''),[port,setPort]=useState('8443');
 const [platforms,setPlatforms]=useState(['snes','gba','ngc','wii','ps2']);
 const [gpu,setGpu]=useState(true);
 const [launch,setLaunch]=useState('600'),[save,setSave]=useState('45'),[history,setHistory]=useState('50');
 const [bundleUrl,setBundleUrl]=useState(''),[error,setError]=useState('');

 function download(){
  setError('');
  try{
   const {url,files}=buildRommHost({ip,port,platforms,gpu,launch,save,history,siteOrigin:location.origin});
   const archive=zipSync(Object.fromEntries(Object.entries(files).map(([name,value])=>[name,strToU8(value)])));
   const objectUrl=URL.createObjectURL(new Blob([archive],{type:'application/zip'}));
   const anchor=document.createElement('a');
   anchor.href=objectUrl;
   anchor.download='AndreDrive-RomM-Streaming.zip';
   anchor.click();
   setTimeout(()=>URL.revokeObjectURL(objectUrl),1000);
   setBundleUrl(url);
   notify('RomM-Setup erstellt.');
  }catch(e){setError(e.message)}
 }

 return <details className="webdav-guide">
  <summary>Eigenen RomM-Server mit Streaming einrichten</summary>
  <p>AndreDrive erstellt ein Docker-Paket mit RomM und Webstation. Der Server läuft auf deinem x86-64-Linux-Rechner im Heimnetz. Für AMD- und Intel-Grafik kannst du den GPU-Durchgriff aktivieren.</p>
  <label>WLAN-IP des Docker-Rechners
   <input value={ip} maxLength={15} inputMode="decimal" placeholder="192.168.1.42" onChange={e=>{setIp(e.target.value);setBundleUrl('')}}/>
  </label>
  <label>HTTPS-Port
   <input type="number" min="1024" max="65535" value={port} onChange={e=>{setPort(e.target.value);setBundleUrl('')}}/>
  </label>
  <p className="hint">Für die Nutzung auf demselben Gerät kannst du 127.0.0.1 eingeben. Vom Handy aus brauchst du die WLAN-IP des Rechners.</p>
  <fieldset>
   <legend>Streaming-Plattformen</legend>
   {Object.entries(streamingPlatforms).map(([id,[label]])=><label className="webdav-write" key={id}>
    <input type="checkbox" checked={platforms.includes(id)} onChange={e=>setPlatforms(p=>e.target.checked?[...p,id]:p.filter(v=>v!==id))}/>
    <span>{label}</span>
   </label>)}
  </fieldset>
  <label className="webdav-write"><input type="checkbox" checked={gpu} onChange={e=>setGpu(e.target.checked)}/><span>AMD-/Intel-GPU über /dev/dri durchreichen</span></label>
  <details>
   <summary>Streaming-Timeouts und Spielstände</summary>
   <label>Emulatorstart (Sekunden)<input type="number" min="1" max="3600" value={launch} onChange={e=>setLaunch(e.target.value)}/></label>
   <label>Speichern beim Beenden (Sekunden)<input type="number" min="1" max="600" value={save} onChange={e=>setSave(e.target.value)}/></label>
   <label>Spielstände pro Spiel, Emulator und Nutzer<input type="number" min="0" max="1000" value={history} onChange={e=>setHistory(e.target.value)}/></label>
   <p className="hint">0 deaktiviert das automatische Löschen alter Spielstände.</p>
  </details>
  <button type="button" className="secondary full" disabled={!ip.trim()||!platforms.length} onClick={download}><Download size={16}/>RomM-Setup herunterladen</button>
  {error&&<p className="error" role="alert">{error}</p>}
  {bundleUrl&&<>
   <ol>
    <li>Entpacke das ZIP in einen neuen Ordner auf dem Docker-Rechner und führe dort <code>sh start.sh</code> aus.</li>
    <li>Folge der beiliegenden Anleitung für das lokale HTTPS-Zertifikat und richte dein RomM-Admin-Konto ein.</li>
    <li>Übernimm die Server-URL unten. Du kannst ROMs per Direktimport übertragen oder über den vorhandenen WebDAV-Zugang in die neue Bibliothek kopieren.</li>
   </ol>
   <p><a href={bundleUrl} target="_blank" rel="noopener noreferrer">{bundleUrl} öffnen</a></p>
   <button type="button" className="secondary full" onClick={()=>onUseUrl(bundleUrl)}>Server-URL in AndreDrive übernehmen</button>
  </>}
  <p><a href="https://docs.romm.app/5.4.0/using/emulator-streaming/#tune-the-timeouts" target="_blank" rel="noopener noreferrer">Offizielle RomM-Anleitung für Emulator-Streaming</a></p>
 </details>;
}
