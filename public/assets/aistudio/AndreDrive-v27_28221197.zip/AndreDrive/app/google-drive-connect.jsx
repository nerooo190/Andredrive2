'use client';
import {useState} from 'react';
import {Copy} from 'lucide-react';

export const googleDriveStart='/api/cloud/google-drive/start';

export default function GoogleDriveConnect({busy,connect,notify}){
 const [clientId,setClientId]=useState(''),[clientSecret,setClientSecret]=useState('');
 const redirectUri=(globalThis.location?.origin||'')+'/api/cloud/google-drive/callback';

 return <section className="settings-detail">
  <h3>Google Drive</h3>
  <p>Durchsuche „Meine Ablage“ und verwende Dateien direkt oder kopiere sie nach AndreDrive.</p>
  <label>Google OAuth-Client-ID<input value={clientId} maxLength={210} autoComplete="off" onChange={e=>setClientId(e.target.value)}/></label>
  <label>Google OAuth-Client-Geheimnis<input type="password" value={clientSecret} maxLength={256} autoComplete="new-password" onChange={e=>setClientSecret(e.target.value)}/></label>
  <button className="secondary full" type="button" disabled={busy||!clientId.trim()||!clientSecret.trim()} onClick={()=>connect({clientId,clientSecret})}>Mit Google verbinden</button>
  <details className="webdav-guide">
   <summary>Google Drive einmalig einrichten</summary>
   <ol>
    <li>Aktiviere in der <a href="https://console.cloud.google.com/apis/library/drive.googleapis.com" target="_blank" rel="noreferrer">Google Cloud Console</a> die Google Drive API.</li>
    <li>Richte die OAuth-Zustimmungsseite ein. Für ein externes Projekt im Testmodus füge dein Google-Konto als Testnutzer hinzu.</li>
    <li>Erstelle unter Google Auth Platform → Clients einen OAuth-Client vom Typ <b>Webanwendung</b>. Füge diese Adresse als autorisierte Weiterleitungs-URI hinzu.</li>
   </ol>
   <label>Autorisierte Weiterleitungs-URI
    <div className="copy-field">
     <input readOnly value={redirectUri} onFocus={e=>e.target.select()}/>
     <button type="button" aria-label="Weiterleitungs-URI kopieren" onClick={()=>navigator.clipboard.writeText(redirectUri).then(()=>notify('Weiterleitungs-URI kopiert.')).catch(()=>notify('Bitte die Adresse markieren und kopieren.'))}><Copy size={16}/></button>
    </div>
   </label>
   <p>Trage Client-ID und Client-Geheimnis oben ein und erlaube bei Google den Drive-Lesezugriff. Im externen Testmodus läuft Googles Freigabe nach sieben Tagen ab. Über „Erneut verbinden“ kannst du sie erneuern.</p>
   <p>Google Docs, Tabellen und Präsentationen kannst du nach einem Export als normale Dateien hinzufügen.</p>
  </details>
 </section>;
}
