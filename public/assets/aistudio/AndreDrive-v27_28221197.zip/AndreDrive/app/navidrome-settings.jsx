'use client';

import {useEffect, useState} from 'react';
import {Copy, Eye, EyeOff, Headphones, LoaderCircle} from 'lucide-react';
import {api} from './api-client';

const endpoint = '/api/navidrome/accounts';

export default function NavidromeSettings({notify}) {
  const [accounts, setAccounts] = useState([]);
  const [serverUrl, setServerUrl] = useState('');
  const [created, setCreated] = useState(null);
  const [visible, setVisible] = useState(false);
  const [label, setLabel] = useState('Mein Musikplayer');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function load() {
    const data = await api(endpoint);
    setServerUrl(data.serverUrl);
    setAccounts(data.accounts);
  }

  useEffect(() => { load().catch(e => setError(e.message)); }, []);

  async function action(task) {
    setBusy(true);
    setError('');
    try { await task(); } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  const fields = [
    {name:'Navidrome-Server-URL', value:serverUrl},
    ...(created ? [
      {name:'Navidrome-Benutzername', value:created.username},
      {name:'Navidrome-Passwort', value:created.password, secret:true},
    ] : []),
  ];

  return <section id="navidrome-settings" className="webdav-settings">
    <div className="vod-access-heading"><Headphones size={20}/><h3>Navidrome / Subsonic</h3></div>
    <p>Musik, Hörbücher und Podcasts aus AndreDrive in kompatiblen Audio-Apps abspielen. Erstelle einen eigenen Zugang pro Gerät.</p>
    {fields.map(({name,value,secret}) => <label key={name}>
      {name}
      <div className="copy-field">
        <input aria-label={name} type={secret && !visible ? 'password' : 'text'} readOnly value={value} onFocus={e => e.target.select()}/>
        {secret && <button type="button" aria-label="Navidrome-Passwort anzeigen oder verbergen" aria-pressed={visible} onClick={() => setVisible(!visible)}>
          {visible ? <EyeOff size={16}/> : <Eye size={16}/>}
        </button>}
        <button type="button" aria-label={name + ' kopieren'} disabled={!value} onClick={async () => {
          try { await navigator.clipboard.writeText(value); notify(name + ' kopiert.'); }
          catch { setError('Bitte den Wert markieren und kopieren.'); }
        }}><Copy size={16}/></button>
      </div>
    </label>)}
    {created && <p className="hint">Speichere das Passwort vor dem Schließen. Es wird einmalig angezeigt.</p>}
    <label>Gerätename<input value={label} maxLength={80} onChange={e => setLabel(e.target.value)}/></label>
    <button type="button" className="secondary full" disabled={busy} onClick={() => action(async () => {
      const fresh = await api(endpoint, {method:'POST', body:JSON.stringify({label})});
      setCreated(fresh);
      setVisible(false);
      await load();
      notify('Navidrome-Gerätezugang erstellt.');
    })}>{busy ? <LoaderCircle className="spin" size={16}/> : <Headphones size={16}/>}Navidrome-Gerätezugang erstellen</button>
    {accounts.map(account => <div className="webdav-account" key={account.id}>
      <div><b>{account.label}</b><small>AndreDrive Audio</small><code>{account.username}</code></div>
      <button type="button" className="text-button danger" disabled={busy} onClick={() => action(async () => {
        await api(endpoint + '/' + account.id, {method:'DELETE'});
        if (created?.id === account.id) setCreated(null);
        await load();
        notify('Navidrome-Gerätezugang widerrufen.');
      })}>Widerrufen</button>
    </div>)}
    <details className="webdav-guide">
      <summary>Mit einer App verbinden</summary>
      <p>In der App einen Subsonic- oder OpenSubsonic-Server hinzufügen. Server-URL, Benutzernamen und Passwort von oben eintragen. Viele Apps verwenden dafür die Bezeichnung Navidrome.</p>
      <p>Die Schnittstelle unterstützt Suche, Künstler, Alben, vorhandene Datei-Cover, Favoriten und Playlists. Audiodateien werden im Originalformat übertragen. Die App muss dieses Format unterstützen. Wo Albumdaten fehlen, gruppiert AndreDrive die Titel nach Ordnern.</p>
    </details>
    {error && <p className="error" role="alert">{error}</p>}
  </section>;
}
