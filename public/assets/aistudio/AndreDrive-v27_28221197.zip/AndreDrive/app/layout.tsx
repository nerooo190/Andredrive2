import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {title:"AndreDrive · Deine private Cloud",description:"Deine Dateien, Videos und Ordner — mit ChatGPT geschützt und in Sites gespeichert.",icons:{icon:"/favicon.svg"}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="de"><body>{children}</body></html>}
