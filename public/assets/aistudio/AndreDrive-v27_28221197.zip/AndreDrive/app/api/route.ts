import {env} from 'cloudflare:workers';
import {handleDrive} from '../../lib/drive-backend';
export const dynamic='force-dynamic';
export const GET=(r:Request)=>handleDrive(r,env);
