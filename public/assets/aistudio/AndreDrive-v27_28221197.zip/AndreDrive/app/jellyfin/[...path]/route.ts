import {env} from 'cloudflare:workers';
import {handleDrive} from '../../../lib/drive-backend';
export const dynamic='force-dynamic';
export const GET=(r:Request)=>handleDrive(r,env);

export const OPTIONS=GET;

export const HEAD=GET;
export const POST=GET;
export const DELETE=GET;
export const PUT=GET;
export const PATCH=GET;
