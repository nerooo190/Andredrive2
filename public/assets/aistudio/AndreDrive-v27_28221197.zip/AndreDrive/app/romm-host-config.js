export const streamingPlatforms={
 snes:['Super Nintendo','retroarch'],
 gba:['Game Boy Advance','retroarch:gpsp'],
 n64:['Nintendo 64','retroarch'],
 ngc:['GameCube','dolphin'],
 wii:['Wii','dolphin'],
 psx:['PlayStation','duckstation'],
 ps2:['PlayStation 2','pcsx2'],
 psp:['PSP','ppsspp'],
};

export function rommHostAddress(value,port){
 const ip=String(value).trim(),parts=ip.split('.');
 if(parts.length!==4||parts.some(part=>!/^(0|[1-9]\d{0,2})$/.test(part)||Number(part)>255)){
  throw new Error('Trage die private IPv4-Adresse des Docker-Rechners ein, z. B. 192.168.1.42.');
 }
 const [a,b]=parts.map(Number);
 if(!(ip==='127.0.0.1'||a===10||a===192&&b===168||a===172&&b>=16&&b<=31)){
  throw new Error('Verwende eine private WLAN-IP oder 127.0.0.1 für die Nutzung auf dem Host.');
 }
 if(!/^\d+$/.test(String(port))||Number(port)<1024||Number(port)>65535)throw new Error('Wähle einen HTTPS-Port zwischen 1024 und 65535.');
 return 'https://'+ip+':'+Number(port);
}

function integer(value,min,max,label){
 if(!/^\d+$/.test(String(value))||Number(value)<min||Number(value)>max)throw new Error(label+' muss zwischen '+min+' und '+max+' liegen.');
 return Number(value);
}

function secret(bytes=32){
 return Array.from(crypto.getRandomValues(new Uint8Array(bytes)),byte=>byte.toString(16).padStart(2,'0')).join('');
}

export function buildRommHost({ip,port,platforms,gpu,launch,save,history,siteOrigin}){
 const url=rommHostAddress(ip,port);
 const origin=new URL(siteOrigin).origin;
 const selected=Object.keys(streamingPlatforms).filter(platform=>platforms.includes(platform));
 if(!selected.length)throw new Error('Wähle mindestens eine Streaming-Plattform.');
 const launchTimeout=integer(launch,1,3600,'Start-Timeout');
 const saveTimeout=integer(save,1,600,'Speicher-Timeout');
 const stateHistory=integer(history,0,1000,'Spielstand-Limit');
 port=Number(port);

 const compose=`services:
  romm:
    image: rommapp/romm:5.4.1
    restart: unless-stopped
    depends_on:
      db:
        condition: service_healthy
    environment:
      DB_HOST: db
      DB_NAME: romm
      DB_USER: romm
      DB_PASSWD: "${'${ROMM_DB_PASSWORD:?Fehlt in .env}'}"
      ROMM_AUTH_SECRET_KEY: "${'${ROMM_AUTH_SECRET:?Fehlt in .env}'}"
      ROMM_BASE_URL: "${url}"
      ROMM_SESSION_SECURE_COOKIE: "true"
      ROMM_CORS_ALLOWED_ORIGINS: "${origin}"
      STREAMING_BROKER_SECRET: "${'${BROKER_SECRET:?Fehlt in .env}'}"
      STREAMING_LAUNCH_TIMEOUT: "${launchTimeout}"
      STREAMING_SAVE_TIMEOUT: "${saveTimeout}"
      STREAMING_STATE_HISTORY_LIMIT: "${stateHistory}"
    volumes:
      - ./library:/romm/library
      - ./romm-config:/romm/config
      - romm-assets:/romm/assets
      - romm-resources:/romm/resources
      - valkey-data:/redis-data
  db:
    image: mariadb:11.4
    restart: unless-stopped
    environment:
      MARIADB_DATABASE: romm
      MARIADB_USER: romm
      MARIADB_PASSWORD: "${'${ROMM_DB_PASSWORD:?Fehlt in .env}'}"
      MARIADB_ROOT_PASSWORD: "${'${ROMM_DB_ROOT_PASSWORD:?Fehlt in .env}'}"
    volumes:
      - database:/var/lib/mysql
    healthcheck:
      test: [CMD, healthcheck.sh, --connect, --innodb_initialized]
      interval: 10s
      timeout: 5s
      start_period: 30s
      retries: 10
  webstation:
    image: lscr.io/linuxserver/webstation:romm
    platform: linux/amd64
    restart: unless-stopped
    shm_size: 1gb
    environment:
      PUID: "1000"
      PGID: "1000"
      SUBFOLDER: /streaming/
      BROKER_SECRET: "${'${BROKER_SECRET:?Fehlt in .env}'}"
    volumes:
      - ./library:/romm/library:ro
      - webstation-config:/config
${gpu?'    devices:\n      - /dev/dri:/dev/dri\n':''}  caddy:
    image: caddy:2-alpine
    restart: unless-stopped
    ports:
      - "${new URL(url).hostname}:${port}:${port}"
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile:ro
      - ./stream-auth:/etc/caddy/stream-auth:ro
      - caddy-data:/data
      - caddy-config:/config
volumes:
  database:
  romm-assets:
  romm-resources:
  valkey-data:
  webstation-config:
  caddy-data:
  caddy-config:
`;
 const config=`streaming:
  enabled: true
  containers:
    - label: AndreDrive Webstation
      protocol: webstation
      host: /streaming
      broker_host: http://webstation:3000
      subfolder: /streaming
      library_path: /romm/library
      platforms:
${selected.map(platform=>'        '+platform+': '+streamingPlatforms[platform][1]).join('\n')}
`;
 const caddy=`{
  auto_https disable_redirects
}

${url} {
  tls internal
  redir /streaming /streaming/ 308
  handle /streaming/* {
    basic_auth {
      import /etc/caddy/stream-auth
    }
    reverse_proxy webstation:3000 {
      header_up -Authorization
    }
  }
  handle {
    reverse_proxy romm:8080
  }
}
`;
 const start=`#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
umask 077
[ "$(uname -s)" = Linux ] && [ "$(uname -m)" = x86_64 ] || {
  echo "Dieses Streaming-Setup benötigt einen x86-64-Linux-Rechner." >&2
  exit 1
}
${gpu?'[ -d /dev/dri ] || { echo "Kein /dev/dri gefunden. Deaktiviere den GPU-Durchgriff oder richte den GPU-Treiber ein." >&2; exit 1; }\n':''}docker compose version >/dev/null
chmod 600 .env
if [ ! -s stream-auth ]; then
  stream_password=$(sed -n 's/^WEBSTATION_PASSWORD=//p' .env)
  [ -n "$stream_password" ] || { echo "WEBSTATION_PASSWORD fehlt in .env." >&2; exit 1; }
  stream_hash=$(printf '%s\n' "$stream_password" | docker run --rm -i caddy:2-alpine caddy hash-password --bcrypt-cost 10)
  case "$stream_hash" in
    '$2'*) ;;
    *) echo "Caddy hat keinen gültigen Passwort-Hash geliefert." >&2; exit 1 ;;
  esac
  printf 'stream %s\n' "$stream_hash" > stream-auth
fi
docker compose up -d
printf '\nRomM: %s\n' '${url}'
`;
 const env=`ROMM_AUTH_SECRET=${secret()}
ROMM_DB_PASSWORD=${secret()}
ROMM_DB_ROOT_PASSWORD=${secret()}
BROKER_SECRET=${secret()}
WEBSTATION_PASSWORD=${secret(16)}
`;
 const readme=`AndreDrive – eigener RomM-Server im Heimnetz

Voraussetzungen
- Linux x86-64, Docker mit Compose und möglichst GPU-Beschleunigung.
- Die eingetragene IP muss auf dem Docker-Rechner liegen. Nutze dieses Setup im vertrauenswürdigen Heimnetz.

1. ZIP in einen neuen Ordner entpacken, Terminal in diesem Ordner öffnen und sh start.sh ausführen.
2. Lokales TLS-Zertifikat exportieren:
   docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt romm-local-ca.crt
   Importiere nur diese öffentliche CA-Datei auf den Geräten, mit denen du dich verbinden möchtest. Das Verfahren richtet sich nach deinem Betriebssystem und Browser.
3. Öffne ${url} und richte in RomM dein Admin-Konto ein.
4. Öffne einmal ${url}/streaming/ im selben Browser. Der Webstation-Zugang lautet stream und das Passwort steht in .env unter WEBSTATION_PASSWORD.
5. Lege deine ROMs in library/roms/<plattform>/ ab. Alternativ verwende den AndreDrive-Direktimport mit dieser Server-URL. Für WebDAV kannst du ROMs über rclone in ./library/roms/ kopieren.
6. Scanne die Bibliothek in RomM und wähle im Spiel die Streaming-Aktion. Für Emulatoren mit BIOS oder Firmware richtest du diese über eine RomM-Desktop-Sitzung ein. ROM-Archive bei Bedarf vorher entpacken.

Sicherung: .env enthält die privaten Schlüssel. Bewahre sie geschützt auf. Caddys Datenvolume enthält die private CA und muss bei einem Neustart erhalten bleiben. Nutze zum Stoppen docker compose stop.

Dokumentation
https://docs.romm.app/5.4.0/using/emulator-streaming/
https://romm-streaming.github.io/romm-broker/docs/container/
https://caddyserver.com/docs/running#local-https-with-docker
`;
 return {url,files:{
  'compose.yaml':compose,'.env':env,Caddyfile:caddy,'romm-config/config.yml':config,'start.sh':start,'README.txt':readme,
  ...Object.fromEntries(selected.map(platform=>['library/roms/'+platform+'/',''])),
 }};
}
