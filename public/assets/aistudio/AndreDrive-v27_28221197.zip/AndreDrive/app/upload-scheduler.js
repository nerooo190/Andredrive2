// One connection budget for the entire upload batch, including retries.
export const MAX_UPLOAD_TRANSFERS=32;
export const DEFAULT_UPLOAD_TRANSFERS=8;
const aborted=()=>new DOMException('Upload pausiert','AbortError');
export function createUploadPool(requested=DEFAULT_UPLOAD_TRANSFERS,{maxBytes}={}){
 const memory=typeof navigator!=='undefined'?navigator.deviceMemory:undefined;
 const byteLimit=maxBytes??(memory&&memory<=2?128:memory&&memory<=4?256:512)*1024**2;
 const target=Math.max(1,Math.min(MAX_UPLOAD_TRANSFERS,Math.floor(Number(requested)||DEFAULT_UPLOAD_TRANSFERS)));
 let limit=target,active=0,bytes=0,successes=0;const queue=[];
 function drain(){while(queue.length&&active<limit){const entry=queue[0];if(active&&bytes+entry.bytes>byteLimit)return;queue.shift();entry.signal.removeEventListener('abort',entry.cancel);active++;bytes+=entry.bytes;entry.resolve()}}
 return {target,get active(){return active},get limit(){return limit},async run(size,signal,transfer){
  if(signal.aborted)throw aborted();
  const entry={bytes:size,signal};
  await new Promise((resolve,reject)=>{entry.resolve=resolve;entry.cancel=()=>{const i=queue.indexOf(entry);if(i>=0)queue.splice(i,1);reject(aborted());drain()};signal.addEventListener('abort',entry.cancel,{once:true});queue.push(entry);drain()});
  try{if(signal.aborted)throw aborted();const result=await transfer();if(++successes>=limit*2){limit=Math.min(target,limit+1);successes=0}return result}
  catch(error){if(!signal.aborted&&(!error.status||[408,429,503,504].includes(error.status))){limit=Math.max(1,Math.floor(limit/2));successes=0}throw error}
  finally{active--;bytes-=size;drain()}
 }};
}
// Several small files can fill the same budget as the chunks of a large file.
// Results and metadata indices retain the original file order.
export async function uploadFiles(files,metadata,{signal,onProgress=()=>{},concurrency=DEFAULT_UPLOAD_TRANSFERS,upload}={}){
 const pool=createUploadPool(concurrency),controller=new AbortController(),cancel=()=>controller.abort();
 signal.addEventListener('abort',cancel,{once:true});if(signal.aborted)controller.abort();
 const progress=files.map(()=>0),results=new Array(files.length);let next=0,error;
 async function worker(){while(!controller.signal.aborted){const i=next++;if(i>=files.length)return;try{results[i]=await upload(files[i],typeof metadata==='function'?metadata(files[i],i):metadata,{signal:controller.signal,pool,concurrency:pool.target,onProgress:n=>{progress[i]=n;onProgress(progress.reduce((a,b)=>a+b,0),i,n)}})}catch(e){if(!error)error=e;controller.abort();return}}}
 try{await Promise.all(Array.from({length:Math.min(4,pool.target,files.length)},worker));if(signal.aborted)throw aborted();if(error)throw error;return results}
 finally{signal.removeEventListener('abort',cancel);controller.abort()}
}
