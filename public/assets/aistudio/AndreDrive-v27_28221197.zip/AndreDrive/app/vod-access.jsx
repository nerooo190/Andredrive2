'use client';
import {useState} from 'react';
import {Copy,Film,Eye,EyeOff} from 'lucide-react';
export default function VodAccess({link,notify}){
 const [visible,setVisible]=useState(false),[error,setError]=useState('');
 if(!link)return null;
 const values=[['Server-URL',location.origin],['Benutzername',link.token.slice(0,32)],['Passwort',link.token.slice(32)]];
 return <section className="vod-access"><div className="vod-access-heading"><Film size={20}/><h3>Filme & Serien im IPTV-Player</h3></div><p>In Waveo: Einstellungen → Playlists & Update → Playlists verwalten → Neue Playlist → <b>Xtream</b>. Trage diese drei Werte ein.</p><p className="hint">Dieser Zugang liefert Filme unter „Filme“ und Episoden unter „Serien“. Er enthält keine Live-TV-Kanäle. Eine bereits als M3U importierte Liste bitte durch diesen Xtream-Zugang ersetzen.</p>{values.map(([label,value],i)=><label key={label}>{label}<div className="copy-field"><input aria-label={'Xtream '+label} type={i===2&&!visible?'password':'text'} readOnly value={value} onFocus={e=>e.target.select()}/>{i===2&&<button type="button" aria-label={visible?'Passwort verbergen':'Passwort anzeigen'} onClick={()=>setVisible(v=>!v)}>{visible?<EyeOff size={17}/>:<Eye size={17}/>}</button>}<button type="button" aria-label={'Xtream '+label+' kopieren'} onClick={()=>navigator.clipboard.writeText(value).then(()=>{setError('');notify(label+' kopiert.');}).catch(()=>setError('Bitte den Wert markieren und kopieren.'))}><Copy size={17}/></button></div></label>)}<small className="hint">Es werden nur die Videos dieser Freigabe angezeigt. Der Zugang gilt bis zum Widerruf des Freigabelinks. Nach Änderungen im Player die Playlist aktualisieren.</small>{error&&<p className="error">{error}</p>}</section>;
}
