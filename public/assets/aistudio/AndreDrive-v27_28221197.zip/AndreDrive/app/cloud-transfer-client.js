import {api} from './api-client.js';
export const DEFAULT_CLOUD_PARALLEL=24,MAX_CLOUD_PARALLEL=32;
const complete=new Set(['done','kept','cancelled']);
const abort=()=>new DOMException('Übertragung pausiert','AbortError');
function delay(ms,signal){return new Promise((resolve,reject)=>{if(signal.aborted)return reject(abort());const cancel=()=>{clearTimeout(timer);reject(abort())};const timer=setTimeout(()=>{signal.removeEventListener('abort',cancel);resolve()},ms);signal.addEventListener('abort',cancel,{once:true})})}
// One FIFO request pool shared by every batch in this page. Changing the view or
// adding another selection cannot create a second pool and multiply the limit.
export function createCloudPool(parallel=DEFAULT_CLOUD_PARALLEL){
 let limit=Math.max(1,Math.min(MAX_CLOUD_PARALLEL,Number(parallel)||DEFAULT_CLOUD_PARALLEL)),active=0;const waiting=[];
 function pump(){while(active<limit&&waiting.length){const task=waiting.shift();if(task.signal.aborted){task.reject(abort());continue}active++;Promise.resolve().then(task.fn).then(task.resolve,task.reject).finally(()=>{active--;pump()})}}
 return {run(fn,signal){return new Promise((resolve,reject)=>{waiting.push({fn,signal,resolve,reject});pump()})},setLimit(value){limit=Math.max(1,Math.min(MAX_CLOUD_PARALLEL,Number(value)||DEFAULT_CLOUD_PARALLEL));pump()},get limit(){return limit},get active(){return active}};
}
async function request(path,signal,pool){for(let attempt=0,busy=0;;attempt++){if(signal.aborted)throw abort();try{return await pool.run(()=>api(path,{method:'POST',signal}),signal)}catch(e){if(signal.aborted)throw abort();if(e.status===409&&busy<180){const current=await pool.run(()=>api(path.replace(/\/(step|finish)$/,''),{signal}),signal);if(current.busy){busy++;attempt--;await delay(2000,signal);continue}}if(attempt>=4||e.status&&e.status<500&&e.status!==429)throw e;await delay(Math.min(8000,750*2**attempt),signal)}}}
// Each file receives one part per turn. Large files cannot monopolize slots;
// slow files do not stop the others. A failed batch never removes any sources.
export async function runCloudTransfers(jobs,{signal,onUpdate=()=>{},onError=()=>{},parallel=DEFAULT_CLOUD_PARALLEL,pool=createCloudPool(parallel)}){
 const result=new Map(jobs.map(j=>[j.id,j])),queue=[...result.values()];let error;
 async function copy(){while(!signal.aborted){const j=queue.shift();if(!j)return;try{let current=j;if(['copying','verifying'].includes(j.status)){current=await request('/api/cloud/transfers/'+j.id+'/step',signal,pool);result.set(j.id,current);onUpdate(current);if(['copying','verifying'].includes(current.status))queue.push(current)}if(current.status==='cancelled')throw Error('Eine Übertragung wurde verworfen. Die Quellen bleiben erhalten.')}catch(e){if(signal.aborted)return;error??=e;onError(j,e)}}}
 await Promise.all(Array.from({length:Math.min(MAX_CLOUD_PARALLEL,jobs.length)},copy));if(signal.aborted)throw abort();if(error)throw error;
 for(const j of result.values())if(j.status==='source_pending'){const done=await request('/api/cloud/transfers/'+j.id+'/finish',signal,pool);result.set(j.id,done);onUpdate(done)}
 return [...result.values()];
}
// The queue belongs to the signed-in workspace, not the CloudSources component.
// Only active job IDs/preferences are saved locally; file bytes, provider URLs
// and credentials remain on the server. D1 owns resumable part/checksum state.
export function createCloudTransferManager({storage=()=>globalThis.localStorage,loadJobs=()=>api('/api/cloud/transfers')}={}){
 let owner=null,generation=0,parallel=DEFAULT_CLOUD_PARALLEL,error='',paused=false,leaving=false,snapshot={jobs:[],running:false,active:0,parallel,error,paused};const jobs=new Map(),activeIds=new Set(),controllers=new Set(),listeners=new Set(),pool=createCloudPool();
 const key=()=>owner?'andredrive:cloud-queue:'+owner:null;
 function persist(){try{if(key())storage()?.setItem(key(),JSON.stringify({ids:[...activeIds],parallel}))}catch{}}
 function emit(){snapshot={jobs:[...jobs.values()].map(j=>({...j,running:activeIds.has(j.id)})),running:controllers.size>0,active:[...activeIds].filter(id=>!complete.has(jobs.get(id)?.status)).length,parallel,error,paused};for(const listener of listeners)listener()}
 function update(job){const previous=jobs.get(job.id),now=Date.now(),delta=Math.max(0,(job.copied||0)-(previous?.copied||0)),elapsed=previous?Math.max(.001,(now-(previous.sampleTime||now))/1000):0;const rate=job.status==='copying'&&delta&&elapsed?delta/elapsed:job.status==='copying'?previous?.speed||0:0;jobs.set(job.id,{...previous,...job,speed:rate,sampleTime:now});emit()}
 async function enqueue(input){const batch=input.filter(j=>!activeIds.has(j.id)&&!complete.has(j.status));if(!owner||!batch.length)return;const runGeneration=generation,controller=new AbortController();controllers.add(controller);error='';paused=false;for(const job of batch){jobs.set(job.id,{...jobs.get(job.id),...job,error:'',sampleTime:Date.now()});activeIds.add(job.id)}persist();emit();
  try{await runCloudTransfers(batch,{signal:controller.signal,pool,onUpdate:job=>{if(generation===runGeneration)update(job)},onError:(job,e)=>{if(generation===runGeneration)update({...jobs.get(job.id),error:e.message})}})}catch(e){if(generation===runGeneration&&!controller.signal.aborted)error=e.message}finally{if(generation===runGeneration){controllers.delete(controller);for(const job of batch)activeIds.delete(job.id);if(!leaving)persist();emit()}}
 }
 async function recover(){if(!owner)return;const thisGeneration=generation;let saved;try{saved=JSON.parse(storage()?.getItem(key())||'null')}catch{}if(!Array.isArray(saved?.ids)||!saved.ids.length)return;try{const data=await loadJobs();if(generation!==thisGeneration)return;for(const job of data.transfers)if(!activeIds.has(job.id))jobs.set(job.id,job);emit();const pending=data.transfers.filter(j=>saved.ids.includes(j.id)&&!complete.has(j.status));if(pending.length)void enqueue(pending);else persist()}catch(e){if(generation===thisGeneration){error=e.message;emit()}}}
 return {subscribe(listener){listeners.add(listener);return()=>listeners.delete(listener)},getSnapshot:()=>snapshot,
  async bind(nextOwner){if(owner===nextOwner)return;for(const controller of controllers)controller.abort();generation++;const thisGeneration=generation;owner=nextOwner;leaving=false;controllers.clear();activeIds.clear();jobs.clear();error='';paused=false;parallel=DEFAULT_CLOUD_PARALLEL;let saved;try{saved=JSON.parse(storage()?.getItem(key())||'null')}catch{}parallel=[4,8,16,20,24,32].includes(saved?.parallel)?saved.parallel:DEFAULT_CLOUD_PARALLEL;pool.setLimit(parallel);emit();if(generation===thisGeneration)await recover()},
  checkpoint(){leaving=true;persist()},
  async recover(){leaving=false;await recover()},
  merge(input){for(const job of input)if(!activeIds.has(job.id))jobs.set(job.id,{...jobs.get(job.id),...job});emit()},enqueue,
  pause(){paused=true;for(const controller of controllers)controller.abort();generation++;controllers.clear();activeIds.clear();persist();emit()},
  setParallel(value){parallel=Math.max(1,Math.min(MAX_CLOUD_PARALLEL,Number(value)||DEFAULT_CLOUD_PARALLEL));pool.setLimit(parallel);persist();emit()}
 };
}
export const cloudTransferManager=createCloudTransferManager();
