'use client';
import {useEffect,useState} from 'react';
import {Copy,ExternalLink,Gamepad2} from 'lucide-react';
import {api} from './api-client';
import RommDirect from './romm-direct';
import RommHost from './romm-host';

const settingsPath='/api/romm/settings';
const accessPath='/api/romm/access';

function folderPath(folder,byId){
 const names=[];
 for(let current=folder;current;current=byId.get(current.parent))names.unshift(current.name);
 return names.join(' / ');
}

export default function RommSettings({files,folders,notify}){
 const [saved,setSaved]=useState(null),[endpoint,setEndpoint]=useState('');
 const [serverUrl,setServerUrl]=useState(''),[folderId,setFolderId]=useState('');
 const [fresh,setFresh]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const byId=new Map(folders.map(folder=>[folder.id,folder]));
 const choices=folders.map(folder=>({id:folder.id,label:folderPath(folder,byId)}))
  .sort((a,b)=>a.label.localeCompare(b.label,'de'));
 const platforms=folders.filter(folder=>folder.parent===folderId);
 const dirty=serverUrl!==saved?.server_url||folderId!==saved?.folder_id;
 const sourceReady=byId.has(saved?.folder_id);

 async function load(){
  const data=await api(settingsPath);
  setSaved(data.settings);
  setEndpoint(data.endpoint);
  return data.settings;
 }
 useEffect(()=>{
  load().then(settings=>{
   if(settings){setServerUrl(settings.server_url);setFolderId(settings.folder_id)}
  }).catch(e=>setError(e.message));
 },[]);

 async function action(work){
  setError('');
  setBusy(true);
  try{await work()}catch(e){setError(e.message)}finally{setBusy(false)}
 }
 async function copy(label,value){
  try{await navigator.clipboard.writeText(value);notify(label+' kopiert.')}
  catch{setError('Bitte den Wert markieren und kopieren.')}
 }

 return <section className="webdav-settings">
  <div className="vod-access-heading"><Gamepad2 size={20}/><h3>RomM</h3></div>
  <p>Binde Spiele aus AndreDrive auf deinem eigenen RomM-Server ein. Dein Server kann im Heimnetz bleiben.</p>
  <form onSubmit={e=>{
   e.preventDefault();
   action(async()=>{
    await api(settingsPath,{method:'PUT',body:JSON.stringify({server_url:serverUrl,folder_id:folderId})});
    if(saved?.folder_id!==folderId)setFresh(null);
    const next=await load();
    setServerUrl(next.server_url);
    notify('RomM-Einstellungen gespeichert.');
   });
  }}>
   <label>Deine RomM-Server-URL
    <input type="url" required disabled={busy||!endpoint} value={serverUrl} maxLength={2048} placeholder="http://steamdeck.local:8080" onChange={e=>setServerUrl(e.target.value)}/>
   </label>
   <label>Spieleordner in AndreDrive
    <select required disabled={busy||!endpoint} value={byId.has(folderId)?folderId:''} onChange={e=>setFolderId(e.target.value)}>
     <option value="" disabled>Ordner auswählen</option>
     {choices.map(folder=><option key={folder.id} value={folder.id}>{folder.label}</option>)}
    </select>
   </label>
   <p className="hint">Lege im Spieleordner Plattform-Unterordner wie <code>snes</code>, <code>gba</code>, <code>ngc</code> oder <code>ps</code> an. Alle Dateien in diesen Unterordnern stehen RomM zur Verfügung. Dateien direkt im ausgewählten Ordner werden übersprungen.</p>
   {folderId&&<p className="hint">{platforms.length?('Plattform-Ordner: '+platforms.map(folder=>folder.name).join(', ')):'In diesem Ordner gibt es noch keine Plattform-Unterordner.'}</p>}
   {saved?.username&&folderId!==saved.folder_id&&<p className="hint">Beim Wechsel des Spieleordners wird der bisherige Lesezugang widerrufen.</p>}
   <button type="submit" className="secondary full" disabled={busy||!endpoint||!serverUrl||!byId.has(folderId)||!dirty}>RomM-Einstellungen speichern</button>
  </form>
  {saved&&<p><a href={saved.server_url} target="_blank" rel="noopener noreferrer"><ExternalLink size={15}/> RomM öffnen</a></p>}
  {endpoint&&serverUrl.trim()&&<RommDirect key={serverUrl.trim()} serverUrl={serverUrl.trim()} files={files} folders={folders} folderId={folderId} notify={notify}/>}
  {saved&&sourceReady&&<>
   {[
    ['WebDAV-URL für RomM',endpoint],
    ...(saved.username?[['Benutzername',saved.username]]:[]),
    ...(fresh?[['Passwort',fresh.password]]:[]),
   ].map(([label,value])=><label key={label}>{label}
    <div className="copy-field">
     <input aria-label={label} readOnly type={label==='Passwort'?'password':'text'} value={value} onFocus={e=>e.target.select()}/>
     <button type="button" aria-label={label+' kopieren'} onClick={()=>copy(label,value)}><Copy size={17}/></button>
    </div>
   </label>)}
   {fresh&&<p className="hint">Kopiere das Passwort jetzt. Es wird nur einmal angezeigt.</p>}
   {saved.username?<button type="button" className="text-button danger" disabled={busy} onClick={()=>action(async()=>{
    await api(accessPath,{method:'DELETE'});
    setFresh(null);
    await load();
    notify('RomM-Lesezugang widerrufen.');
   })}>Lesezugang widerrufen</button>:<button type="button" className="secondary full" disabled={busy||dirty} onClick={()=>action(async()=>{
    const credentials=await api(accessPath,{method:'POST'});
    setFresh(credentials);
    await load();
    notify('RomM-Lesezugang erstellt.');
   })}>Lesezugang für RomM erstellen</button>}
  </>}
  {saved&&!sourceReady&&<p className="hint">Der gespeicherte Spieleordner ist nicht mehr verfügbar. Wähle einen neuen Ordner.</p>}
  <details className="webdav-guide">
   <summary>RomM mit rclone und Docker einrichten</summary>
   <p>Führe <code>rclone config</code> auf dem Gerät aus, auf dem RomM läuft. Erstelle einen Remote namens <code>andredrive-romm</code> vom Typ <code>webdav</code>. Verwende die WebDAV-URL und den Lesezugang aus diesem Abschnitt. Wähle <code>other</code> als Anbieter und lass das Feld für den Bearer-Token leer.</p>
   <p>Prüfe, ob rclone deine Plattform-Ordner anzeigt.</p>
   <pre>rclone lsf andredrive-romm:roms/</pre>
   <p><b>Direkt aus AndreDrive lesen.</b> Wenn rclone und FUSE auf deinem Linux-Host eingerichtet sind, mounte die Bibliothek in deinem Home-Verzeichnis. Für <code>--allow-other</code> muss FUSE die Option <code>user_allow_other</code> erlauben.</p>
   <pre>{'mkdir -p "$HOME/andredrive-romm"\nrclone mount andredrive-romm: "$HOME/andredrive-romm" \\\n  --read-only --allow-other --vfs-cache-mode full'}</pre>
   <p>Bei einer neuen RomM-Bibliothek binde den laufenden Mount in den bestehenden RomM-Dienst deiner Compose-Datei ein. Starte den Dienst danach neu. Lass den Mount laufen, solange RomM die Spiele nutzen soll.</p>
   <pre>{'volumes:\n  - ${HOME}/andredrive-romm:/romm/library:ro'}</pre>
   <p><b>Vorhandene Bibliothek ergänzen.</b> Kopiere die ROMs in den <code>roms</code>-Unterordner der bestehenden Bibliothek. Ersetze <code>/pfad/zur/bibliothek</code> durch den Host-Pfad, der bereits unter <code>/romm/library</code> eingebunden ist.</p>
   <pre>{'rclone copy --ignore-existing andredrive-romm:roms/ /pfad/zur/bibliothek/roms/'}</pre>
   <p>Starte danach in RomM einen Bibliotheksscan. Für Emulatoren und Metadaten nutze die <a href="https://docs.romm.app/latest/Platforms-and-Players/Supported-Platforms/" target="_blank" rel="noopener noreferrer">Plattformnamen von RomM</a>.</p>
  </details>
  <RommHost notify={notify} onUseUrl={url=>{
   setServerUrl(url);
   notify('RomM-Server-URL übernommen. Speichere sie in den RomM-Einstellungen.');
  }}/>
  {error&&<p className="error" role="alert">{error}</p>}
 </section>;
}
