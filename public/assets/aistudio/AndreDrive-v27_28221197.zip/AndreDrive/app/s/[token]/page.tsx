import Drive from "../../drive";
export default function Shared(){return <Drive/>}
