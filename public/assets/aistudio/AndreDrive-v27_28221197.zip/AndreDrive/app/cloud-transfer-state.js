'use client';
import {useSyncExternalStore} from 'react';
import {cloudTransferManager} from './cloud-transfer-client.js';
const empty={jobs:[],running:false,active:0,parallel:24,error:'',paused:false};
export function useCloudTransfers(){return useSyncExternalStore(cloudTransferManager.subscribe,cloudTransferManager.getSnapshot,()=>empty)}
