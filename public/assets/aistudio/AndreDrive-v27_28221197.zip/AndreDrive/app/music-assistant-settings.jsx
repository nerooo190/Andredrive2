'use client';

import {useEffect, useState} from 'react';
import {Copy, ExternalLink, Music} from 'lucide-react';

function serverAddress(input) {
  const value = input.trim();
  const hasScheme = /^https?:\/\//i.test(value);
  const address = new URL(hasScheme ? value : `http://${value}`);
  if (address.username || address.password || address.search || address.hash ||
      /[\\\s]/.test(value) || (!hasScheme && address.pathname !== '/')) {
    throw new Error('Ungültige Server-Adresse');
  }
  if (!hasScheme && !address.port && !/:\d+\/?$/.test(value)) address.port = '8095';
  return address.href.replace(/\/$/, '');
}

export default function MusicAssistantSettings({userId, notify}) {
  const storageKey = `andredrive:music-assistant:${userId}`;
  const [input, setInput] = useState('');
  const [serverUrl, setServerUrl] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    let saved = '';
    try {
      const value = localStorage.getItem(storageKey);
      if (value) saved = serverAddress(value);
    } catch { /* Browser storage may be unavailable. */ }
    setInput(saved);
    setServerUrl(saved);
  }, [storageKey]);

  function saveAddress(event) {
    event.preventDefault();
    setError('');
    let address = '';
    try {
      if (input.trim()) address = serverAddress(input);
    } catch {
      setError('Gib die IP-Adresse oder die vollständige HTTP- oder HTTPS-Adresse deines Music-Assistant-Servers ein.');
      return;
    }
    setInput(address);
    setServerUrl(address);
    try {
      if (address) localStorage.setItem(storageKey, address);
      else localStorage.removeItem(storageKey);
    } catch {
      setError('Diese Adresse ist bis zum Schließen der Einstellungen verfügbar. Der Browser-Speicher ist gesperrt.');
      return;
    }
    notify(address ? 'Music-Assistant-Adresse gespeichert.' : 'Music-Assistant-Adresse entfernt.');
  }

  async function copy(value, message) {
    try {
      await navigator.clipboard.writeText(value);
      setError('');
      notify(message);
    } catch {
      setError('Bitte markiere die Adresse und kopiere sie manuell.');
    }
  }

  const sourceUrl = window.location.origin;

  return <section className="webdav-settings">
    <div className="vod-access-heading"><Music size={20}/><h3>Music Assistant</h3></div>
    <p>Richte den offiziellen Music-Assistant-Server auf einem Linux-Rechner mit Docker ein und verbinde deine Apps über seine Server-Adresse.</p>
    <details className="webdav-guide">
      <summary>Music Assistant auf deinem Rechner hosten</summary>
      <ol>
        <li><a href="/music-assistant-compose.yaml" download="compose.yaml">Docker-Compose-Datei herunterladen</a> und als <code>compose.yaml</code> in einem eigenen Ordner auf dem Linux-Rechner ablegen.</li>
        <li>In diesem Ordner <code>docker compose up -d</code> ausführen. Music Assistant speichert seine Bibliothek und Einstellungen in einem Docker-Volume.</li>
        <li>Die IP-Adresse des Rechners unten eintragen. Im gleichen Netzwerk die Server-Adresse öffnen und beim ersten Start ein Music-Assistant-Konto anlegen.</li>
      </ol>
      <p>Für den Zugriff von unterwegs kannst du <a href="https://www.music-assistant.io/settings/remote-access/" target="_blank" rel="noreferrer">Remote Access in Music Assistant</a> einrichten.</p>
    </details>
    <form onSubmit={saveAddress}>
      <label>IP-Adresse oder URL deines Music-Assistant-Servers
        <input value={input} onChange={event => setInput(event.target.value)} placeholder="192.168.1.42 oder https://music.example.com" autoCapitalize="none" autoCorrect="off" spellCheck={false} maxLength={500}/>
      </label>
      <button type="submit" className="secondary full" disabled={!input.trim() && !serverUrl}>Server-Adresse speichern</button>
    </form>
    {serverUrl && <>
      <label>Server-URL für Music-Assistant-Clients
        <div className="copy-field">
          <input readOnly value={serverUrl} onFocus={event => event.target.select()}/>
          <button type="button" aria-label="Music-Assistant-Server-URL kopieren" onClick={() => copy(serverUrl, 'Music-Assistant-Server-URL kopiert.')}><Copy size={16}/></button>
        </div>
      </label>
      <p className="hint">Diese URL in deiner Music-Assistant-App eingeben. Die Adresse ist in diesem Browser gespeichert.</p>
      <a href={serverUrl} target="_blank" rel="noreferrer"><ExternalLink size={15} aria-hidden="true"/> Music Assistant öffnen</a>
    </>}
    <details className="webdav-guide">
      <summary>AndreDrive als Musikquelle hinzufügen</summary>
      <p>Erstelle oben unter <a href="#navidrome-settings">Navidrome / Subsonic</a> einen Gerätezugang, zum Beispiel mit dem Namen „Music Assistant“.</p>
      <p>Öffne in Music Assistant <b>Einstellungen → Musikquellen → Musikquelle hinzufügen → Open Subsonic</b>. Verwende den AndreDrive-Benutzernamen und das Passwort des Geräts. Für AndreDrive ist der Port <b>443</b>. Lass <b>Server Path</b> leer und deaktiviere Podcasts für diese Quelle.</p>
      <label>AndreDrive-Basis-URL für Open Subsonic
        <div className="copy-field">
          <input readOnly value={sourceUrl} onFocus={event => event.target.select()}/>
          <button type="button" aria-label="AndreDrive-Basis-URL kopieren" onClick={() => copy(sourceUrl, 'AndreDrive-Basis-URL kopiert.')}><Copy size={16}/></button>
        </div>
      </label>
    </details>
    {error && <p className="error" role="alert">{error}</p>}
  </section>;
}
