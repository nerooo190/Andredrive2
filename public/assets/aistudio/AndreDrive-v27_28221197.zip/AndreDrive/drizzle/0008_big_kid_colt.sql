CREATE TABLE `subsonic_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`username` text NOT NULL,
	`label` text NOT NULL,
	`secret` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `subsonic_accounts_username_unique` ON `subsonic_accounts` (`username`);--> statement-breakpoint
CREATE INDEX `subsonic_account_owner` ON `subsonic_accounts` (`user_id`);--> statement-breakpoint
CREATE TABLE `subsonic_playlists` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`comment` text DEFAULT '' NOT NULL,
	`tracks` text NOT NULL,
	`created` text NOT NULL,
	`changed` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `subsonic_playlist_owner` ON `subsonic_playlists` (`user_id`);