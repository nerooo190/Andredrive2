CREATE TABLE `cloud_auth` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`credentials` text NOT NULL,
	`expires` integer NOT NULL,
	`next_poll` integer NOT NULL,
	`interval` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `cloud_auth_owner` ON `cloud_auth` (`user_id`);--> statement-breakpoint
CREATE TABLE `cloud_connections` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`provider` text NOT NULL,
	`label` text NOT NULL,
	`credentials` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `cloud_connection_owner` ON `cloud_connections` (`user_id`);--> statement-breakpoint
CREATE TABLE `cloud_files` (
	`object_id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`connection_id` text NOT NULL,
	`remote_key` text NOT NULL,
	`data` text NOT NULL,
	`download_cache` text,
	`cache_expires` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `cloud_file_owner` ON `cloud_files` (`user_id`);--> statement-breakpoint
CREATE INDEX `cloud_file_connection` ON `cloud_files` (`connection_id`);