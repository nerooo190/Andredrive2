CREATE TABLE `file_metadata` (
	`file_id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`data` text DEFAULT '{}' NOT NULL,
	`updated` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `metadata_owner` ON `file_metadata` (`user_id`);--> statement-breakpoint
CREATE TABLE `metadata_settings` (
	`user_id` text PRIMARY KEY NOT NULL,
	`tmdb_token` text NOT NULL,
	`updated` text NOT NULL
);
