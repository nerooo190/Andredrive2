CREATE TABLE `abs_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`username` text NOT NULL,
	`label` text NOT NULL,
	`password_hash` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `abs_accounts_username_unique` ON `abs_accounts` (`username`);--> statement-breakpoint
CREATE INDEX `abs_account_owner` ON `abs_accounts` (`user_id`);--> statement-breakpoint
CREATE TABLE `abs_audio` (
	`user_id` text NOT NULL,
	`object_id` text NOT NULL,
	`size` integer NOT NULL,
	`duration` real NOT NULL,
	PRIMARY KEY(`user_id`, `object_id`)
);
--> statement-breakpoint
CREATE TABLE `abs_playback` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`item_id` text NOT NULL,
	`duration` real NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `abs_playback_account` ON `abs_playback` (`account_id`);--> statement-breakpoint
CREATE TABLE `abs_progress` (
	`user_id` text NOT NULL,
	`item_id` text NOT NULL,
	`current_time` real NOT NULL,
	`duration` real NOT NULL,
	`finished` integer NOT NULL,
	`started` integer NOT NULL,
	`updated` integer NOT NULL,
	PRIMARY KEY(`user_id`, `item_id`)
);
--> statement-breakpoint
CREATE TABLE `abs_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`access_hash` text NOT NULL,
	`refresh_hash` text NOT NULL,
	`expires` integer NOT NULL,
	`refresh_expires` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `abs_sessions_access_hash_unique` ON `abs_sessions` (`access_hash`);--> statement-breakpoint
CREATE UNIQUE INDEX `abs_sessions_refresh_hash_unique` ON `abs_sessions` (`refresh_hash`);--> statement-breakpoint
CREATE INDEX `abs_session_account` ON `abs_sessions` (`account_id`);