CREATE TABLE `iptv_series` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` text NOT NULL,
	`series_key` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `iptv_series_owner_key` ON `iptv_series` (`user_id`,`series_key`);--> statement-breakpoint
CREATE TABLE `iptv_streams` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`file_id` text NOT NULL,
	`hls` integer,
	`duration` real DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `iptv_streams_file_id_unique` ON `iptv_streams` (`file_id`);