CREATE TABLE `files` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`folder` text,
	`name` text NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`created` text NOT NULL,
	`kind` text DEFAULT 'movie' NOT NULL,
	`series` text DEFAULT '' NOT NULL,
	`season` integer DEFAULT 1 NOT NULL,
	`episode` integer DEFAULT 1 NOT NULL,
	`starred` integer DEFAULT 0 NOT NULL,
	`hls` text DEFAULT 'none' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `files_owner` ON `files` (`user_id`);--> statement-breakpoint
CREATE TABLE `folders` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`parent` text,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `folders_owner` ON `folders` (`user_id`);--> statement-breakpoint
CREATE TABLE `links` (
	`token` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`type` text NOT NULL,
	`target` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `links_owner` ON `links` (`user_id`);--> statement-breakpoint
CREATE TABLE `upload_parts` (
	`upload` text NOT NULL,
	`part` integer NOT NULL,
	`etag` text NOT NULL,
	`size` integer NOT NULL,
	PRIMARY KEY(`upload`, `part`)
);
--> statement-breakpoint
CREATE TABLE `uploads` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`upload_id` text NOT NULL,
	`metadata` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `uploads_owner` ON `uploads` (`user_id`);