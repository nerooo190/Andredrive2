CREATE TABLE `webdav_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`label` text NOT NULL,
	`username` text NOT NULL,
	`password_hash` text NOT NULL,
	`can_write` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `webdav_accounts_username_unique` ON `webdav_accounts` (`username`);--> statement-breakpoint
CREATE INDEX `webdav_owner` ON `webdav_accounts` (`user_id`);--> statement-breakpoint
ALTER TABLE `files` ADD `object_id` text;--> statement-breakpoint
ALTER TABLE `files` ADD `poster_id` text;