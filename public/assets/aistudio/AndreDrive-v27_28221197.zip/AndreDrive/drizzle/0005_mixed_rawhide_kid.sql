CREATE TABLE `jelly_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`label` text NOT NULL,
	`username` text NOT NULL,
	`password_hash` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `jelly_accounts_username_unique` ON `jelly_accounts` (`username`);--> statement-breakpoint
CREATE INDEX `jelly_owner` ON `jelly_accounts` (`user_id`);--> statement-breakpoint
CREATE TABLE `jelly_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `jelly_session_account` ON `jelly_sessions` (`account_id`);--> statement-breakpoint
CREATE TABLE `jelly_state` (
	`user_id` text NOT NULL,
	`item_id` text NOT NULL,
	`position` real DEFAULT 0 NOT NULL,
	`played` integer DEFAULT 0 NOT NULL,
	`play_count` integer DEFAULT 0 NOT NULL,
	`favorite` integer DEFAULT 0 NOT NULL,
	`updated` text NOT NULL,
	PRIMARY KEY(`user_id`, `item_id`)
);
--> statement-breakpoint
CREATE TABLE `trash_files` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`object_id` text NOT NULL,
	`poster_id` text NOT NULL,
	`data` text NOT NULL,
	`metadata` text NOT NULL,
	`deleted` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `trash_owner` ON `trash_files` (`user_id`);