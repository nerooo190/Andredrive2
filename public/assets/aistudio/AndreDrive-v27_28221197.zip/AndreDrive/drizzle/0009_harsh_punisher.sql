CREATE TABLE `opds_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`username` text NOT NULL,
	`label` text NOT NULL,
	`password_hash` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `opds_accounts_username_unique` ON `opds_accounts` (`username`);--> statement-breakpoint
CREATE INDEX `opds_account_owner` ON `opds_accounts` (`user_id`);