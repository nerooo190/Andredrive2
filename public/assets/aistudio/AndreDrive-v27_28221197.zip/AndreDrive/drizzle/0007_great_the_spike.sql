CREATE TABLE `cloud_transfer_parts` (
	`transfer_id` text NOT NULL,
	`part` integer NOT NULL,
	`etag` text NOT NULL,
	`size` integer NOT NULL,
	`sha256` text NOT NULL,
	`verified` integer DEFAULT 0 NOT NULL,
	PRIMARY KEY(`transfer_id`, `part`)
);
--> statement-breakpoint
CREATE TABLE `cloud_transfers` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`connection_id` text NOT NULL,
	`operation` text NOT NULL,
	`status` text NOT NULL,
	`data` text NOT NULL,
	`upload_id` text NOT NULL,
	`chunk_bytes` integer NOT NULL,
	`created` text NOT NULL,
	`updated` text NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL,
	`lease_token` text DEFAULT '' NOT NULL,
	`error` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `cloud_transfer_owner` ON `cloud_transfers` (`user_id`);