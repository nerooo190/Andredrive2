CREATE TABLE `romm_settings` (
	`user_id` text PRIMARY KEY NOT NULL,
	`server_url` text NOT NULL,
	`folder_id` text NOT NULL,
	`username` text,
	`password_hash` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `romm_settings_username_unique` ON `romm_settings` (`username`);